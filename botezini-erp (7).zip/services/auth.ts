import { supabase } from './supabase';
import { UserProfile } from '../types';

export const authService = {
    async signIn(email: string, password: string) {
        const { data, error } = await supabase.auth.signInWithPassword({
            email,
            password,
        });
        if (error) throw error;
        return data;
    },

    async signOut() {
        try {
            await supabase.auth.signOut();
        } catch (e) {
            console.warn("Supabase signOut failed, clearing local state anyway.");
        }
        localStorage.clear();
        // Redirect securely instead of reload to avoid state loops
        window.location.href = '/'; 
    },

    async getCurrentProfile(): Promise<UserProfile | null> {
        try {
            // 1. Validate Session Integrity
            const { data: { session }, error: sessionError } = await supabase.auth.getSession();
            
            if (sessionError) {
                console.error("Session Error:", sessionError.message);
                // Don't purge immediately on network error
                if (sessionError.message.includes('Failed to fetch')) {
                    throw new Error('Network Error during session check');
                }
                await this.handleCorruptToken();
                return null;
            }

            if (!session?.user) return null;

            // 2. Fetch Profile securely
            // This now relies on the RLS policies defined in the DB
            const { data: profile, error: profileError } = await supabase
                .from('profiles')
                .select('*')
                .eq('id', session.user.id)
                .single();

            if (profileError) {
                // Handle case where auth user exists but profile is missing in DB
                if (profileError.code === 'PGRST116') {
                     return {
                        id: session.user.id,
                        email: session.user.email || '',
                        role: 'factory', // Safe fallback
                        full_name: 'Guest'
                    };
                }
                
                // If network error during profile fetch
                if (profileError.message.includes('Failed to fetch')) {
                     console.warn("Network error fetching profile, returning limited session.");
                     return {
                        id: session.user.id,
                        email: session.user.email || '',
                        role: 'factory', // Fail safe to lowest permission
                        full_name: 'Offline User'
                    };
                }

                console.warn("Profile fetch error:", profileError.message);
                return null;
            }

            return profile as UserProfile;

        } catch (err: any) {
            console.error("Critical Auth Error:", err);
            
            if (err.message === 'Network Error during session check') {
                return null; // Treat as not authenticated temporarily
            }

            // 3. Trap specific Supabase/JWT errors
            if (
                err.message?.includes('invalid claim') || 
                err.message?.includes('missing sub claim') ||
                err.message?.includes('JWT')
            ) {
                await this.handleCorruptToken();
            }
            return null;
        }
    },

    async handleCorruptToken() {
        console.error("Security: Corrupted Token detected. Purging session.");
        localStorage.clear();
        try {
            await supabase.auth.signOut();
        } catch (e) { /* ignore */ }
    }
};
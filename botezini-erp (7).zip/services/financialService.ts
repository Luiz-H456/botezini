
import { Transaction, DRELine, BankAccount, DailyProjection } from '../types';
import { getTodayStr, addBusinessDays, addMonths } from '../utils';

/**
 * FINANCIAL SERVICE ENGINE
 * Calculates DRE, Cash Flow and KPIs strictly from Transaction data.
 * No manual inputs allowed for reports.
 */
export const financialService = {

  // --- ENGINE 1: DRE GENERATOR (Automated) ---
  calculateDRE(transactions: Transaction[], monthStr: string): DRELine[] {
    // Filter by Competency Date (transaction.date)
    const periodTxs = transactions.filter(t => t.date.startsWith(monthStr));

    // 1. Gross Revenue (Receita Bruta)
    const grossRevenue = periodTxs
        .filter(t => t.type === 'income')
        .reduce((sum, t) => sum + t.amount, 0);

    // 2. Deductions (Impostos sobre Venda, Devoluções)
    // Filter by specific categories or flags if available. Using string match fallback.
    const deductions = periodTxs
        .filter(t => t.type === 'expense' && (t.category?.includes('Imposto') || t.category?.includes('Devolução')))
        .reduce((sum, t) => sum + t.amount, 0);

    const netRevenue = grossRevenue - deductions;

    // 3. COGS / CPV (Custo do Produto Vendido)
    // Direct production costs: Matéria Prima, Mão de Obra Direta
    const cogs = periodTxs
        .filter(t => t.type === 'expense' && (t.category?.includes('Matéria') || t.category?.includes('Produção') || t.costCenterId === 'production'))
        .reduce((sum, t) => sum + t.amount, 0);

    const grossProfit = netRevenue - cogs;

    // 4. Operating Expenses (Despesas Operacionais)
    // Everything else that is expense but not deduction or COGS
    const opExpenses = periodTxs
        .filter(t => 
            t.type === 'expense' && 
            !t.category?.includes('Imposto') && 
            !t.category?.includes('Devolução') &&
            !t.category?.includes('Matéria') &&
            !t.category?.includes('Produção')
        )
        .reduce((sum, t) => sum + t.amount, 0);

    const ebitda = grossProfit - opExpenses;
    // Net Profit (Assuming no financial result/IR for simplicity in Phase 3, or treat as opExpenses)
    const netProfit = ebitda; 

    const calcPercent = (val: number) => grossRevenue ? (val / grossRevenue) * 100 : 0;

    return [
        { label: '(=) RECEITA BRUTA', value: grossRevenue, level: 1, percent: 100, isTotal: true },
        { label: '(-) Impostos / Deduções', value: deductions, level: 2, percent: calcPercent(deductions), isDeduction: true },
        { label: '(=) RECEITA LÍQUIDA', value: netRevenue, level: 1, percent: calcPercent(netRevenue), isTotal: true },
        { label: '(-) CPV (Custos Diretos)', value: cogs, level: 2, percent: calcPercent(cogs), isDeduction: true },
        { label: '(=) LUCRO BRUTO', value: grossProfit, level: 1, percent: calcPercent(grossProfit), isTotal: true },
        { label: '(-) Despesas Operacionais', value: opExpenses, level: 2, percent: calcPercent(opExpenses), isDeduction: true },
        { label: '(=) EBITDA', value: ebitda, level: 1, percent: calcPercent(ebitda), isTotal: true },
        { label: '(=) LUCRO LÍQUIDO', value: netProfit, level: 1, percent: calcPercent(netProfit), isTotal: true },
    ];
  },

  // --- ENGINE 2: CASH FLOW PROJECTION (Multi-Account) ---
  calculateCashFlowProjection(
      transactions: Transaction[], 
      accounts: BankAccount[], 
      days: number = 90
  ): DailyProjection[] {
      const today = getTodayStr();
      const projection: DailyProjection[] = [];
      
      // Calculate current total balance across all active accounts
      let currentTotalBalance = accounts
        .filter(a => a.isActive)
        .reduce((sum, a) => sum + (a.currentBalance || 0), 0);

      // We need to replay transactions from "today" onwards to project
      // Assuming 'transactions' contains open items (not paid) with future dates
      
      for (let i = 0; i < days; i++) {
          const dateStr = addBusinessDays(today, i);
          
          // Find transactions due on this day (or expected payment day)
          const dayTxs = transactions.filter(t => {
              const txDate = t.paymentDate || t.dueDate || t.date;
              return txDate === dateStr && !t.isPaid;
          });

          const inflow = dayTxs
            .filter(t => t.type === 'income')
            .reduce((sum, t) => sum + t.amount, 0);
            
          const outflow = dayTxs
            .filter(t => t.type === 'expense')
            .reduce((sum, t) => sum + t.amount, 0);

          const netChange = inflow - outflow;
          const opening = currentTotalBalance;
          currentTotalBalance += netChange;

          // Risk Analysis
          let riskLevel: DailyProjection['riskLevel'] = 'low';
          if (currentTotalBalance < 0) riskLevel = 'critical';
          else if (currentTotalBalance < 2000) riskLevel = 'high';
          else if (netChange < 0 && i < 7) riskLevel = 'medium'; // Burning cash short term

          projection.push({
              date: dateStr,
              openingBalance: opening,
              inflow,
              outflow,
              closingBalance: currentTotalBalance,
              riskLevel
          });
      }

      return projection;
  },

  // --- ENGINE 3: KPI CALCULATOR ---
  calculateKPIs(transactions: Transaction[], accounts: BankAccount[]) {
      const currentCash = accounts.reduce((sum, a) => sum + (a.currentBalance || 0), 0);
      
      // Calculate Burn Rate (Avg expenses last 3 months)
      const today = getTodayStr();
      const threeMonthsAgo = addMonths(today, -3);
      
      const last3MonthsExpenses = transactions
        .filter(t => t.type === 'expense' && t.date >= threeMonthsAgo && t.date < today)
        .reduce((sum, t) => sum + t.amount, 0);
      
      const dailyBurnRate = last3MonthsExpenses / 90;
      const runwayDays = dailyBurnRate > 0 ? currentCash / dailyBurnRate : 0;

      // Overdue Receivables
      const overdueReceivables = transactions
        .filter(t => t.type === 'income' && !t.isPaid && (t.dueDate || t.date) < today)
        .reduce((sum, t) => sum + t.amount, 0);

      return {
          currentCash,
          dailyBurnRate,
          runwayDays: Math.floor(runwayDays),
          overdueReceivables
      };
  }
};

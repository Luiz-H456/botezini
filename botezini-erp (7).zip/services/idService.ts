import { supabase } from './supabase';
import { getNow } from '../utils';

export const idService = {
  /**
   * Gera um UUID v4 padrão.
   * Centraliza a lógica caso queira mudar a lib de geração no futuro.
   */
  generateUUID: (): string => {
    return crypto.randomUUID();
  },

  /**
   * Gera o próximo ID sequencial baseado no último registro do banco de dados.
   * Formato: PREFIXO-ANO-NNN (ex: ORC-BZ-2026-001)
   * 
   * @param type 'budget' ou 'order'
   */
  getNextSequence: async (type: 'budget' | 'order'): Promise<string> => {
    const now = getNow();
    const year = now.getFullYear();
    
    // Definições por tipo
    const prefix = type === 'budget' ? 'ORC-BZ' : 'PED-BZ';
    const table = type === 'budget' ? 'budgets' : 'orders';
    const column = type === 'budget' ? 'serialNumber' : 'orderNumber';
    
    // Removido dateColumn. Ordenaremos pelo próprio ID para garantir a sequência numérica correta.
    // const dateColumn = type === 'budget' ? 'date' : 'createdAt';

    // Padrão de busca para o ano atual (ex: ORC-BZ-2026-%)
    const searchPattern = `${prefix}-${year}-%`;

    try {
      // Busca o último item criado neste ano
      // IMPORTANTE: Ordenar pela coluna do ID (descendente) e não pela data.
      // Isso evita erros se o usuário criar um orçamento com data retroativa.
      const { data, error } = await supabase
        .from(table)
        .select(column)
        .ilike(column, searchPattern)
        .order(column, { ascending: false }) 
        .limit(1)
        .single();

      if (error && error.code !== 'PGRST116') {
        // PGRST116 significa "nenhuma linha encontrada", o que é normal para o primeiro do ano
        console.warn('Erro ao buscar sequência:', error.message);
      }

      let nextNum = 1;

      if (data) {
        const currentId = (data as any)[column] as string;
        // Esperado: PRE-ANO-NUM (split por '-')
        const parts = currentId.split('-');
        if (parts.length >= 3) {
           const lastNumStr = parts[parts.length - 1]; // Pega a última parte (NNN)
           const lastNum = parseInt(lastNumStr, 10);
           if (!isNaN(lastNum)) {
             nextNum = lastNum + 1;
           }
        }
      }

      // Formata para 3 dígitos (001, 002...)
      return `${prefix}-${year}-${String(nextNum).padStart(3, '0')}`;

    } catch (err) {
      console.error('Falha crítica ao gerar ID sequencial, usando fallback de timestamp.', err);
      // Fallback de emergência para não travar o usuário
      return `${prefix}-${year}-${Date.now().toString().slice(-3)}`;
    }
  }
};
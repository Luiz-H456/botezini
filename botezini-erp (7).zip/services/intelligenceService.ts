
import { Transaction, Client, DailyProjection, ClientRiskProfile, FinancialHealthSnapshot, SimulationAction, Order } from '../types';
import { getTodayStr, addBusinessDays, countBusinessDays, addMonths } from '../utils';

/**
 * INTELLIGENCE SERVICE
 * Contains the "Brains" of the ERP Phase 2.
 * Calculates projections, risks, and scenarios client-side for interactivity.
 */
export const intelligenceService = {

  // --- ENGINE 1: CASH FLOW PROJECTION ---
  calculateProjection(
    transactions: Transaction[], 
    daysToProject: number = 90, 
    startBalance: number = 0,
    scenarios: SimulationAction[] = []
  ): DailyProjection[] {
    const today = getTodayStr();
    const projection: DailyProjection[] = [];
    let currentBalance = startBalance;

    // Helper to check if a tx is affected by scenario
    const getAdjustedDate = (tx: Transaction) => {
        let date = tx.date;
        // Scenario: Delay Payment
        const delayAction = scenarios.find(s => s.type === 'delay_payment');
        if (delayAction && tx.type === 'expense' && !tx.isPaid && tx.date >= today) {
             date = addBusinessDays(date, delayAction.days || 0);
        }
        return date;
    };

    const getAdjustedAmount = (tx: Transaction) => {
        // Scenario: Simulate Default
        const defaultAction = scenarios.find(s => s.type === 'simulate_default');
        if (defaultAction && tx.type === 'income' && !tx.isPaid) {
            // Simply remove random 20% of income for simulation or specific logic
            // For now, strict simulation: if default active, reduce future income by 30%
            return tx.amount * 0.7; 
        }
        return tx.amount;
    };

    // Build timeline
    for (let i = 0; i < daysToProject; i++) {
        const dateStr = addBusinessDays(today, i);
        
        // Find transactions for this day
        const dayTxs = transactions.filter(t => {
            const adjustedDate = getAdjustedDate(t);
            return adjustedDate === dateStr && !t.isPaid;
        });

        // Scenario: Inject Cash
        const injectAction = scenarios.find(s => s.type === 'inject_cash');
        let manualInflow = 0;
        if (i === 0 && injectAction) manualInflow = injectAction.amount || 0;

        const inflow = dayTxs.filter(t => t.type === 'income').reduce((sum, t) => sum + getAdjustedAmount(t), 0) + manualInflow;
        const outflow = dayTxs.filter(t => t.type === 'expense').reduce((sum, t) => sum + t.amount, 0);

        currentBalance = currentBalance + inflow - outflow;

        // Risk Rules
        let riskLevel: DailyProjection['riskLevel'] = 'low';
        if (currentBalance < 0) riskLevel = 'critical';
        else if (currentBalance < 5000) riskLevel = 'high'; // Threshold example
        else if (currentBalance < 15000) riskLevel = 'medium';

        projection.push({
            date: dateStr,
            openingBalance: currentBalance - inflow + outflow,
            inflow,
            outflow,
            closingBalance: currentBalance,
            riskLevel,
            isSimulated: scenarios.length > 0
        });
    }

    return projection;
  },

  // --- ENGINE 2: CLIENT RISK SCORING ---
  calculateClientRisk(clients: Client[], orders: Order[], transactions: Transaction[]): ClientRiskProfile[] {
      return clients.map(client => {
          const clientOrders = orders.filter(o => o.clientId === client.id);
          const clientTxs = transactions.filter(t => t.type === 'income' && clientOrders.some(o => o.id === t.referenceId));
          
          const totalRevenue = clientOrders.reduce((sum, o) => sum + o.totalAmount, 0);
          const openTxs = clientTxs.filter(t => !t.isPaid);
          const totalOpen = openTxs.reduce((sum, t) => sum + t.amount, 0);
          
          // Calculate Delays
          const paidLateTxs = clientTxs.filter(t => t.isPaid && t.date < (t.updatedAt || t.date).substring(0, 10)); // Heuristic
          // Better heuristic: compare due date vs today for open ones
          const overdueTxs = openTxs.filter(t => t.date < getTodayStr());
          
          let avgDelay = 0;
          if (overdueTxs.length > 0) {
              const totalDaysLate = overdueTxs.reduce((sum, t) => sum + countBusinessDays(t.date, getTodayStr()), 0);
              avgDelay = totalDaysLate / overdueTxs.length;
          }

          // Score Algo (100 is perfect)
          let score = 100;
          if (avgDelay > 5) score -= 20;
          if (avgDelay > 15) score -= 30;
          if (overdueTxs.length > 2) score -= 15;
          if (totalOpen > 50000) score -= 10; // High exposure

          let riskLevel: 'low' | 'medium' | 'high' = 'low';
          if (score < 50) riskLevel = 'high';
          else if (score < 80) riskLevel = 'medium';

          return {
              clientId: client.id,
              clientName: client.companyName,
              score: Math.max(0, score),
              riskLevel,
              totalOpen,
              avgDelayDays: Math.floor(avgDelay),
              suggestedCreditLimit: score * 1000 // Simple heuristic
          };
      }).sort((a, b) => a.score - b.score); // Riskiest first
  },

  // --- ENGINE 3: FINANCIAL HEALTH SNAPSHOT ---
  calculateHealth(transactions: Transaction[], assets: number, liabilities: number): FinancialHealthSnapshot {
      const income = transactions.filter(t => t.type === 'income').reduce((sum, t) => sum + t.amount, 0);
      const expense = transactions.filter(t => t.type === 'expense').reduce((sum, t) => sum + t.amount, 0);
      const profit = income - expense;
      
      // Calculate daily burn rate (avg expense last 30 days)
      const last30DaysExpense = transactions
        .filter(t => t.type === 'expense' && t.date >= addMonths(getTodayStr(), -1))
        .reduce((sum, t) => sum + t.amount, 0);
      const dailyBurn = last30DaysExpense / 30;

      // Current Cash (simplified)
      const cash = income - expense; // This should ideally come from a real bank balance input

      return {
          period: getTodayStr().substring(0, 7),
          liquidityRatio: liabilities > 0 ? assets / liabilities : 0,
          profitMargin: income > 0 ? (profit / income) * 100 : 0,
          debtRatio: assets > 0 ? liabilities / assets : 0,
          cashRunwayDays: dailyBurn > 0 ? cash / dailyBurn : 0,
          breakEvenPoint: expense * 1.2 // Heuristic
      };
  }
};

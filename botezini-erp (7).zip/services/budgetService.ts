import { BudgetItem, BudgetCustomization, BudgetExtra } from '../types';

export const budgetService = {
  calculateTotals: (
    items: BudgetItem[],
    customizations: BudgetCustomization[],
    extras: BudgetExtra[],
    discount: number
  ) => {
    const subtotalItems = items.reduce((acc, i) => acc + i.total, 0);
    const subtotalCustom = customizations.reduce((acc, c) => acc + c.total, 0);
    const subtotalExtras = extras.reduce((acc, e) => acc + e.total, 0);
    
    const grossTotal = subtotalItems + subtotalCustom + subtotalExtras;
    const totalAmount = Math.max(0, grossTotal - discount);

    return {
      subtotalItems,
      subtotalCustom,
      subtotalExtras,
      totalAmount
    };
  },

  calculatePayments: (totalAmount: number, downPaymentPercent: number) => {
    const downPaymentValue = totalAmount * (downPaymentPercent / 100);
    const deliveryPaymentValue = totalAmount - downPaymentValue;
    return { downPaymentValue, deliveryPaymentValue };
  }
};
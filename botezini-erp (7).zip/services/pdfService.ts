
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { Budget, Client, CompanyProfile, Order, Product, DRELine, Transaction } from '../types';
import { formatDate, formatCurrency, addBusinessDays } from '../utils';

class PdfService {
    private drawHeader(doc: jsPDF, title: string, id: string, dateLabel: string, dateValue: string, companyProfile?: CompanyProfile | null) {
        const pageWidth = doc.internal.pageSize.getWidth();
        const darkColor = [20, 20, 20] as [number, number, number]; 
        const goldColor = [201, 162, 77] as [number, number, number]; 

        // Header Background
        doc.setFillColor(...darkColor);
        doc.rect(0, 0, pageWidth * 0.65, 45, 'F');
        doc.setFillColor(...goldColor);
        doc.rect(pageWidth * 0.65, 0, pageWidth * 0.35, 45, 'F');

        // Logo Placeholder
        doc.setFillColor(255, 255, 255);
        doc.rect(10, 7, 31, 31, 'F');
        
        if (companyProfile?.logoUrl) {
            try { doc.addImage(companyProfile.logoUrl, 'PNG', 11, 8, 29, 29, undefined, 'FAST'); } catch (e) {}
        }

        // Company Info
        doc.setTextColor(255, 255, 255);
        const startTextX = 48;
        let currentY = 15;

        doc.setFontSize(16);
        doc.setFont(undefined, 'bold');
        doc.text((companyProfile?.name || "BOTEZINI ERP").toUpperCase(), startTextX, currentY);
        
        currentY += 6;
        doc.setFontSize(8);
        doc.setFont(undefined, 'normal');
        doc.setTextColor(200, 200, 200);
        
        if (companyProfile?.cnpj) { doc.text(`CNPJ: ${companyProfile.cnpj}`, startTextX, currentY); currentY += 4; }
        if (companyProfile?.address) {
            const splitAddress = doc.splitTextToSize(companyProfile.address, (pageWidth * 0.65) - startTextX - 5);
            doc.text(splitAddress, startTextX, currentY);
            currentY += (splitAddress.length * 3.5);
        }
        
        // Report Info (Right Side)
        doc.setTextColor(0, 0, 0); 
        const goldX = (pageWidth * 0.65) + 10;
        let goldY = 15;

        doc.setFontSize(12);
        doc.setFont(undefined, 'bold');
        doc.text(title, goldX, goldY);
        goldY += 6;
        
        doc.setFontSize(9);
        doc.setFont(undefined, 'normal');
        doc.text(id, goldX, goldY);
        goldY += 10;
        
        doc.setFontSize(8);
        doc.text(`${dateLabel}:`, goldX, goldY);
        doc.setFont(undefined, 'bold');
        doc.text(dateValue, goldX + 25, goldY);

        return 55; // Return Y start position for content
    }

    // ... (Existing budget/production methods remain unchanged) ...
    public generateBudgetPDF(budget: Budget, client: Client, companyProfile?: CompanyProfile | null) {
        const doc = new jsPDF();
        const pageWidth = doc.internal.pageSize.getWidth();
        const pageHeight = doc.internal.pageSize.getHeight();
        
        let currentY = this.drawHeader(doc, "ORÇAMENTO COMERCIAL", budget.serialNumber, "Data", formatDate(budget.date), companyProfile);
        
        doc.setFontSize(9);
        doc.text(`Validade: ${budget.validityDays} dias`, (pageWidth * 0.65) + 10, 38);

        doc.setFontSize(11);
        doc.setFont(undefined, 'bold');
        doc.setTextColor(0, 0, 0);
        doc.text("DADOS DO CLIENTE", 14, currentY);
        currentY += 2;
        doc.setDrawColor(200, 200, 200);
        doc.setLineWidth(0.5);
        doc.line(14, currentY, pageWidth - 14, currentY);
        currentY += 6;
        doc.setFontSize(10);
        doc.setFont(undefined, 'normal');

        doc.text(client.companyName, 14, currentY);
        doc.setFontSize(9);
        doc.text(`CNPJ: ${client.cnpj || '-'}`, 14, currentY + 5);
        
        const col2X = 120;
        doc.text(`Contato: ${client.contactPerson || '-'}`, col2X, currentY);
        doc.text(`Tel: ${client.phone || '-'}`, col2X, currentY + 10);

        currentY += 25; 
        doc.setFontSize(11);
        doc.setFont(undefined, 'bold');
        doc.text("ITENS DO ORÇAMENTO", 14, currentY);
        currentY += 3;

        const itemRows = budget.items.map(item => [
            item.productName,
            `${item.model || ''} ${item.fabric || ''} ${item.color || ''}`,
            item.size,
            item.quantity.toString(),
            formatCurrency(item.unitPrice),
            formatCurrency(item.total)
        ]);

        autoTable(doc, {
            startY: currentY,
            head: [['Produto', 'Detalhes', 'Tam', 'Qtd', 'Unit.', 'Total']],
            body: itemRows,
            theme: 'plain',
            headStyles: { fillColor: [20, 20, 20], textColor: 255, fontStyle: 'bold', cellPadding: 3 },
            bodyStyles: { cellPadding: 3, fontSize: 9 },
            columnStyles: { 0: { fontStyle: 'bold' }, 4: { halign: 'right' }, 5: { halign: 'right', fontStyle: 'bold' } },
            alternateRowStyles: { fillColor: [250, 250, 250] }
        });

        // @ts-ignore
        let finalY = doc.lastAutoTable.finalY + 10;

        const boxHeight = 90; 
        const boxWidth = 95; 
        
        if (finalY > pageHeight - (boxHeight + 10)) { doc.addPage(); finalY = 20; }
        
        const boxX = pageWidth - boxWidth - 14;
        doc.setFillColor(240, 240, 240);
        doc.rect(boxX, finalY, boxWidth, boxHeight, 'F');
        
        let boxY = finalY + 10;
        const textRightX = pageWidth - 20;
        const textLeftX = boxX + 5;
        
        doc.setTextColor(0,0,0);
        doc.setFontSize(10);
        doc.text("Subtotal:", textLeftX, boxY);
        doc.text(formatCurrency(budget.subtotalItems + budget.subtotalCustomizations + budget.subtotalExtras), textRightX, boxY, { align: 'right' });
        
        if (budget.discount > 0) {
            boxY += 6;
            doc.setTextColor(200, 0, 0);
            doc.text("Desconto:", textLeftX, boxY);
            doc.text(`- ${formatCurrency(budget.discount)}`, textRightX, boxY, { align: 'right' });
            doc.setTextColor(0,0,0);
        }

        boxY += 8;
        doc.setLineWidth(0.2);
        doc.line(textLeftX, boxY, textRightX, boxY);
        
        boxY += 6;
        doc.setFontSize(14);
        doc.setFont(undefined, 'bold');
        doc.text("TOTAL:", textLeftX, boxY);
        doc.text(formatCurrency(budget.totalAmount), textRightX, boxY, { align: 'right' });

        boxY += 12;
        doc.setFontSize(10);
        doc.setFont(undefined, 'bold');
        doc.text("ENTREGA ESTIMADA:", textLeftX, boxY);
        
        boxY += 5;
        doc.setFontSize(9);
        doc.setFont(undefined, 'normal');
        const deliveryDays = budget.deliveryTimeDays || 20;
        const estimatedDate = addBusinessDays(budget.date, deliveryDays);
        doc.text(`${deliveryDays} dias úteis (${formatDate(estimatedDate)})`, textLeftX, boxY);

        if (companyProfile?.bankName || companyProfile?.bankAccount || companyProfile?.pixKey) {
            boxY += 10;
            doc.setFontSize(10);
            doc.setFont(undefined, 'bold');
            doc.text("DADOS PARA PAGAMENTO:", textLeftX, boxY);
            
            boxY += 5;
            doc.setFontSize(8);
            doc.setFont(undefined, 'normal');
            
            if (companyProfile.bankName) {
                doc.text(`Banco: ${companyProfile.bankName}`, textLeftX, boxY);
                boxY += 4;
            }
            if (companyProfile.bankAgency || companyProfile.bankAccount) {
                doc.text(`Ag: ${companyProfile.bankAgency || '-'} / Conta: ${companyProfile.bankAccount || '-'}`, textLeftX, boxY);
                boxY += 4;
            }
            if (companyProfile.bankHolder) {
                doc.text(`Titular: ${companyProfile.bankHolder}`, textLeftX, boxY);
                boxY += 4;
            }
            if (companyProfile.pixKey) {
                boxY += 2;
                doc.setFont(undefined, 'bold');
                doc.text(`PIX: ${companyProfile.pixKey}`, textLeftX, boxY);
            }
        }

        doc.save(`Orcamento_${budget.serialNumber}.pdf`);
    }

    public generateOrderProductionPDF(order: Order, client: Client, products: Product[], companyProfile?: CompanyProfile | null, budgetRef?: string) {
        const doc = new jsPDF();
        const pageWidth = doc.internal.pageSize.getWidth();
        const leftMargin = 34;
        
        doc.setFillColor(0, 0, 0);
        doc.rect(0, 0, pageWidth, 24, 'F');
        doc.setTextColor(255, 255, 255);
        doc.setFontSize(16);
        doc.setFont('helvetica', 'bold');
        doc.text("FICHA DE PRODUÇÃO", 14, 16);

        let currentY = 40;
        doc.setTextColor(0, 0, 0);
        doc.setFontSize(24);
        doc.text(order.orderNumber, leftMargin, currentY);

        doc.setFontSize(10);
        doc.setFont('helvetica', 'normal');
        doc.text(`ENTREGA:`, pageWidth - 60, currentY);
        doc.setTextColor(200, 0, 0);
        doc.setFont('helvetica', 'bold');
        doc.text(formatDate(order.deadline), pageWidth - 40, currentY);
        doc.setTextColor(0, 0, 0);

        currentY += 18;
        doc.text(`CLIENTE: ${client.companyName.toUpperCase()}`, leftMargin, currentY);
        if(budgetRef) doc.text(`Ref. Orçamento: ${budgetRef}`, leftMargin, currentY + 5);
        currentY += 15;

        const itemRows = order.items.map(item => {
            const product = products.find(p => p.id === item.productId);
            return [item.quantity.toString(), item.size, product ? product.name : '-', item.fabric || '-', item.color || '-', ''];
        });

        autoTable(doc, {
            startY: currentY,
            margin: { left: leftMargin, right: 14 },
            head: [['QTD', 'TAM', 'REF', 'TECIDO', 'COR', 'CONF.']],
            body: itemRows,
            theme: 'plain',
            headStyles: { fillColor: [220, 220, 220], textColor: 0, fontStyle: 'bold', halign: 'center' },
            bodyStyles: { textColor: 0, cellPadding: 3, halign: 'center', lineColor: [200, 200, 200], lineWidth: { bottom: 0.1 } },
            columnStyles: { 0: { cellWidth: 15 }, 1: { cellWidth: 15 }, 2: { halign: 'left' } },
            didParseCell: (data) => { if (data.section === 'body' && data.column.index === 5) data.cell.text = ['_______']; }
        });

        doc.save(`FichaProducao_${order.orderNumber}.pdf`);
    }

    public generateExecutiveReport(
        dreData: DRELine[], 
        periodStr: string, 
        companyProfile: CompanyProfile | null,
        topExpenses: { name: string, value: number }[],
        kpis: { revenue: number, expenses: number, ebitda: number, result: number }
    ) {
        const doc = new jsPDF();
        const pageWidth = doc.internal.pageSize.getWidth();
        const date = new Date();
        const refId = `FIN-REP-${date.getFullYear()}-${(date.getMonth()+1).toString().padStart(2,'0')}`;
        
        let currentY = this.drawHeader(doc, "RELATÓRIO EXECUTIVO", refId, "Emitido em", formatDate(date.toISOString()), companyProfile);
        
        // --- SCORECARD ---
        doc.setFillColor(245, 245, 245);
        doc.setDrawColor(200, 200, 200);
        doc.roundedRect(14, currentY, pageWidth - 28, 25, 1, 1, 'FD');
        
        const colWidth = (pageWidth - 28) / 4;
        const labels = ['Receita Líquida', 'Total Despesas', 'EBITDA', 'Resultado Líquido'];
        const values = [kpis.revenue, kpis.expenses, kpis.ebitda, kpis.result];
        
        doc.setFontSize(8);
        doc.setTextColor(100, 100, 100);
        
        labels.forEach((label, i) => {
            doc.text(label.toUpperCase(), 14 + (colWidth * i) + (colWidth/2), currentY + 8, { align: 'center' });
        });

        doc.setFontSize(12);
        doc.setFont(undefined, 'bold');
        doc.setTextColor(0, 0, 0);

        values.forEach((val, i) => {
            const text = formatCurrency(val);
            if (i === 3) doc.setTextColor(val >= 0 ? 0 : 200, val >= 0 ? 150 : 0, 0); // Green or Red for Result
            doc.text(text, 14 + (colWidth * i) + (colWidth/2), currentY + 18, { align: 'center' });
            doc.setTextColor(0, 0, 0); // Reset
        });

        currentY += 35;

        // --- NEW SECTION: GOALS ANALYSIS (METAS) ---
        if (companyProfile?.revenueGoal || companyProfile?.expenseLimit) {
            doc.setFontSize(11);
            doc.setTextColor(201, 162, 77); // Gold
            doc.text("ANÁLISE DE METAS (KPIs)", 14, currentY);
            currentY += 3;

            const goalBody = [];
            if (companyProfile.revenueGoal) {
                const pct = (kpis.revenue / companyProfile.revenueGoal) * 100;
                goalBody.push(['Faturamento Mensal', formatCurrency(kpis.revenue), formatCurrency(companyProfile.revenueGoal), `${pct.toFixed(1)}%`]);
            }
            if (companyProfile.expenseLimit) {
                const pct = (kpis.expenses / companyProfile.expenseLimit) * 100;
                goalBody.push(['Teto de Gastos', formatCurrency(kpis.expenses), formatCurrency(companyProfile.expenseLimit), `${pct.toFixed(1)}%`]);
            }

            autoTable(doc, {
                startY: currentY,
                head: [['Indicador', 'Realizado', 'Meta / Limite', '% Atingido']],
                body: goalBody,
                theme: 'striped',
                headStyles: { fillColor: [50, 50, 50] },
                bodyStyles: { fontSize: 10 },
                columnStyles: { 3: { fontStyle: 'bold' } }
            });

            // @ts-ignore
            currentY = doc.lastAutoTable.finalY + 15;
        }

        // --- DRE TABLE ---
        doc.setFontSize(11);
        doc.setTextColor(201, 162, 77); // Gold
        doc.text("D.R.E - DEMONSTRAÇÃO DO RESULTADO", 14, currentY);
        currentY += 3;

        const tableBody = dreData.map(row => {
            const indent = row.level === 1 ? '' : row.level === 2 ? '   ' : '      ';
            const label = indent + row.label;
            const valStr = formatCurrency(row.value);
            const displayVal = row.isDeduction ? `(${valStr})` : valStr;
            const percentStr = row.percent !== undefined ? `${row.percent.toFixed(1)}%` : '-';
            return [label, percentStr, displayVal];
        });

        autoTable(doc, {
            startY: currentY,
            head: [['Descrição da Conta', 'A.V. %', 'Valor (R$)']],
            body: tableBody,
            theme: 'grid',
            headStyles: { 
                fillColor: [20, 20, 20], 
                textColor: [255, 255, 255], 
                fontStyle: 'bold', 
                halign: 'center',
                lineWidth: 0
            },
            styles: {
                cellPadding: 4,
                fontSize: 9,
                textColor: [50, 50, 50],
                lineColor: [230, 230, 230],
                lineWidth: 0.1
            },
            columnStyles: {
                0: { cellWidth: 'auto' },
                1: { cellWidth: 25, halign: 'center' },
                2: { cellWidth: 40, halign: 'right', fontStyle: 'bold' }
            },
            didParseCell: (data) => {
                const rowIndex = data.row.index;
                const rowData = dreData[rowIndex];
                if (data.section === 'body' && rowData) {
                    if (rowData.isTotal) {
                        data.cell.styles.fontStyle = 'bold';
                        data.cell.styles.fillColor = [245, 245, 245];
                    }
                    if (data.column.index === 2) {
                        if (rowData.isDeduction) data.cell.styles.textColor = [180, 0, 0];
                        if (rowData.label.includes('LUCRO LÍQUIDO') || rowData.label.includes('EBITDA')) {
                            data.cell.styles.textColor = rowData.value >= 0 ? [0, 120, 0] : [180, 0, 0];
                        }
                    }
                }
            }
        });

        // @ts-ignore
        let finalY = doc.lastAutoTable.finalY + 15;

        // --- TOP EXPENSES ---
        // Check space
        if (finalY + 60 > doc.internal.pageSize.getHeight()) {
            doc.addPage();
            finalY = 20;
        }

        doc.setFontSize(11);
        doc.setTextColor(201, 162, 77);
        doc.text("PRINCIPAIS DESPESAS DO PERÍODO", 14, finalY);
        finalY += 5;

        const expenseRows = topExpenses.slice(0, 5).map(e => [e.name, formatCurrency(e.value)]);
        
        autoTable(doc, {
            startY: finalY,
            head: [['Categoria', 'Valor']],
            body: expenseRows,
            theme: 'striped',
            headStyles: { fillColor: [220, 220, 220], textColor: [0,0,0], fontStyle: 'bold' },
            bodyStyles: { fontSize: 9 },
            columnStyles: { 1: { halign: 'right', cellWidth: 40 } },
            margin: { right: pageWidth / 2 } // Half width table
        });

        // --- FOOTER NOTE WITH BANK INFO ---
        const pageHeight = doc.internal.pageSize.getHeight();
        let footerY = pageHeight - 20;
        
        if (companyProfile?.bankName || companyProfile?.pixKey) {
             doc.setFontSize(8);
             doc.setTextColor(100, 100, 100);
             doc.text(`Dados Bancários: ${companyProfile.bankName || ''} | AG: ${companyProfile.bankAgency || ''} CC: ${companyProfile.bankAccount || ''} | PIX: ${companyProfile.pixKey || ''}`, 14, footerY - 5);
        }

        doc.setFontSize(8);
        doc.setTextColor(150, 150, 150);
        doc.text("Este relatório foi gerado automaticamente pelo BOTEZINI ERP para fins de análise gerencial.", 14, footerY);

        doc.save(`Relatorio_Executivo_${periodStr}.pdf`);
    }
}

export const pdfService = new PdfService();

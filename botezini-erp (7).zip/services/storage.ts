
import { supabase } from './supabase';
import { idService } from './idService';
import { Client, Product, Transaction, Order, Budget, Supplier, CompanyProfile, CostCenter } from '../types';
import { getNow } from '../utils';
import { BudgetRepository } from '../repositories/budgetRepository';

// Initialize Repositories
const budgetRepository = new BudgetRepository();

// --- HELPER CATEGORIAS ---
const getCategories = async (type: string): Promise<string[]> => {
    try {
        const { data, error } = await supabase.from('app_settings').select('value').eq('key', `cat_${type}`).single();
        if (error && error.code !== 'PGRST116') {
            console.warn(`Erro ao buscar categorias (${type}):`, error.message);
        }
        return data?.value || [];
    } catch (e) { 
        console.warn(`Falha na conexão ao buscar categorias (${type})`);
        return []; 
    }
};

const saveCategories = async (type: string, cats: string[]) => {
    try { 
        await supabase.from('app_settings').upsert({ key: `cat_${type}`, value: cats }); 
    } catch (e) { 
        console.error("Erro ao salvar categorias:", e); 
    }
};

// --- HELPER GENERIC SETTINGS ---
const getSetting = async <T>(key: string, defaultValue: T): Promise<T> => {
    try {
        const { data, error } = await supabase.from('app_settings').select('value').eq('key', key).single();
        if (error) return defaultValue;
        return data.value as T;
    } catch (e) { return defaultValue; }
};

const saveSetting = async <T>(key: string, value: T) => {
    await supabase.from('app_settings').upsert({ key, value });
};

/**
 * STORAGE SERVICE FACADE
 * Delegates to specific repositories or keeps simple logic for smaller entities.
 */
export const storageService = {
  
  getCategories: (type: string) => {
      const local = localStorage.getItem(`botezini_cat_${type}`);
      // Tenta sincronizar em background, sem bloquear a UI
      getCategories(type).then(cats => {
          if (cats.length > 0) localStorage.setItem(`botezini_cat_${type}`, JSON.stringify(cats));
      }).catch(e => console.warn(`Sync categorias falhou (${type})`));
      
      return local ? JSON.parse(local) : [];
  },
  
  saveCategories: async (type: string, cats: string[]) => {
      localStorage.setItem(`botezini_cat_${type}`, JSON.stringify(cats));
      await saveCategories(type, cats);
  },

  getCompanyProfile: async (): Promise<CompanyProfile | null> => {
      try {
          const { data, error } = await supabase.from('app_settings').select('value').eq('key', 'company_profile').single();
          if (error) return null;
          return data.value as CompanyProfile;
      } catch (e) { return null; }
  },

  saveCompanyProfile: async (profile: CompanyProfile) => {
      const { error } = await supabase.from('app_settings').upsert({ key: 'company_profile', value: profile });
      if (error) throw new Error(error.message);
  },

  // -- FINANCIAL SETTINGS (COST CENTERS) --
  // Refatorado para usar tabela dedicada 'cost_centers'
  getCostCenters: async (): Promise<CostCenter[]> => {
      const { data, error } = await supabase
          .from('cost_centers')
          .select('*')
          .order('name', { ascending: true });
          
      if (error) {
          console.error("Erro ao buscar centros de custo:", error.message);
          return [];
      }
      return data || [];
  },

  saveCostCenter: async (costCenter: CostCenter) => {
      const now = getNow().toISOString();
      const payload = { 
          ...costCenter, 
          id: costCenter.id || idService.generateUUID(), 
          updatedAt: now,
          // Se for insert, define createdAt
          createdAt: costCenter.createdAt || now
      };
      
      const { error } = await supabase.from('cost_centers').upsert(payload);
      if (error) throw new Error(error.message);
  },

  deleteCostCenter: async (id: string) => {
      const { error } = await supabase.from('cost_centers').delete().eq('id', id);
      if (error) throw new Error(error.message);
  },

  // -- CLIENTES --
  getClients: async (): Promise<Client[]> => {
    const { data, error } = await supabase.from('clients').select('*');
    if (error) throw new Error(error.message);
    return data || [];
  },
  saveClient: async (client: Client) => {
    const now = getNow().toISOString();
    const payload = { ...client, id: client.id || idService.generateUUID(), updatedAt: now, createdAt: client.createdAt || now };
    const { error } = await supabase.from('clients').upsert(payload);
    if (error) throw new Error(error.message);
  },
  deleteClient: async (id: string) => {
    const { error } = await supabase.from('clients').delete().eq('id', id);
    if (error) throw new Error(error.message);
  },

  // -- FORNECEDORES --
  getSuppliers: async (): Promise<Supplier[]> => {
    const { data, error } = await supabase.from('suppliers').select('*');
    if (error) throw new Error(error.message);
    return data || [];
  },
  saveSupplier: async (supplier: Supplier) => {
    const now = getNow().toISOString();
    const payload = { ...supplier, id: supplier.id || idService.generateUUID(), updatedAt: now, createdAt: supplier.createdAt || now };
    const { error } = await supabase.from('suppliers').upsert(payload);
    if (error) throw new Error(error.message);
  },
  deleteSupplier: async (id: string) => {
    const { error } = await supabase.from('suppliers').delete().eq('id', id);
    if (error) throw new Error(error.message);
  },

  // -- PRODUTOS --
  getProducts: async (): Promise<Product[]> => {
    const { data, error } = await supabase.from('products').select('*');
    if (error) throw new Error(error.message);
    return data || [];
  },
  saveProduct: async (product: Product) => {
    const now = getNow().toISOString();
    const payload = { ...product, id: product.id || idService.generateUUID(), updatedAt: now, createdAt: product.createdAt || now };
    const { error } = await supabase.from('products').upsert(payload);
    if (error) throw new Error(error.message);
  },
  deleteProduct: async (id: string) => {
    const { error } = await supabase.from('products').delete().eq('id', id);
    if (error) throw new Error(error.message);
  },

  // -- ORÇAMENTOS (DELEGATED TO REPO) --
  getBudgets: async () => budgetRepository.getAll(),
  saveBudget: async (budget: Budget) => budgetRepository.save(budget),
  deleteBudget: async (id: string) => budgetRepository.delete(id),

  // -- PEDIDOS --
  getOrders: async (): Promise<Order[]> => {
    const { data, error } = await supabase.from('orders').select('*').order('createdAt', { ascending: false });
    if (error) throw new Error(error.message);
    return data || [];
  },
  saveOrder: async (order: Order) => {
    const now = getNow().toISOString();
    const payload = { ...order, id: order.id || idService.generateUUID(), updatedAt: now, createdAt: order.createdAt || now };
    const { error } = await supabase.from('orders').upsert(payload);
    if (error) throw new Error(error.message);
  },
  deleteOrder: async (id: string) => {
    const { error } = await supabase.from('orders').delete().eq('id', id);
    if (error) throw new Error(error.message);
  },

  // -- FINANCEIRO --
  getTransactions: async (): Promise<Transaction[]> => {
    const { data, error } = await supabase.from('transactions').select('*').order('date', { ascending: false });
    if (error) throw new Error(error.message);
    return data || [];
  },
  getTransactionsByRecurrenceId: async (recurrenceId: string): Promise<Transaction[]> => {
    const { data, error } = await supabase.from('transactions').select('*').eq('recurrenceId', recurrenceId).order('date', { ascending: true });
    if (error) throw new Error(error.message);
    return data || [];
  },
  addTransaction: async (tx: Transaction) => {
    const now = getNow().toISOString();
    const payload = { ...tx, id: tx.id || idService.generateUUID(), updatedAt: now, createdAt: now };
    const { error } = await supabase.from('transactions').insert(payload);
    if (error) throw new Error(error.message);
  },
  addTransactions: async (txs: Transaction[]) => {
    const now = getNow().toISOString();
    const payload = txs.map(tx => ({ ...tx, id: tx.id || idService.generateUUID(), updatedAt: now, createdAt: now }));
    const { error } = await supabase.from('transactions').insert(payload);
    if (error) throw new Error(error.message);
  },
  upsertTransactions: async (txs: Transaction[]) => {
    const { error } = await supabase.from('transactions').upsert(txs);
    if (error) throw new Error(error.message);
  },
  updateTransaction: async (tx: Transaction) => {
    const now = getNow().toISOString();
    const payload = { ...tx, updatedAt: now };
    const { error } = await supabase.from('transactions').update(payload).eq('id', tx.id);
    if (error) throw new Error(error.message);
  },
  deleteTransaction: async (id: string) => {
    const { error } = await supabase.from('transactions').delete().eq('id', id);
    if (error) throw new Error(error.message);
  },
  deleteTransactionsByReference: async (referenceId: string) => {
    const { error } = await supabase.from('transactions').delete().eq('referenceId', referenceId);
    if (error) throw new Error(error.message);
  },
  deleteTransactionSeries: async (recurrenceId: string) => {
    const { error } = await supabase.from('transactions').delete().eq('recurrenceId', recurrenceId);
    if (error) throw new Error(error.message);
  }
};

import { createClient } from '@supabase/supabase-js';

// Helper to safely get env vars without crashing
const getEnv = (key: string) => {
    // Check for Vite's import.meta.env
    // We access it safely to prevent "Cannot read properties of undefined"
    const meta = import.meta as any;
    if (meta && meta.env && meta.env[key]) {
        return meta.env[key];
    }
    
    // Check for standard process.env (React Scripts / Webpack / Polyfills)
    // The typeof check prevents ReferenceError if process is not defined
    if (typeof process !== 'undefined' && process.env && process.env[key]) {
        return process.env[key];
    }

    return '';
};

// FALLBACK CREDENTIALS (Auto-injected to fix connection issues)
const FALLBACK_URL = 'https://xtpndafiehgjbihoznul.supabase.co';
const FALLBACK_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inh0cG5kYWZpZWhnamJpaG96bnVsIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Njg3ODQ0MDUsImV4cCI6MjA4NDM2MDQwNX0.eMNxjKGTErp9ci0TgdXfxJblJyakgC-8PageQbhgi6Y';

const supabaseUrl = getEnv('VITE_SUPABASE_URL') || FALLBACK_URL;
const supabaseKey = getEnv('VITE_SUPABASE_ANON_KEY') || FALLBACK_KEY;

if (!supabaseUrl || !supabaseKey) {
    console.warn("CRITICAL: Supabase Environment Variables Missing. Check your .env file.");
} else {
    // console.log("Supabase Connection Initialized:", supabaseUrl);
}

// Initialize client with fallback to prevent immediate crash, allowing UI to show connection error later
export const supabase = createClient(
    supabaseUrl || 'https://placeholder.supabase.co', 
    supabaseKey || 'placeholder',
    {
        auth: {
            persistSession: true,
            autoRefreshToken: true,
            detectSessionInUrl: false
        }
    }
);

export const checkConnection = async (): Promise<{ success: boolean; message?: string }> => {
    // If we are using the placeholder, we know it will fail.
    if (!supabaseUrl || supabaseUrl.includes('placeholder')) {
        return { 
            success: false, 
            message: 'CONFIGURAÇÃO INVÁLIDA: URL do banco de dados não encontrada.' 
        };
    }

    try {
        // Simple ping to auth service
        const { error } = await supabase.auth.getSession();
        if (error) throw error;
        
        return { success: true };
    } catch (e: any) {
        console.error("Supabase Connection Error:", e);
        
        if (e.message === 'Failed to fetch' || e.name === 'TypeError') {
            return { 
                success: false, 
                message: 'SEM CONEXÃO: O sistema não conseguiu contactar o servidor. Verifique sua internet.' 
            };
        }

        return { 
            success: false, 
            message: `Erro ao conectar: ${e.message}` 
        };
    }
};
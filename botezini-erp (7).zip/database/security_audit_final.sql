
-- ==============================================================================
-- BOTEZINI ERP - FINAL SECURITY AUDIT & LOCKDOWN
-- ==============================================================================
-- Este script reinicia todas as políticas de segurança para um estado conhecido e seguro.
-- Execute no SQL Editor do Supabase.

-- 1. LIMPEZA DE POLÍTICAS ANTIGAS (DROP ALL)
-- Removemos qualquer política "permissiva" anterior para garantir Zero Trust.

DO $$ 
DECLARE 
    tbl text; 
BEGIN 
    FOR tbl IN 
        SELECT tablename FROM pg_tables WHERE schemaname = 'public' 
    LOOP 
        EXECUTE format('ALTER TABLE public.%I ENABLE ROW LEVEL SECURITY', tbl);
        EXECUTE format('DROP POLICY IF EXISTS "Acesso total publico %I" ON public.%I', tbl, tbl);
        EXECUTE format('DROP POLICY IF EXISTS "Enable read access for all users" ON public.%I', tbl);
        EXECUTE format('DROP POLICY IF EXISTS "Enable insert for authenticated users only" ON public.%I', tbl);
        EXECUTE format('DROP POLICY IF EXISTS "Enable update for users based on email" ON public.%I', tbl);
        EXECUTE format('DROP POLICY IF EXISTS "Enable delete for users based on email" ON public.%I', tbl);
    END LOOP; 
END $$;

-- 2. FUNÇÕES HELPER SEGURAS (SECURITY DEFINER)
-- Estas funções executam com privilégios de superusuário para checar a tabela 'profiles'
-- sem causar recursão infinita nas políticas da própria tabela 'profiles'.

CREATE OR REPLACE FUNCTION public.is_admin() RETURNS boolean AS $$
BEGIN
  RETURN EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin');
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE FUNCTION public.is_manager() RETURNS boolean AS $$
BEGIN
  RETURN EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role IN ('admin', 'manager'));
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE FUNCTION public.is_factory() RETURNS boolean AS $$
BEGIN
  RETURN EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'factory');
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 3. SEGURANÇA DA TABELA PROFILES (Identidade)

-- Remove políticas específicas antigas para recriar
DROP POLICY IF EXISTS "Users can read own profile" ON public.profiles;
DROP POLICY IF EXISTS "Admins can manage all profiles" ON public.profiles;

-- Política 1: Usuário vê seu próprio perfil
CREATE POLICY "Users can read own profile" ON public.profiles
    FOR SELECT USING (auth.uid() = id);

-- Política 2: Admins gerenciam tudo (usa função segura is_admin() para evitar loop)
CREATE POLICY "Admins can manage all profiles" ON public.profiles
    FOR ALL USING (public.is_admin());


-- 4. SEGURANÇA DAS TABELAS DE NEGÓCIO

-- --- TABELAS SENSÍVEIS (Financeiro, Clientes, Fornecedores, Orçamentos, Configs) ---
-- Regra: Apenas Admin e Manager podem ler/escrever. Fábrica não tem acesso nenhum.

-- Clientes
DROP POLICY IF EXISTS "Clients Manager Access" ON public.clients;
CREATE POLICY "Clients Manager Access" ON public.clients FOR ALL USING (public.is_manager());

-- Fornecedores
DROP POLICY IF EXISTS "Suppliers Manager Access" ON public.suppliers;
CREATE POLICY "Suppliers Manager Access" ON public.suppliers FOR ALL USING (public.is_manager());

-- Orçamentos
DROP POLICY IF EXISTS "Budgets Manager Access" ON public.budgets;
CREATE POLICY "Budgets Manager Access" ON public.budgets FOR ALL USING (public.is_manager());

-- Transações Financeiras (CRÍTICO)
DROP POLICY IF EXISTS "Transactions Manager Access" ON public.transactions;
CREATE POLICY "Transactions Manager Access" ON public.transactions FOR ALL USING (public.is_manager());

-- Configurações
DROP POLICY IF EXISTS "Settings Manager Access" ON public.app_settings;
CREATE POLICY "Settings Manager Access" ON public.app_settings FOR ALL USING (public.is_manager());


-- --- TABELAS HÍBRIDAS (Produção, Produtos) ---
-- Regra: Admin/Manager total. Fábrica tem acesso restrito.

-- Produtos
DROP POLICY IF EXISTS "Products Manager Access" ON public.products;
DROP POLICY IF EXISTS "Products Factory Read" ON public.products;

CREATE POLICY "Products Manager Access" ON public.products FOR ALL USING (public.is_manager());
CREATE POLICY "Products Factory Read" ON public.products FOR SELECT USING (public.is_factory());

-- Pedidos (Fábrica precisa ler para ver a fila e atualizar status)
DROP POLICY IF EXISTS "Orders Manager Access" ON public.orders;
DROP POLICY IF EXISTS "Orders Factory Read" ON public.orders;
DROP POLICY IF EXISTS "Orders Factory Update" ON public.orders;

CREATE POLICY "Orders Manager Access" ON public.orders FOR ALL USING (public.is_manager());

-- Fábrica pode ver pedidos
CREATE POLICY "Orders Factory Read" ON public.orders FOR SELECT USING (public.is_factory());

-- Fábrica pode atualizar pedidos (apenas colunas específicas idealmente, mas PG RLS é a nível de linha)
-- O frontend controla o que é enviado, mas o backend permite o UPDATE na linha se for fábrica.
CREATE POLICY "Orders Factory Update" ON public.orders FOR UPDATE USING (public.is_factory()) WITH CHECK (public.is_factory());

-- 5. REPARO DE TRIGGER DE USUÁRIO
-- Garante que novos usuários sempre tenham um perfil criado
CREATE OR REPLACE FUNCTION public.handle_new_user() 
RETURNS trigger AS $$
BEGIN
  INSERT INTO public.profiles (id, email, role, full_name)
  VALUES (new.id, new.email, 'factory', new.raw_user_meta_data->>'full_name')
  ON CONFLICT (id) DO NOTHING;
  RETURN new;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

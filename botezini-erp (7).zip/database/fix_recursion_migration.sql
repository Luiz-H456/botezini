
-- CORREÇÃO DE ERRO: 42P17 (Infinite Recursion)
-- Execute este script no SQL Editor do Supabase

-- 1. Definir funções de verificação como SECURITY DEFINER (Bypass RLS interno)
-- Isso permite que a função leia a tabela profiles sem acionar as políticas recursivamente
create or replace function public.is_admin() returns boolean as $$
begin
  return exists (select 1 from public.profiles where id = auth.uid() and role = 'admin');
end;
$$ language plpgsql security definer;

-- 2. Remover a política recursiva antiga (que causava o loop)
drop policy if exists "Admins can manage all profiles" on public.profiles;

-- 3. Criar a nova política usando a função segura
create policy "Admins can manage all profiles" on public.profiles
  for all using (public.is_admin());

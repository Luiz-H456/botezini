-- BOTEZINI ERP - MIGRATION V5
-- Adiciona a coluna de dias úteis de entrega na tabela de orçamentos

ALTER TABLE public.budgets ADD COLUMN IF NOT EXISTS "deliveryTimeDays" integer;

COMMENT ON COLUMN public.budgets."deliveryTimeDays" IS 'Número de dias úteis previstos para entrega';

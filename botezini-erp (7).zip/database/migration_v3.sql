-- BOTEZINI ERP - MIGRATION V3
-- Execute este script no SQL Editor do Supabase para adicionar as colunas de vinculação

-- Adiciona a coluna generatedOrderNumber na tabela budgets
ALTER TABLE public.budgets ADD COLUMN IF NOT EXISTS "generatedOrderNumber" text;

-- Adiciona a coluna budgetSerialNumber na tabela orders
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS "budgetSerialNumber" text;

-- Atualiza os comentários para documentação
COMMENT ON COLUMN public.budgets."generatedOrderNumber" IS 'Armazena o ID do pedido gerado a partir deste orçamento (ex: PED-BZ-2026-001)';
COMMENT ON COLUMN public.orders."budgetSerialNumber" IS 'Armazena o ID legível do orçamento que originou este pedido (ex: ORC-BZ-2026-001)';

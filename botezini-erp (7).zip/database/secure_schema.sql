
-- ==============================================================================
-- BOTEZINI ERP - SECURE PRODUCTION SCHEMA
-- ==============================================================================

-- 1. EXTENSIONS
create extension if not exists "uuid-ossp";

-- 2. TABLES & STRUCTURE

-- PROFILES (RBAC)
create table if not exists public.profiles (
  id uuid references auth.users on delete cascade not null primary key,
  email text,
  role text not null check (role in ('admin', 'manager', 'factory')),
  full_name text,
  updated_at timestamptz default now()
);

-- CLIENTS
create table if not exists public.clients (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references auth.users(id) default auth.uid(),
  "createdAt" timestamptz default now(),
  "updatedAt" timestamptz default now(),
  "companyName" text not null,
  "category" text,
  "cnpj" text,
  "contactPerson" text,
  "email" text,
  "phone" text,
  "address" text
);

-- SUPPLIERS
create table if not exists public.suppliers (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references auth.users(id) default auth.uid(),
  "createdAt" timestamptz default now(),
  "updatedAt" timestamptz default now(),
  "companyName" text not null,
  "category" text,
  "cnpj" text,
  "contactPerson" text,
  "email" text,
  "phone" text,
  "address" text
);

-- PRODUCTS
create table if not exists public.products (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references auth.users(id) default auth.uid(),
  "createdAt" timestamptz default now(),
  "updatedAt" timestamptz default now(),
  "name" text not null,
  "description" text,
  "sku" text,
  "category" text,
  "notes" text,
  "priceTier1" numeric,
  "priceTier2" numeric,
  "priceTier3" numeric
);

-- BUDGETS
create table if not exists public.budgets (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references auth.users(id) default auth.uid(),
  "createdAt" timestamptz default now(),
  "updatedAt" timestamptz default now(),
  "serialNumber" text not null,
  "clientId" uuid references public.clients(id), -- Normalized FK
  "date" text,
  "items" jsonb default '[]'::jsonb,
  "customizations" jsonb default '[]'::jsonb,
  "extras" jsonb default '[]'::jsonb,
  "subtotalItems" numeric default 0,
  "subtotalCustomizations" numeric default 0,
  "subtotalExtras" numeric default 0,
  "discount" numeric default 0,
  "totalAmount" numeric default 0,
  "downPaymentPercent" numeric default 0,
  "downPaymentValue" numeric default 0,
  "deliveryPaymentValue" numeric default 0,
  "validityDays" integer default 15,
  "deliveryTimeDays" integer,
  "notes" text,
  "status" text,
  "generatedOrderNumber" text
);

-- ORDERS
create table if not exists public.orders (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references auth.users(id) default auth.uid(),
  "createdAt" timestamptz default now(),
  "updatedAt" timestamptz default now(),
  "budgetId" uuid references public.budgets(id), -- Normalized FK
  "budgetSerialNumber" text,
  "orderNumber" text not null,
  "clientId" uuid references public.clients(id) not null, -- Normalized FK
  "items" jsonb default '[]'::jsonb,
  "customizations" jsonb default '[]'::jsonb,
  "extras" jsonb default '[]'::jsonb,
  "totalAmount" numeric default 0,
  "amountPaid" numeric default 0,
  "discount" numeric default 0,
  "deadline" text,
  "status" text,
  "paymentStatus" text,
  "productionStage" text default 'Aguardando Material'
);

-- TRANSACTIONS
create table if not exists public.transactions (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references auth.users(id) default auth.uid(),
  "createdAt" timestamptz default now(),
  "updatedAt" timestamptz default now(),
  "type" text not null,
  "description" text not null,
  "amount" numeric not null,
  "date" text not null,
  "category" text,
  "referenceId" text, -- Polymorphic reference (Order or Budget), kept as text or separate FKs
  "payee" text,
  "splits" jsonb default '[]'::jsonb,
  "costCenterId" text,
  "isPaid" boolean default true,
  "isRecurring" boolean default false,
  "recurrenceId" text
);

-- APP SETTINGS
create table if not exists public.app_settings (
  key text primary key,
  user_id uuid references auth.users(id) default auth.uid(),
  value jsonb
);

-- 3. INDEXES (Performance & Integrity)
create index if not exists idx_profiles_role on public.profiles(role);
create index if not exists idx_transactions_date on public.transactions("date");
create index if not exists idx_transactions_recurrence on public.transactions("recurrenceId");
create index if not exists idx_transactions_user on public.transactions(user_id);
create index if not exists idx_orders_stage on public.orders("productionStage");
create index if not exists idx_orders_number on public.orders("orderNumber");
create index if not exists idx_budgets_serial on public.budgets("serialNumber");

-- 4. SECURITY DEFINER FUNCTIONS (Prevents Recursion 42P17)
-- Critical: Runs with owner privileges to check roles without triggering RLS on profiles again.

create or replace function public.is_admin() returns boolean as $$
begin
  return exists (select 1 from public.profiles where id = auth.uid() and role = 'admin');
end;
$$ language plpgsql security definer;

create or replace function public.is_manager() returns boolean as $$
begin
  return exists (select 1 from public.profiles where id = auth.uid() and role in ('admin', 'manager'));
end;
$$ language plpgsql security definer;

create or replace function public.is_factory() returns boolean as $$
begin
  return exists (select 1 from public.profiles where id = auth.uid() and role = 'factory');
end;
$$ language plpgsql security definer;

-- 5. ROW LEVEL SECURITY (RLS) POLICIES

-- Enable RLS everywhere
alter table public.profiles enable row level security;
alter table public.clients enable row level security;
alter table public.suppliers enable row level security;
alter table public.products enable row level security;
alter table public.budgets enable row level security;
alter table public.orders enable row level security;
alter table public.transactions enable row level security;
alter table public.app_settings enable row level security;

-- Clean old policies to prevent conflicts
drop policy if exists "Public Access" on public.profiles;
drop policy if exists "Public Access" on public.clients;
drop policy if exists "Public Access" on public.suppliers;
drop policy if exists "Public Access" on public.products;
drop policy if exists "Public Access" on public.budgets;
drop policy if exists "Public Access" on public.orders;
drop policy if exists "Public Access" on public.transactions;
drop policy if exists "Public Access" on public.app_settings;

-- PROFILES
create policy "Read Own Profile" on public.profiles for select using (auth.uid() = id);
create policy "Admin Manage Profiles" on public.profiles for all using (public.is_admin());

-- CLIENTS, SUPPLIERS, BUDGETS
-- Managers can see all. Users can see what they created.
create policy "Manager Full Access Clients" on public.clients for all using (public.is_manager());
create policy "User View Own Clients" on public.clients for select using (auth.uid() = user_id);

create policy "Manager Full Access Suppliers" on public.suppliers for all using (public.is_manager());
create policy "User View Own Suppliers" on public.suppliers for select using (auth.uid() = user_id);

create policy "Manager Full Access Budgets" on public.budgets for all using (public.is_manager());
create policy "User View Own Budgets" on public.budgets for select using (auth.uid() = user_id);
create policy "User Insert Own Budgets" on public.budgets for insert with check (auth.uid() = user_id);

-- TRANSACTIONS (Sensitive)
-- Only Managers/Admins can see/edit transactions.
create policy "Manager Full Access Transactions" on public.transactions for all using (public.is_manager());

-- PRODUCTS
-- Factory needs read access to see product details
create policy "Manager Full Access Products" on public.products for all using (public.is_manager());
create policy "Factory Read Products" on public.products for select using (public.is_factory());

-- ORDERS
-- Factory needs to READ orders and UPDATE status
create policy "Manager Full Access Orders" on public.orders for all using (public.is_manager());
create policy "Factory Read Orders" on public.orders for select using (public.is_factory());
create policy "Factory Update Orders" on public.orders for update using (public.is_factory());

-- SETTINGS
create policy "Manager Full Access Settings" on public.app_settings for all using (public.is_manager());
create policy "Factory Read Settings" on public.app_settings for select using (public.is_factory());

-- 6. TRIGGERS (Automation)

-- Auto-create profile on signup
create or replace function public.handle_new_user() 
returns trigger as $$
begin
  insert into public.profiles (id, email, role, full_name)
  values (new.id, new.email, 'factory', new.raw_user_meta_data->>'full_name')
  on conflict (id) do nothing;
  return new;
end;
$$ language plpgsql security definer;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- Auto-update timestamps
create or replace function public.update_updated_at_column()
returns trigger as $$
begin
  new."updatedAt" = now();
  return new;
end;
$$ language plpgsql;

create trigger update_clients_modtime before update on public.clients for each row execute procedure public.update_updated_at_column();
create trigger update_products_modtime before update on public.products for each row execute procedure public.update_updated_at_column();
create trigger update_orders_modtime before update on public.orders for each row execute procedure public.update_updated_at_column();
create trigger update_transactions_modtime before update on public.transactions for each row execute procedure public.update_updated_at_column();


-- CORREÇÃO DEFINITIVA DE RECURSÃO INFINITA (ERRO 42P17)
-- Execute isso no SQL Editor do Supabase

-- 1. Redefinir funções de verificação com SECURITY DEFINER
-- Isso impede que a verificação de permissão acione a própria política de segurança num loop infinito.

CREATE OR REPLACE FUNCTION public.is_admin() RETURNS boolean AS $$
BEGIN
  RETURN EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin');
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE FUNCTION public.is_manager() RETURNS boolean AS $$
BEGIN
  RETURN EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role IN ('admin', 'manager'));
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE FUNCTION public.is_factory() RETURNS boolean AS $$
BEGIN
  RETURN EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'factory');
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 2. Recriar a política problemática na tabela Profiles

DROP POLICY IF EXISTS "Admins can manage all profiles" ON public.profiles;

CREATE POLICY "Admins can manage all profiles" ON public.profiles
  FOR ALL USING (public.is_admin());

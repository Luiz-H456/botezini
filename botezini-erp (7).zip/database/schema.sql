-- Execute este script no SQL Editor do Supabase

-- Habilitar extensão para UUIDs
create extension if not exists "uuid-ossp";

-- TABELA: CLIENTES
create table if not exists public.clients (
  id uuid primary key default uuid_generate_v4(),
  "createdAt" timestamptz default now(),
  "updatedAt" timestamptz default now(),
  "companyName" text not null,
  "category" text,
  "cnpj" text,
  "contactPerson" text,
  "email" text,
  "phone" text,
  "address" text
);

-- TABELA: FORNECEDORES
create table if not exists public.suppliers (
  id uuid primary key default uuid_generate_v4(),
  "createdAt" timestamptz default now(),
  "updatedAt" timestamptz default now(),
  "companyName" text not null,
  "category" text,
  "cnpj" text,
  "contactPerson" text,
  "email" text,
  "phone" text,
  "address" text
);

-- TABELA: PRODUTOS
create table if not exists public.products (
  id uuid primary key default uuid_generate_v4(),
  "createdAt" timestamptz default now(),
  "updatedAt" timestamptz default now(),
  "name" text not null,
  "description" text,
  "sku" text,
  "category" text,
  "notes" text,
  "priceTier1" numeric,
  "priceTier2" numeric,
  "priceTier3" numeric
);

-- TABELA: ORÇAMENTOS (Budgets)
create table if not exists public.budgets (
  id uuid primary key default uuid_generate_v4(),
  "createdAt" timestamptz default now(),
  "updatedAt" timestamptz default now(),
  "serialNumber" text not null,
  "clientId" text not null, 
  "date" text,
  "items" jsonb default '[]'::jsonb,
  "customizations" jsonb default '[]'::jsonb,
  "extras" jsonb default '[]'::jsonb,
  "subtotalItems" numeric default 0,
  "subtotalCustomizations" numeric default 0,
  "subtotalExtras" numeric default 0,
  "discount" numeric default 0,
  "totalAmount" numeric default 0,
  "downPaymentPercent" numeric default 0,
  "downPaymentValue" numeric default 0,
  "deliveryPaymentValue" numeric default 0,
  "validityDays" integer default 15,
  "notes" text,
  "status" text
);

-- TABELA: PEDIDOS (Orders)
create table if not exists public.orders (
  id uuid primary key default uuid_generate_v4(),
  "createdAt" timestamptz default now(),
  "updatedAt" timestamptz default now(),
  "budgetId" text,
  "orderNumber" text not null,
  "clientId" text not null,
  "items" jsonb default '[]'::jsonb,
  "customizations" jsonb default '[]'::jsonb,
  "extras" jsonb default '[]'::jsonb,
  "totalAmount" numeric default 0,
  "amountPaid" numeric default 0,
  "deadline" text,
  "status" text,
  "paymentStatus" text
);

-- TABELA: TRANSAÇÕES (Financeiro)
create table if not exists public.transactions (
  id uuid primary key default uuid_generate_v4(),
  "createdAt" timestamptz default now(),
  "updatedAt" timestamptz default now(),
  "type" text not null,
  "description" text not null,
  "amount" numeric not null,
  "date" text not null,
  "category" text,
  "referenceId" text,
  "payee" text,
  "splits" jsonb default '[]'::jsonb,
  "isPaid" boolean default true,
  "isRecurring" boolean default false,
  "recurrenceId" text
);

-- Migração segura: Adiciona a coluna se ela não existir (para bancos já criados)
alter table public.transactions 
add column if not exists "recurrenceId" text;

-- Indices para performance
create index if not exists idx_transactions_recurrence_id on public.transactions("recurrenceId");

-- TABELA: CONFIGURAÇÕES (Categorias)
create table if not exists public.app_settings (
  key text primary key,
  value jsonb
);

-- POLÍTICAS DE SEGURANÇA (RLS)
-- O padrão DROP IF EXISTS antes do CREATE garante que a política seja atualizada sem erro de duplicidade.

-- Clients
alter table public.clients enable row level security;
drop policy if exists "Acesso total publico clients" on public.clients;
create policy "Acesso total publico clients" on public.clients for all using (true);

-- Suppliers
alter table public.suppliers enable row level security;
drop policy if exists "Acesso total publico suppliers" on public.suppliers;
create policy "Acesso total publico suppliers" on public.suppliers for all using (true);

-- Products
alter table public.products enable row level security;
drop policy if exists "Acesso total publico products" on public.products;
create policy "Acesso total publico products" on public.products for all using (true);

-- Budgets
alter table public.budgets enable row level security;
drop policy if exists "Acesso total publico budgets" on public.budgets;
create policy "Acesso total publico budgets" on public.budgets for all using (true);

-- Orders
alter table public.orders enable row level security;
drop policy if exists "Acesso total publico orders" on public.orders;
create policy "Acesso total publico orders" on public.orders for all using (true);

-- Transactions
alter table public.transactions enable row level security;
drop policy if exists "Acesso total publico transactions" on public.transactions;
create policy "Acesso total publico transactions" on public.transactions for all using (true);

-- Settings
alter table public.app_settings enable row level security;
drop policy if exists "Acesso total publico settings" on public.app_settings;
create policy "Acesso total publico settings" on public.app_settings for all using (true);

-- BOTEZINI ERP - PHASE 3: ENTERPRISE FINANCIAL CORE
-- Execute this in Supabase SQL Editor

-- 1. BANK ACCOUNTS (Contas Bancárias e Caixas)
CREATE TABLE IF NOT EXISTS public.bank_accounts (
    id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id uuid REFERENCES auth.users(id) DEFAULT auth.uid(),
    "createdAt" timestamptz DEFAULT now(),
    "updatedAt" timestamptz DEFAULT now(),
    name text NOT NULL,
    type text NOT NULL CHECK (type IN ('checking', 'savings', 'cash', 'credit_card')),
    "bankName" text,
    "accountNumber" text,
    "initialBalance" numeric DEFAULT 0,
    "currentBalance" numeric DEFAULT 0,
    currency text DEFAULT 'BRL',
    "isActive" boolean DEFAULT true
);

-- 2. FINANCIAL CATEGORIES (Plano de Contas Hierárquico)
CREATE TABLE IF NOT EXISTS public.financial_categories (
    id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id uuid REFERENCES auth.users(id) DEFAULT auth.uid(),
    "createdAt" timestamptz DEFAULT now(),
    name text NOT NULL,
    type text NOT NULL CHECK (type IN ('income', 'expense')),
    "parentId" uuid REFERENCES public.financial_categories(id),
    code text, -- Ex: 1.01
    "isDeductible" boolean DEFAULT false -- Para DRE (Impostos/Devoluções)
);

-- 3. UPGRADE TRANSACTIONS TABLE
-- Adicionando colunas para suportar o novo motor financeiro
ALTER TABLE public.transactions ADD COLUMN IF NOT EXISTS "accountId" uuid REFERENCES public.bank_accounts(id);
ALTER TABLE public.transactions ADD COLUMN IF NOT EXISTS "categoryId" uuid REFERENCES public.financial_categories(id);
ALTER TABLE public.transactions ADD COLUMN IF NOT EXISTS "dueDate" date;
ALTER TABLE public.transactions ADD COLUMN IF NOT EXISTS "paymentDate" date;
ALTER TABLE public.transactions ADD COLUMN IF NOT EXISTS "clientId" uuid REFERENCES public.clients(id);
ALTER TABLE public.transactions ADD COLUMN IF NOT EXISTS "supplierId" uuid REFERENCES public.suppliers(id);
ALTER TABLE public.transactions ADD COLUMN IF NOT EXISTS "installmentNumber" integer;
ALTER TABLE public.transactions ADD COLUMN IF NOT EXISTS "totalInstallments" integer;

-- 4. FINANCIAL ALERTS (Already defined in Phase 2, ensuring existence)
CREATE TABLE IF NOT EXISTS public.financial_alerts (
    id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id uuid REFERENCES auth.users(id) DEFAULT auth.uid(),
    "createdAt" timestamptz DEFAULT now(),
    type text NOT NULL,
    severity text NOT NULL,
    title text NOT NULL,
    message text,
    "isRead" boolean DEFAULT false
);

-- 5. SEED DEFAULT DATA (Plano de Contas Básico)
-- Apenas insere se não existirem categorias
DO $$ 
BEGIN 
    IF NOT EXISTS (SELECT 1 FROM public.financial_categories) THEN
        -- Receitas
        INSERT INTO public.financial_categories (name, type, code) VALUES ('Venda de Produtos', 'income', '1.01');
        INSERT INTO public.financial_categories (name, type, code) VALUES ('Serviços', 'income', '1.02');
        
        -- Despesas Variáveis (CPV)
        INSERT INTO public.financial_categories (name, type, code, "isDeductible") VALUES ('Matéria Prima', 'expense', '2.01', true);
        INSERT INTO public.financial_categories (name, type, code, "isDeductible") VALUES ('Mão de Obra Direta', 'expense', '2.02', true);
        INSERT INTO public.financial_categories (name, type, code, "isDeductible") VALUES ('Embalagens', 'expense', '2.03', true);
        
        -- Despesas Fixas
        INSERT INTO public.financial_categories (name, type, code) VALUES ('Aluguel', 'expense', '3.01');
        INSERT INTO public.financial_categories (name, type, code) VALUES ('Energia Elétrica', 'expense', '3.02');
        INSERT INTO public.financial_categories (name, type, code) VALUES ('Pessoal Administrativo', 'expense', '3.03');
        INSERT INTO public.financial_categories (name, type, code) VALUES ('Marketing', 'expense', '3.04');
        INSERT INTO public.financial_categories (name, type, code) VALUES ('Impostos', 'expense', '3.05');
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM public.bank_accounts) THEN
        INSERT INTO public.bank_accounts (name, type, "currentBalance") VALUES ('Caixa Principal', 'cash', 0);
        INSERT INTO public.bank_accounts (name, type, "currentBalance") VALUES ('Banco Itaú', 'checking', 0);
    END IF;
END $$;

-- 6. RLS POLICIES
ALTER TABLE public.bank_accounts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.financial_categories ENABLE ROW LEVEL SECURITY;

-- Manager Access
CREATE POLICY "Manager Access Accounts" ON public.bank_accounts FOR ALL USING (public.is_manager());
CREATE POLICY "Manager Access Categories" ON public.financial_categories FOR ALL USING (public.is_manager());

-- Factory Read-Only (Opicional, geralmente factory não vê banco)
-- CREATE POLICY "Factory Read Categories" ON public.financial_categories FOR SELECT USING (public.is_factory());

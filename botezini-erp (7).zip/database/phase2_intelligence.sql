
-- BOTEZINI ERP - PHASE 2: INTELLIGENCE MODULE
-- Run this in Supabase SQL Editor

-- 1. CASH FLOW PROJECTIONS (SNAPSHOTS)
create table if not exists public.cash_flow_projections (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references auth.users(id) default auth.uid(),
  "createdAt" timestamptz default now(),
  "projectionDate" date not null,
  "data" jsonb not null, -- Stores DailyProjection[]
  "scenarioName" text default 'Base'
);

-- 2. CLIENT RISK PROFILES
create table if not exists public.client_risk_profiles (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references auth.users(id) default auth.uid(),
  "clientId" uuid references public.clients(id) not null,
  "score" numeric default 100,
  "riskLevel" text default 'low',
  "avgDelayDays" numeric default 0,
  "lastUpdated" timestamptz default now()
);

-- 3. FINANCIAL ALERTS LOG
create table if not exists public.financial_alerts (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references auth.users(id) default auth.uid(),
  "createdAt" timestamptz default now(),
  "type" text not null,
  "severity" text not null,
  "title" text not null,
  "message" text,
  "isRead" boolean default false
);

-- 4. RLS POLICIES (Mirroring core security)
alter table public.cash_flow_projections enable row level security;
alter table public.client_risk_profiles enable row level security;
alter table public.financial_alerts enable row level security;

-- Manager Policies
create policy "Manager Access Projections" on public.cash_flow_projections for all using (public.is_manager());
create policy "Manager Access Risks" on public.client_risk_profiles for all using (public.is_manager());
create policy "Manager Access Alerts" on public.financial_alerts for all using (public.is_manager());

-- Factory Policies (Read Alerts Only)
create policy "Factory Read Alerts" on public.financial_alerts for select using (public.is_factory());

-- BOTEZINI ERP - MIGRATION V6
-- Refatoração da Produção: Adicionar status de produção no nível do Pedido

-- 1. Adicionar coluna productionStage
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS "productionStage" text;

-- 2. Migrar dados existentes (Extrair do primeiro item do JSON, ou definir como 'Corte' se falhar)
UPDATE public.orders
SET "productionStage" = COALESCE(items->0->>'productionStage', 'Corte')
WHERE "productionStage" IS NULL;

-- 3. Definir valor padrão para novos inserts
ALTER TABLE public.orders ALTER COLUMN "productionStage" SET DEFAULT 'Aguardando Material';

-- 4. Criar índice para performance do Kanban
CREATE INDEX IF NOT EXISTS idx_orders_production_stage ON public.orders("productionStage");

-- 5. Comentário
COMMENT ON COLUMN public.orders."productionStage" IS 'Estágio atual do pedido no Kanban de produção (Ex: Corte, Costura, etc)';

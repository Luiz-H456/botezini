-- BOTEZINI ERP - MIGRATION V4
-- Adiciona coluna de desconto aos pedidos para manter consistência com o orçamento

ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS "discount" numeric DEFAULT 0;

COMMENT ON COLUMN public.orders."discount" IS 'Valor do desconto aplicado no momento da conversão do orçamento';

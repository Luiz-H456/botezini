-- BOTEZINI ERP - REFATORAÇÃO CENTROS DE CUSTO
-- Execute este script no SQL Editor do Supabase

-- 1. Criar a tabela
CREATE TABLE IF NOT EXISTS public.cost_centers (
    id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id uuid REFERENCES auth.users(id) DEFAULT auth.uid(),
    "createdAt" timestamptz DEFAULT now(),
    "updatedAt" timestamptz DEFAULT now(),
    name text NOT NULL,
    type text NOT NULL, -- 'production', 'administrative', etc
    color text,
    "budgetLimit" numeric DEFAULT 0,
    "isActive" boolean DEFAULT true,
    categories text[] DEFAULT '{}' -- Array de strings para sub-categorias
);

-- 2. Habilitar RLS
ALTER TABLE public.cost_centers ENABLE ROW LEVEL SECURITY;

-- 3. Políticas de Acesso (Seguindo o padrão do sistema: Managers gerenciam, Factory lê)
DROP POLICY IF EXISTS "Manager Full Access CostCenters" ON public.cost_centers;
CREATE POLICY "Manager Full Access CostCenters" ON public.cost_centers 
    FOR ALL USING (public.is_manager());

DROP POLICY IF EXISTS "Factory Read CostCenters" ON public.cost_centers;
CREATE POLICY "Factory Read CostCenters" ON public.cost_centers 
    FOR SELECT USING (public.is_factory());

-- 4. Inserir dados padrão (Se a tabela estiver vazia)
INSERT INTO public.cost_centers (name, type, color, "budgetLimit", categories)
SELECT 'Produção', 'production', '#3b82f6', 50000, ARRAY['Matéria Prima', 'Mão de Obra', 'Manutenção Máquinas', 'Insumos', 'Embalagens']
WHERE NOT EXISTS (SELECT 1 FROM public.cost_centers);

INSERT INTO public.cost_centers (name, type, color, "budgetLimit", categories)
SELECT 'Administrativo', 'administrative', '#8b5cf6', 15000, ARRAY['Aluguel', 'Energia Elétrica', 'Água', 'Internet', 'Limpeza', 'Salários ADM']
WHERE NOT EXISTS (SELECT 1 FROM public.cost_centers WHERE name = 'Administrativo');

INSERT INTO public.cost_centers (name, type, color, "budgetLimit", categories)
SELECT 'Comercial', 'commercial', '#10b981', 10000, ARRAY['Marketing', 'Comissões', 'Viagens', 'Brindes', 'Software']
WHERE NOT EXISTS (SELECT 1 FROM public.cost_centers WHERE name = 'Comercial');

INSERT INTO public.cost_centers (name, type, color, "budgetLimit", categories)
SELECT 'Financeiro', 'financial', '#f59e0b', 5000, ARRAY['Impostos', 'Tarifas Bancárias', 'Contabilidade', 'Empréstimos']
WHERE NOT EXISTS (SELECT 1 FROM public.cost_centers WHERE name = 'Financeiro');

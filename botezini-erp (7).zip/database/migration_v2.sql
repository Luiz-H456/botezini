-- BOTEZINI ERP - MIGRATION V2
-- Execute este script no SQL Editor do Supabase para habilitar a nova conversão de pedidos

-- 1. ÍNDICES DE PERFORMANCE (CRITICO PARA idService)
-- Estes índices garantem que a busca pelo "último ID gerado" (Ex: PED-BZ-2026-005) seja instantânea.
CREATE INDEX IF NOT EXISTS idx_budgets_serial_number ON public.budgets("serialNumber");
CREATE INDEX IF NOT EXISTS idx_orders_order_number ON public.orders("orderNumber");

-- 2. ÍNDICE DE RELACIONAMENTO
-- Acelera o cruzamento de dados na tela de Orçamentos para saber qual virou Pedido (Etiqueta Verde)
CREATE INDEX IF NOT EXISTS idx_orders_budget_id ON public.orders("budgetId");

-- 3. GARANTIA DE COLUNAS
-- Adiciona colunas caso tenham sido esquecidas na criação inicial
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS "budgetId" text;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS "deadline" text;
ALTER TABLE public.budgets ADD COLUMN IF NOT EXISTS "validityDays" integer DEFAULT 15;

-- 4. LIMPEZA DE DADOS ANTIGOS (Sanitização)
-- Define status padrão para registros antigos que possam estar como NULL para não quebrar a UI
UPDATE public.budgets SET status = 'Draft' WHERE status IS NULL OR status = '';
UPDATE public.orders SET status = 'Pendente' WHERE status IS NULL OR status = '';

-- 5. CONFIGURAÇÃO DE RLS (Reforço de Segurança)
-- Garante que as novas políticas se apliquem corretamente
ALTER TABLE public.budgets ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;

-- 6. COMENTÁRIOS DE DOCUMENTAÇÃO
COMMENT ON COLUMN public.orders."budgetId" IS 'Referencia o ID (UUID) da tabela budgets. Usado para rastreabilidade.';
COMMENT ON COLUMN public.orders."orderNumber" IS 'ID legível (SKU) do pedido. Ex: PED-BZ-2026-001';

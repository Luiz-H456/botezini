// Arquivo obsoleto - Removido durante limpeza de código.
export {};
import React from 'react';
import { LucideIcon } from 'lucide-react';
import { formatCurrency } from '../utils';

interface MetricCardProps {
  title: string;
  value: number;
  target?: number;
  icon: LucideIcon;
  variant?: 'default' | 'highlight';
  trend?: number;
  inverseTrend?: boolean;
  subtext?: string;
  color?: string;
}

const MetricCard: React.FC<MetricCardProps> = ({ 
  title, 
  value, 
  target, 
  icon: Icon, 
  variant = 'default',
  trend,
  inverseTrend,
  subtext,
  color
}) => {
  const isHighlight = variant === 'highlight';
  
  // Progress for target bar
  const progress = target ? Math.min((value / target) * 100, 100) : 0;
  
  return (
    <div className={`p-6 rounded-sm relative overflow-hidden group hover:border-zinc-700 transition-colors bg-zinc-900 border ${isHighlight ? 'border-zinc-700' : 'border-zinc-800'}`}>
      <div className="flex justify-between items-start mb-4">
        <div className={`p-2 bg-zinc-950 rounded-sm border border-zinc-800 ${color || (isHighlight ? 'text-emerald-500' : 'text-zinc-400')}`}>
          <Icon size={20} />
        </div>
        {trend !== undefined && (
             <div className={`flex items-center gap-1 text-xs font-bold bg-zinc-950 px-2 py-1 rounded-sm border border-zinc-800 ${
                 (inverseTrend ? trend < 0 : trend >= 0) ? 'text-emerald-500' : 'text-red-500'
             }`}>
                 {trend > 0 ? '+' : ''}{trend.toFixed(1)}%
             </div>
        )}
      </div>
      
      <p className="text-zinc-500 text-xs font-bold uppercase tracking-wider mb-1">{title}</p>
      <h3 className={`text-2xl font-bold mb-1 ${isHighlight ? 'text-white' : 'text-zinc-200'}`}>
          {formatCurrency(value)}
      </h3>
      
      {subtext && <p className="text-[10px] text-zinc-600">{subtext}</p>}

      {/* Target Progress Bar */}
      {target !== undefined && target > 0 && (
          <div className="mt-3">
              <div className="flex justify-between text-[10px] mb-1">
                  <span className="text-zinc-500">Meta: {formatCurrency(target)}</span>
                  <span className={value >= target ? 'text-emerald-500 font-bold' : 'text-zinc-500'}>
                      {((value/target)*100).toFixed(0)}%
                  </span>
              </div>
              <div className="w-full bg-zinc-950 h-1.5 rounded-full overflow-hidden border border-zinc-800">
                  <div 
                    className={`h-full rounded-full ${value >= target ? 'bg-emerald-500' : 'bg-blue-500'}`} 
                    style={{ width: `${progress}%` }}
                  ></div>
              </div>
          </div>
      )}
    </div>
  );
};

export default MetricCard;
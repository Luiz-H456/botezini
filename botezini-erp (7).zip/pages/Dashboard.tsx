
import React, { useEffect, useState, useMemo } from 'react';
import { storageService } from '../services/storage'; 
import { Transaction, FinancialAlert, DRELine, CostCenter, CompanyProfile, Product, Order, Client } from '../types';
import { formatCurrency, getTodayStr, addMonths, countBusinessDays, formatDate } from '../utils';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, ComposedChart, ReferenceLine } from 'recharts';
import { TrendingUp, TrendingDown, DollarSign, Activity, AlertTriangle, Calendar, Download, PieChart as PieIcon, ArrowRight, Filter, AlertCircle, Clock, CheckCircle, Target, ShoppingBag, Brain, Sparkles, X, ChevronRight, Scale, Briefcase, ChevronDown, ChevronUp } from 'lucide-react';
import { pdfService } from '../services/pdfService';

// --- THEME CONSTANTS ---
const COLORS = {
  gold: '#C9A24D',
  emerald: '#10b981',
  blue: '#3b82f6',
  red: '#ef4444',
  zinc: '#71717a',
  bg: '#18181b', // Zinc 900
  cardBg: '#09090b', // Zinc 950
};

interface Props {
    onNavigate?: (view: 'orders' | 'budgets' | 'finance', searchTerm?: string) => void;
}

const Dashboard: React.FC<Props> = ({ onNavigate }) => {
  // --- DATA STATE ---
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [clients, setClients] = useState<Client[]>([]);
  const [companyProfile, setCompanyProfile] = useState<CompanyProfile | null>(null);
  const [costCenters, setCostCenters] = useState<CostCenter[]>([]);
  
  // --- UI STATE ---
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'overview' | 'dre' | 'costs' | 'products'>('overview');
  const [aiAdvice, setAiAdvice] = useState<string>('');
  const [isGeneratingAi, setIsGeneratingAi] = useState(false);
  const [isAiExpanded, setIsAiExpanded] = useState(true);

  // --- NOTIFICATION SYSTEM (No Browser Alerts) ---
  const [toast, setToast] = useState<{ visible: boolean; message: string; type: 'success' | 'info' | 'error' }>({ 
      visible: false, message: '', type: 'success' 
  });

  useEffect(() => {
    const fetchData = async () => {
        setIsLoading(true);
        try {
            const [txs, ords, prods, clis, profile, ccenters] = await Promise.all([
                storageService.getTransactions(),
                storageService.getOrders(),
                storageService.getProducts(),
                storageService.getClients(),
                storageService.getCompanyProfile(),
                storageService.getCostCenters()
            ]);
            setTransactions(txs);
            setOrders(ords);
            setProducts(prods);
            setClients(clis);
            setCompanyProfile(profile);
            setCostCenters(ccenters);
        } catch (e) {
            console.error(e);
            showToast('Erro ao carregar dados. Verifique sua conexão.', 'error');
        } finally {
            setIsLoading(false);
        }
    };
    fetchData();
  }, []);

  const showToast = (message: string, type: 'success' | 'info' | 'error' = 'success') => {
      setToast({ visible: true, message, type });
      setTimeout(() => setToast(prev => ({ ...prev, visible: false })), 4000);
  };

  const todayStr = getTodayStr();
  const currentMonthStr = todayStr.substring(0, 7);

  // --- ANALYTICS ENGINE ---

  // 1. Financial Projection & Receivables
  const { receivables, cashFlowProjection } = useMemo(() => {
      // Receivables
      const recs = transactions
        .filter(t => t.type === 'income' && !t.isPaid)
        .map(t => {
            const daysDiff = countBusinessDays(todayStr, t.date);
            let status: 'ok' | 'due_soon' | 'overdue' = 'ok';
            if (daysDiff < 0) status = 'overdue'; else if (daysDiff <= 5) status = 'due_soon';
            return { ...t, daysDiff, status };
        }).sort((a, b) => a.date.localeCompare(b.date));

      // Projection
      let currentBalance = 0; 
      const sortedTxs = [...transactions].sort((a, b) => a.date.localeCompare(b.date));
      const startRange = addMonths(todayStr, -1);
      const endRange = addMonths(todayStr, 3);
      
      const grouped: Record<string, any> = {};
      sortedTxs.forEach(t => {
          if (t.date < startRange || t.date > endRange) return;
          if (!grouped[t.date]) grouped[t.date] = { date: t.date, income: 0, expense: 0 };
          if (t.type === 'income') grouped[t.date].income += t.amount; else grouped[t.date].expense += t.amount;
      });

      const proj = Object.values(grouped).sort((a: any, b: any) => a.date.localeCompare(b.date)).map((day: any) => {
          currentBalance += (day.income - day.expense);
          return { ...day, balance: currentBalance, displayDate: day.date.substring(8, 10) + '/' + day.date.substring(5, 7) };
      });

      return { receivables: recs, cashFlowProjection: proj };
  }, [transactions]);

  // 2. DRE Logic
  const dreData = useMemo((): DRELine[] => {
      const monthTxs = transactions.filter(t => t.date.startsWith(currentMonthStr));
      const grossRevenue = monthTxs.filter(t => t.type === 'income').reduce((acc, t) => acc + t.amount, 0);
      
      const actualTaxes = monthTxs.filter(t => t.category.includes('Impostos')).reduce((acc, t) => acc + t.amount, 0);
      const taxRate = companyProfile?.defaultTaxRate || 0;
      const estimatedTaxes = grossRevenue * (taxRate / 100);
      const finalTaxValue = actualTaxes > 0 ? actualTaxes : estimatedTaxes;
      
      const netRevenue = grossRevenue - finalTaxValue;

      const prodCC = costCenters.find(cc => cc.type === 'production');
      const cogs = monthTxs.filter(t => t.type === 'expense' && ((prodCC && t.costCenterId === prodCC.id) || t.category === 'Matéria-Prima')).reduce((acc, t) => acc + t.amount, 0);
      
      const grossProfit = netRevenue - cogs;

      const opExpenses = monthTxs.filter(t => t.type === 'expense' && (!prodCC || t.costCenterId !== prodCC.id) && !t.category.includes('Impostos')).reduce((acc, t) => acc + t.amount, 0);
      
      const ebitda = grossProfit - opExpenses; 
      
      return [
          { label: 'RECEITA BRUTA', value: grossRevenue, level: 1, percent: 100 },
          { label: '(-) Deduções / Impostos', value: finalTaxValue, isDeduction: true, level: 2, percent: grossRevenue ? (finalTaxValue/grossRevenue)*100 : 0 },
          { label: '(=) RECEITA LÍQUIDA', value: netRevenue, level: 1, isTotal: true, percent: grossRevenue ? (netRevenue/grossRevenue)*100 : 0 },
          { label: '(-) CPV (Custo Produto)', value: cogs, isDeduction: true, level: 2, percent: grossRevenue ? (cogs/grossRevenue)*100 : 0 },
          { label: '(=) LUCRO BRUTO', value: grossProfit, level: 1, isTotal: true, percent: grossRevenue ? (grossProfit/grossRevenue)*100 : 0 },
          { label: '(-) Despesas Operacionais', value: opExpenses, isDeduction: true, level: 2, percent: grossRevenue ? (opExpenses/grossRevenue)*100 : 0 },
          { label: '(=) EBITDA', value: ebitda, level: 1, isTotal: true, percent: grossRevenue ? (ebitda/grossRevenue)*100 : 0 },
          { label: '(=) LUCRO LÍQUIDO', value: ebitda, level: 1, isTotal: true, percent: grossRevenue ? (ebitda/grossRevenue)*100 : 0 },
      ];
  }, [transactions, companyProfile, costCenters]);

  // 3. Products & Market Analytics
  const productAnalytics = useMemo(() => {
      const prodStats: Record<string, { id: string, name: string, qty: number }> = {};
      const clientStats: Record<string, { id: string, name: string, revenue: number, count: number }> = {};

      products.forEach(p => { prodStats[p.id] = { id: p.id, name: p.name, qty: 0 }; });

      orders.forEach(order => {
          order.items.forEach(item => {
              if (prodStats[item.productId]) prodStats[item.productId].qty += item.quantity;
          });
          if (!clientStats[order.clientId]) {
              const client = clients.find(c => c.id === order.clientId);
              clientStats[order.clientId] = { id: order.clientId, name: client?.companyName || 'Unknown', revenue: 0, count: 0 };
          }
          clientStats[order.clientId].revenue += order.totalAmount;
          clientStats[order.clientId].count += 1;
      });

      return {
          topProducts: Object.values(prodStats).sort((a, b) => b.qty - a.qty).slice(0, 5),
          bottomProducts: Object.values(prodStats).filter(p => p.qty === 0 || p.qty < 5).slice(0, 5),
          topClients: Object.values(clientStats).sort((a, b) => b.revenue - a.revenue).slice(0, 5)
      };
  }, [orders, products, clients]);

  // 4. Alerts
  const alerts = useMemo((): FinancialAlert[] => {
      const list: FinancialAlert[] = [];
      const grossMargin = dreData.find(d => d.label === '(=) LUCRO BRUTO')?.percent || 0;
      const minBalance = cashFlowProjection.filter(d => d.date > todayStr).map(d => d.balance).reduce((min, val) => Math.min(min, val), 0);
      
      if (minBalance < 0) list.push({ id: '1', type: 'critical', title: 'Risco de Caixa', message: `Projeção negativa (${formatCurrency(minBalance)}) detectada.`, action: 'Ver Fluxo' });
      if (grossMargin > 0 && grossMargin < 40) list.push({ id: '2', type: 'warning', title: 'Margem Bruta Baixa', message: `Margem de ${grossMargin.toFixed(1)}% está abaixo do ideal (45%).`, action: 'Ver Custos' });
      if (receivables.filter(r => r.status === 'overdue').length > 0) list.push({ id: '3', type: 'warning', title: 'Inadimplência', message: `${receivables.filter(r => r.status === 'overdue').length} pagamentos vencidos.`, action: 'Cobrar' });
      return list;
  }, [dreData, cashFlowProjection, receivables]);

  // --- ACTIONS ---
  const handleExportExecutiveReport = async () => {
      try {
        const topExpenses = transactions
            .filter(t => t.date.startsWith(currentMonthStr) && t.type === 'expense')
            .reduce((acc: Record<string, number>, t) => {
                const cat = t.category || 'Outros';
                acc[cat] = (acc[cat] || 0) + t.amount;
                return acc;
            }, {} as Record<string, number>);
        
        const sortedExpenses = Object.entries(topExpenses).map(([name, value]) => ({ name, value: value as number })).sort((a, b) => b.value - a.value);
        
        const kpis = {
            revenue: dreData.find(d => d.label === '(=) RECEITA LÍQUIDA')?.value || 0,
            expenses: dreData.find(d => d.label === '(-) Despesas Operacionais')?.value || 0,
            ebitda: dreData.find(d => d.label === '(=) EBITDA')?.value || 0,
            result: dreData.find(d => d.label === '(=) LUCRO LÍQUIDO')?.value || 0,
        };
        
        pdfService.generateExecutiveReport(dreData, currentMonthStr, await storageService.getCompanyProfile(), sortedExpenses, kpis);
        showToast('Relatório exportado com sucesso!', 'success');
      } catch (e) {
          showToast('Falha ao gerar relatório.', 'error');
      }
  };

  const generateAiInsights = async () => {
      showToast('Inteligência Artificial temporariamente indisponível.', 'info');
      // IA desabilitada temporariamente para estabilidade
  };

  // KPI Helpers
  const kpiRevenue = dreData.find(d => d.label === '(=) RECEITA LÍQUIDA')?.value || 0;
  const kpiExpenses = Math.abs(dreData.find(d => d.label === '(-) Despesas Operacionais')?.value || 0) + Math.abs(dreData.find(d => d.label === '(-) CPV / Custos Diretos')?.value || 0);
  const kpiProfit = dreData.find(d => d.label === '(=) LUCRO LÍQUIDO')?.value || 0;

  if (isLoading) return <div className="flex h-screen items-center justify-center text-zinc-500 bg-zinc-950"><Activity className="mr-2 animate-spin text-gold-500" /> Carregando BOTEZINI ERP...</div>;

  return (
    <div className="space-y-8 pb-20 animate-in fade-in duration-700">
        
        {/* --- HERO HEADER --- */}
        <div className="sticky top-0 z-30 bg-zinc-950/80 backdrop-blur-md border-b border-zinc-800 pb-4 pt-2 -mx-8 px-8 transition-all">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <div>
                    <h1 className="text-2xl font-bold text-white tracking-tight flex items-center gap-3">
                        <div className="p-2 bg-gold-500/10 rounded-lg border border-gold-500/20 text-gold-500"><Activity size={20} /></div>
                        CENTRO DE COMANDO
                    </h1>
                    <p className="text-zinc-500 text-xs mt-1 font-mono uppercase tracking-widest pl-1">
                        Visão Estratégica • {new Date().toLocaleString('pt-BR', { month: 'long', year: 'numeric' })}
                    </p>
                </div>
                
                {/* Modern Segmented Control */}
                <div className="flex bg-zinc-900/50 p-1 rounded-lg border border-zinc-800 backdrop-blur-sm">
                    {(['overview', 'dre', 'products'] as const).map((tab) => (
                        <button 
                            key={tab}
                            onClick={() => setActiveTab(tab)} 
                            className={`
                                px-6 py-2 text-xs font-bold uppercase rounded-md transition-all duration-300 relative overflow-hidden
                                ${activeTab === tab ? 'text-white shadow-lg shadow-black/50 bg-zinc-800' : 'text-zinc-500 hover:text-zinc-300 hover:bg-zinc-800/50'}
                            `}
                        >
                            {tab === 'overview' ? 'Visão 360º' : tab === 'dre' ? 'DRE Gerencial' : 'Produtos & Mercado'}
                            {activeTab === tab && <div className="absolute bottom-0 left-0 w-full h-0.5 bg-gold-500/50"></div>}
                        </button>
                    ))}
                </div>
            </div>
        </div>

        {/* --- ALERTS BANNER --- */}
        {alerts.length > 0 && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {alerts.map(alert => (
                    <div key={alert.id} className={`group relative p-4 rounded-lg border flex gap-4 items-start overflow-hidden transition-all duration-300 hover:shadow-lg hover:translate-y-[-2px] ${alert.type === 'critical' ? 'bg-red-950/10 border-red-900/30 hover:border-red-500/50' : 'bg-amber-950/10 border-amber-900/30 hover:border-amber-500/50'}`}>
                        <div className={`p-2 rounded-full ${alert.type === 'critical' ? 'bg-red-500/10 text-red-500' : 'bg-amber-500/10 text-amber-500'}`}>
                            {alert.type === 'critical' ? <AlertTriangle size={20} /> : <AlertCircle size={20} />}
                        </div>
                        <div className="flex-1">
                            <h4 className={`text-sm font-bold uppercase tracking-wider ${alert.type === 'critical' ? 'text-red-400' : 'text-amber-400'}`}>{alert.title}</h4>
                            <p className="text-xs text-zinc-400 mt-1 leading-relaxed">{alert.message}</p>
                        </div>
                        {/* Glow Effect */}
                        <div className={`absolute -right-4 -bottom-4 w-24 h-24 rounded-full blur-3xl opacity-20 pointer-events-none ${alert.type === 'critical' ? 'bg-red-500' : 'bg-amber-500'}`}></div>
                    </div>
                ))}
            </div>
        )}

        {/* --- VIEW: OVERVIEW --- */}
        {activeTab === 'overview' && (
            <div className="space-y-8">
                {/* KPI CARDS */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                    <DashboardCard 
                        title="Faturamento" 
                        value={kpiRevenue} 
                        target={companyProfile?.revenueGoal} 
                        icon={TrendingUp} 
                        color="emerald" 
                    />
                    <DashboardCard 
                        title="Despesas Totais" 
                        value={kpiExpenses} 
                        target={companyProfile?.expenseLimit} 
                        icon={TrendingDown} 
                        color="red" 
                        inverse
                    />
                    <DashboardCard 
                        title="Recebíveis" 
                        value={receivables.reduce((acc, r) => acc + r.amount, 0)} 
                        icon={DollarSign} 
                        color="blue" 
                        action={() => onNavigate && onNavigate('finance', 'income')}
                    />
                    <DashboardCard 
                        title="Resultado Líquido" 
                        value={kpiProfit} 
                        icon={Scale} 
                        color={kpiProfit >= 0 ? "gold" : "red"} 
                        isMain
                    />
                </div>

                {/* MAIN CHART & SIDEBAR */}
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    {/* CHART */}
                    <div className="lg:col-span-2 bg-zinc-900/30 border border-zinc-800/50 rounded-xl p-6 backdrop-blur-sm relative overflow-hidden group hover:border-zinc-700/50 transition-colors">
                        <div className="flex justify-between items-center mb-6">
                            <div>
                                <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2"><Calendar size={16} className="text-blue-500"/> Projeção de Caixa</h3>
                                <p className="text-[10px] text-zinc-500">Próximos 90 dias</p>
                            </div>
                        </div>
                        <div className="h-[350px] w-full">
                            <ResponsiveContainer width="100%" height="100%">
                                <ComposedChart data={cashFlowProjection.filter((_, i) => i % 2 === 0)}>
                                    <defs>
                                        <linearGradient id="colorBalance" x1="0" y1="0" x2="0" y2="1">
                                            <stop offset="5%" stopColor={COLORS.blue} stopOpacity={0.3}/>
                                            <stop offset="95%" stopColor={COLORS.blue} stopOpacity={0}/>
                                        </linearGradient>
                                    </defs>
                                    <CartesianGrid strokeDasharray="3 3" stroke="#27272a" vertical={false} />
                                    <XAxis dataKey="displayDate" stroke="#52525b" fontSize={10} tickLine={false} axisLine={false} minTickGap={30} />
                                    <YAxis stroke="#52525b" fontSize={10} tickLine={false} axisLine={false} tickFormatter={(val) => `R$${val/1000}k`} />
                                    <Tooltip 
                                        contentStyle={{ backgroundColor: COLORS.cardBg, borderColor: '#3f3f46', borderRadius: '8px', fontSize: '12px', boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.5)' }} 
                                        itemStyle={{ padding: 0 }}
                                        formatter={(value: number) => formatCurrency(value)} 
                                        cursor={{ stroke: 'rgba(255,255,255,0.1)', strokeWidth: 1 }}
                                    />
                                    <ReferenceLine y={0} stroke="#ef4444" strokeDasharray="3 3" strokeOpacity={0.5} />
                                    <Area type="monotone" dataKey="balance" stroke={COLORS.blue} fill="url(#colorBalance)" strokeWidth={3} name="Saldo Acumulado" />
                                    <Bar dataKey="income" fill={COLORS.emerald} opacity={0.4} barSize={6} radius={[4, 4, 0, 0]} name="Entradas" />
                                    <Bar dataKey="expense" fill={COLORS.red} opacity={0.4} barSize={6} radius={[4, 4, 0, 0]} name="Saídas" />
                                </ComposedChart>
                            </ResponsiveContainer>
                        </div>
                    </div>

                    {/* RIGHT COLUMN: AI & RECEIVABLES */}
                    <div className="flex flex-col gap-6">
                        
                        {/* AI COMMAND CENTER */}
                        <div className={`relative overflow-hidden rounded-xl border transition-all duration-500 ${isAiExpanded ? 'bg-zinc-900/80 border-gold-500/30 shadow-2xl shadow-gold-900/10' : 'bg-zinc-900/30 border-zinc-800 hover:border-gold-500/20'}`}>
                            {/* Header */}
                            <div className="p-4 flex items-center justify-between border-b border-white/5 bg-gradient-to-r from-gold-900/10 to-transparent">
                                <h3 className="text-xs font-bold text-gold-500 uppercase tracking-widest flex items-center gap-2">
                                    <Brain size={16} /> Inteligência Botezini
                                </h3>
                                <button onClick={() => setIsAiExpanded(!isAiExpanded)} className="text-zinc-500 hover:text-white transition-colors">
                                    {isAiExpanded ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
                                </button>
                            </div>

                            {/* Content */}
                            <div className={`p-5 transition-all ${isAiExpanded ? 'block' : 'hidden'}`}>
                                {aiAdvice ? (
                                    <div className="space-y-4">
                                        <div className="text-xs text-zinc-300 leading-relaxed font-mono bg-black/30 p-3 rounded border border-white/5">
                                            {aiAdvice.split('\n').map((line, i) => (
                                                <p key={i} className={`min-h-[1rem] ${line.includes('**') ? 'text-white font-bold' : ''}`}>
                                                    {line.replace(/\*\*/g, '')}
                                                </p>
                                            ))}
                                        </div>
                                        <button 
                                            onClick={() => setAiAdvice('')} 
                                            className="w-full text-[10px] uppercase font-bold text-zinc-500 hover:text-gold-500 transition-colors flex items-center justify-center gap-1"
                                        >
                                            <Sparkles size={12} /> Nova Análise
                                        </button>
                                    </div>
                                ) : (
                                    <div className="text-center py-6">
                                        <p className="text-xs text-zinc-400 mb-4 px-4">
                                            Analise seus dados de vendas e margem para encontrar oportunidades ocultas.
                                        </p>
                                        <button 
                                            onClick={generateAiInsights} 
                                            disabled={isGeneratingAi}
                                            className="bg-gold-600/90 hover:bg-gold-500 text-black px-6 py-2.5 rounded-sm text-xs font-bold uppercase transition-all shadow-lg shadow-gold-900/20 flex items-center gap-2 mx-auto hover:scale-105"
                                        >
                                            {isGeneratingAi ? <Activity size={14} className="animate-spin"/> : <Sparkles size={14} />}
                                            {isGeneratingAi ? 'Processando...' : 'Gerar Estratégia'}
                                        </button>
                                    </div>
                                )}
                            </div>
                            
                            {/* Decorative Elements */}
                            <div className="absolute top-0 right-0 p-8 opacity-5 pointer-events-none"><Brain size={100} /></div>
                        </div>

                        {/* RECEIVABLES MINI-LIST */}
                        <div className="bg-zinc-900/30 border border-zinc-800/50 rounded-xl p-5 flex flex-col flex-1 min-h-[250px]">
                            <h3 className="text-xs font-bold text-zinc-400 uppercase tracking-wider mb-4 flex items-center gap-2"><ArrowRight size={14} className="text-emerald-500"/> Próximos Recebimentos</h3>
                            <div className="flex-1 overflow-y-auto space-y-2 pr-1 custom-scrollbar">
                                {receivables.slice(0, 5).map(rx => (
                                    <div key={rx.id} className="group p-3 bg-zinc-950/50 border border-zinc-800/50 hover:border-emerald-500/30 rounded-lg flex justify-between items-center transition-all">
                                        <div>
                                            <p className="text-xs font-bold text-zinc-200 truncate w-32 group-hover:text-emerald-400 transition-colors">{rx.payee || 'Cliente'}</p>
                                            <p className={`text-[10px] font-mono ${rx.status === 'overdue' ? 'text-red-500 font-bold' : 'text-zinc-500'}`}>
                                                {rx.status === 'overdue' ? `ATRASO ${Math.abs(rx.daysDiff)}D` : formatDate(rx.date)}
                                            </p>
                                        </div>
                                        <span className="text-xs font-mono font-bold text-white group-hover:text-emerald-400">{formatCurrency(rx.amount)}</span>
                                    </div>
                                ))}
                                {receivables.length === 0 && <div className="flex-1 flex items-center justify-center text-xs text-zinc-600 italic">Nenhum recebimento pendente.</div>}
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        )}

        {/* --- VIEW: DRE --- */}
        {activeTab === 'dre' && (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2 bg-zinc-900 border border-zinc-800 rounded-xl overflow-hidden shadow-2xl">
                    <div className="flex justify-between items-center p-6 border-b border-zinc-800 bg-zinc-950/50">
                        <div>
                            <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2"><Scale size={16} className="text-gold-500"/> Demonstração de Resultado</h3>
                            <p className="text-[10px] text-zinc-500 mt-1">Competência: {currentMonthStr}</p>
                        </div>
                        <button onClick={handleExportExecutiveReport} className="text-zinc-400 hover:text-white transition-colors bg-zinc-900 p-2 rounded-lg border border-zinc-800 hover:border-gold-500" title="Download PDF"><Download size={18} /></button>
                    </div>
                    <div className="p-2">
                        {dreData.map((line, idx) => (
                            <div 
                                key={idx} 
                                className={`
                                    flex justify-between items-center px-6 py-3 my-1 rounded-lg transition-all
                                    ${line.isTotal ? 'bg-zinc-950 border border-zinc-800 font-bold shadow-sm' : 'hover:bg-zinc-800/30'}
                                    ${line.label.includes('LUCRO LÍQUIDO') ? 'bg-gradient-to-r from-zinc-900 to-emerald-950/30 border-emerald-900/30' : ''}
                                `}
                            >
                                <div className="flex items-center gap-3">
                                    {line.isTotal && <div className={`w-1 h-4 rounded-full ${line.label.includes('LUCRO') ? 'bg-emerald-500' : 'bg-zinc-500'}`}></div>}
                                    <span className={`text-sm ${line.level === 1 ? 'text-zinc-200' : 'text-zinc-400 pl-4'} ${line.isTotal ? 'uppercase tracking-wide' : ''}`}>
                                        {line.label}
                                    </span>
                                </div>
                                <div className="flex gap-8 items-center font-mono">
                                    <span className="text-xs text-zinc-600 w-12 text-right">{line.percent?.toFixed(1)}%</span>
                                    <span className={`w-28 text-right text-sm ${
                                        line.isDeduction ? 'text-red-400' : 
                                        line.label.includes('LUCRO') || line.label.includes('EBITDA') ? 'text-emerald-400 font-bold' : 
                                        'text-white'
                                    }`}>
                                        {line.isDeduction ? `(${formatCurrency(line.value)})` : formatCurrency(line.value)}
                                    </span>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
                
                {/* DRE SIDEBAR */}
                <div className="space-y-6">
                    <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-6">
                        <h3 className="text-xs font-bold text-white uppercase tracking-wider mb-6">Estrutura de Custos</h3>
                        <div className="space-y-6">
                            <ProgressBar label="Custo do Produto (CPV)" value={dreData.find(d => d.label.includes('CPV'))?.percent || 0} color="bg-red-500" />
                            <ProgressBar label="Despesas Operacionais" value={dreData.find(d => d.label.includes('Despesas'))?.percent || 0} color="bg-orange-500" />
                            <ProgressBar label="Margem EBITDA" value={dreData.find(d => d.label === '(=) EBITDA')?.percent || 0} color="bg-emerald-500" />
                        </div>
                    </div>
                    
                    <div className="bg-zinc-900/50 border border-zinc-800 p-6 rounded-xl relative overflow-hidden">
                        <div className="absolute top-0 right-0 p-4 opacity-5"><Target size={80} /></div>
                        <p className="text-[10px] text-zinc-500 uppercase font-bold mb-1">Ponto de Equilíbrio (Est.)</p>
                        <p className="text-2xl font-bold text-white tracking-tight">R$ 45.200</p>
                        <p className="text-[10px] text-zinc-600 mt-2">Valor necessário para cobrir custos fixos.</p>
                    </div>
                </div>
            </div>
        )}

        {/* --- VIEW: PRODUCTS --- */}
        {activeTab === 'products' && (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2 space-y-6">
                    {/* TOP PRODUCTS */}
                    <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-6">
                        <h3 className="text-xs font-bold text-white uppercase tracking-wider mb-6 flex items-center gap-2">
                            <ShoppingBag size={16} className="text-gold-500"/> Campeões de Venda (Volume)
                        </h3>
                        <div className="h-[280px]">
                            <ResponsiveContainer width="100%" height="100%">
                                <BarChart data={productAnalytics.topProducts} layout="vertical" margin={{ top: 5, right: 30, left: 0, bottom: 5 }}>
                                    <CartesianGrid strokeDasharray="3 3" stroke="#27272a" horizontal={true} vertical={false} />
                                    <XAxis type="number" stroke="#52525b" fontSize={10} axisLine={false} tickLine={false} />
                                    <YAxis dataKey="name" type="category" stroke="#a1a1aa" fontSize={11} width={140} axisLine={false} tickLine={false} />
                                    <Tooltip cursor={{fill: 'rgba(255,255,255,0.05)'}} contentStyle={{ backgroundColor: COLORS.cardBg, borderColor: '#3f3f46', fontSize: '12px' }} />
                                    <Bar dataKey="qty" fill={COLORS.gold} barSize={20} radius={[0, 4, 4, 0]} name="Quantidade" />
                                </BarChart>
                            </ResponsiveContainer>
                        </div>
                    </div>

                    {/* TOP CLIENTS */}
                    <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-6">
                        <h3 className="text-xs font-bold text-white uppercase tracking-wider mb-6 flex items-center gap-2">
                            <Briefcase size={16} className="text-blue-500"/> Principais Clientes (Receita)
                        </h3>
                        <div className="space-y-2">
                            {productAnalytics.topClients.map((client, idx) => (
                                <div key={client.id} className="flex items-center justify-between p-3 bg-zinc-950/50 border border-zinc-800 hover:border-blue-900/50 rounded-lg transition-colors group">
                                    <div className="flex items-center gap-4">
                                        <div className="w-8 h-8 rounded-full bg-zinc-800 flex items-center justify-center text-xs font-bold text-zinc-400 group-hover:text-white transition-colors">#{idx + 1}</div>
                                        <div>
                                            <p className="text-sm font-bold text-zinc-200 group-hover:text-white">{client.name}</p>
                                            <p className="text-[10px] text-zinc-500">{client.count} pedidos realizados</p>
                                        </div>
                                    </div>
                                    <span className="text-sm font-mono font-bold text-emerald-500 bg-emerald-500/10 px-2 py-1 rounded border border-emerald-500/20">{formatCurrency(client.revenue)}</span>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>

                {/* ALERTS COLUMN */}
                <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-6 h-fit">
                    <h3 className="text-xs font-bold text-white uppercase tracking-wider mb-4 flex items-center gap-2">
                        <AlertTriangle size={16} className="text-red-500"/> Atenção: Baixo Volume
                    </h3>
                    <p className="text-xs text-zinc-400 mb-6 leading-relaxed">
                        Produtos com estoque parado ou baixa procura. Considere promoções.
                    </p>
                    <div className="space-y-3">
                        {productAnalytics.bottomProducts.map(p => (
                            <div key={p.id} className="flex justify-between items-center text-xs p-3 bg-red-950/10 border border-red-900/30 rounded-lg group hover:bg-red-950/20 transition-colors">
                                <span className="text-zinc-300 font-medium">{p.name}</span>
                                <span className="font-bold text-red-400 bg-red-500/10 px-2 py-1 rounded">{p.qty} un</span>
                            </div>
                        ))}
                        {productAnalytics.bottomProducts.length === 0 && <span className="text-xs text-zinc-500 italic">Nenhum produto crítico identificado.</span>}
                    </div>
                </div>
            </div>
        )}

        {/* --- CUSTOM TOAST NOTIFICATION --- */}
        {toast.visible && (
            <div className={`fixed bottom-8 left-1/2 -translate-x-1/2 px-6 py-3 rounded-full shadow-2xl flex items-center gap-3 z-[100] animate-in slide-in-from-bottom-5 fade-in duration-300 border backdrop-blur-md ${
                toast.type === 'error' ? 'bg-red-950/90 border-red-800 text-red-200' :
                toast.type === 'info' ? 'bg-blue-950/90 border-blue-800 text-blue-200' :
                'bg-emerald-950/90 border-emerald-800 text-emerald-200'
            }`}>
                {toast.type === 'error' ? <AlertTriangle size={18} /> : toast.type === 'info' ? <AlertCircle size={18} /> : <CheckCircle size={18} />}
                <span className="text-sm font-bold tracking-wide">{toast.message}</span>
            </div>
        )}
    </div>
  );
};

// --- SUB-COMPONENTS (INLINED FOR STYLE CONTROL) ---

const DashboardCard = ({ title, value, target, icon: Icon, color, inverse, action, isMain }: any) => {
    // Color mapping
    const colorClasses: any = {
        emerald: 'text-emerald-500 bg-emerald-500/10 border-emerald-500/20',
        red: 'text-red-500 bg-red-500/10 border-red-500/20',
        blue: 'text-blue-500 bg-blue-500/10 border-blue-500/20',
        gold: 'text-gold-500 bg-gold-500/10 border-gold-500/20',
    };
    
    const percent = target ? (value / target) * 100 : 0;
    const isPositive = inverse ? value <= (target || value) : value >= (target || 0);

    return (
        <div 
            onClick={action}
            className={`
                relative overflow-hidden p-6 rounded-xl border transition-all duration-300 group
                ${isMain ? 'bg-gradient-to-br from-zinc-900 via-zinc-900 to-black border-gold-500/30' : 'bg-zinc-900/50 border-zinc-800 hover:border-zinc-700'}
                ${action ? 'cursor-pointer hover:translate-y-[-2px] hover:shadow-xl' : ''}
            `}
        >
            <div className="flex justify-between items-start mb-4">
                <div className={`p-2.5 rounded-lg border ${colorClasses[color] || 'text-zinc-400 bg-zinc-800 border-zinc-700'}`}>
                    <Icon size={20} />
                </div>
                {target && (
                    <div className={`text-[10px] font-bold px-2 py-1 rounded-full border ${isPositive ? 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20' : 'bg-red-500/10 text-red-500 border-red-500/20'}`}>
                        {percent.toFixed(0)}% Meta
                    </div>
                )}
            </div>
            
            <p className="text-zinc-500 text-xs font-bold uppercase tracking-widest mb-1">{title}</p>
            <h3 className={`text-2xl font-bold tracking-tight ${isMain ? 'text-white text-3xl' : 'text-zinc-100'}`}>
                {formatCurrency(value)}
            </h3>

            {/* Target Bar */}
            {target && (
                <div className="mt-4 h-1.5 w-full bg-zinc-800 rounded-full overflow-hidden">
                    <div 
                        className={`h-full rounded-full transition-all duration-1000 ${isPositive ? 'bg-emerald-500' : 'bg-blue-500'}`} 
                        style={{ width: `${Math.min(percent, 100)}%` }}
                    ></div>
                </div>
            )}
            
            {/* Hover Glow */}
            <div className={`absolute -right-10 -top-10 w-32 h-32 rounded-full blur-3xl opacity-0 group-hover:opacity-10 transition-opacity pointer-events-none bg-${color}-500`}></div>
        </div>
    );
};

const ProgressBar = ({ label, value, color }: any) => (
    <div>
        <div className="flex justify-between text-xs mb-2">
            <span className="text-zinc-400 font-bold uppercase tracking-wider">{label}</span>
            <span className="text-white font-mono">{value.toFixed(1)}%</span>
        </div>
        <div className="w-full bg-zinc-950 h-2 rounded-full overflow-hidden border border-zinc-800">
            <div className={`${color} h-full rounded-full transition-all duration-1000`} style={{ width: `${Math.min(value, 100)}%` }}></div>
        </div>
    </div>
);

export default Dashboard;

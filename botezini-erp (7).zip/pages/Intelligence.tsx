
import React, { useState, useEffect, useMemo } from 'react';
import { storageService } from '../services/storage';
import { intelligenceService } from '../services/intelligenceService';
import { Transaction, Order, Client, DailyProjection, ClientRiskProfile, FinancialHealthSnapshot, SimulationAction } from '../types';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, ReferenceLine, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar, Legend } from 'recharts';
import { Brain, TrendingUp, AlertTriangle, ShieldAlert, Activity, Play, RefreshCw, Plus, Trash2, Zap, Save, CheckCircle } from 'lucide-react';
import { formatCurrency } from '../utils';

const COLORS = {
  gold: '#C9A24D',
  emerald: '#10b981',
  red: '#ef4444',
  zinc: '#71717a',
  bg: '#18181b',
};

const Intelligence: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'projection' | 'risk' | 'health'>('projection');
  const [isLoading, setIsLoading] = useState(true);
  
  // Data State
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [clients, setClients] = useState<Client[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  
  // Derived State
  const [projections, setProjections] = useState<DailyProjection[]>([]);
  const [baseProjections, setBaseProjections] = useState<DailyProjection[]>([]);
  const [riskProfiles, setRiskProfiles] = useState<ClientRiskProfile[]>([]);
  const [health, setHealth] = useState<FinancialHealthSnapshot | null>(null);
  
  // Simulation State
  const [scenarios, setScenarios] = useState<SimulationAction[]>([]);
  const [manualInjection, setManualInjection] = useState<number>(0);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setIsLoading(true);
    try {
        const [txs, ords, clis] = await Promise.all([
            storageService.getTransactions(),
            storageService.getOrders(),
            storageService.getClients()
        ]);
        setTransactions(txs);
        setOrders(ords);
        setClients(clis);

        // Initial Calculations
        const currentBalance = txs.filter(t => t.isPaid).reduce((acc, t) => acc + (t.type === 'income' ? t.amount : -t.amount), 0);
        
        const baseProj = intelligenceService.calculateProjection(txs, 60, currentBalance);
        setBaseProjections(baseProj);
        setProjections(baseProj);

        const risks = intelligenceService.calculateClientRisk(clis, ords, txs);
        setRiskProfiles(risks);

        // Simple mock for assets/liabilities for health demo
        const receivables = txs.filter(t => t.type === 'income' && !t.isPaid).reduce((s,t) => s + t.amount, 0);
        const payables = txs.filter(t => t.type === 'expense' && !t.isPaid).reduce((s,t) => s + t.amount, 0);
        const healthSnap = intelligenceService.calculateHealth(txs, currentBalance + receivables, payables);
        setHealth(healthSnap);

    } catch (e) {
        console.error(e);
    } finally {
        setIsLoading(false);
    }
  };

  // Re-run simulation when scenarios change
  useEffect(() => {
      if (transactions.length > 0) {
          const currentBalance = transactions.filter(t => t.isPaid).reduce((acc, t) => acc + (t.type === 'income' ? t.amount : -t.amount), 0);
          const simProj = intelligenceService.calculateProjection(transactions, 60, currentBalance, scenarios);
          setProjections(simProj);
      }
  }, [scenarios, transactions]);

  const toggleScenario = (type: SimulationAction['type']) => {
      const existing = scenarios.find(s => s.type === type);
      if (existing) {
          setScenarios(prev => prev.filter(s => s.type !== type));
      } else {
          const newAction: SimulationAction = {
              id: crypto.randomUUID(),
              type,
              amount: type === 'inject_cash' ? 10000 : undefined,
              days: type === 'delay_payment' ? 15 : undefined,
              description: type
          };
          setScenarios(prev => [...prev, newAction]);
      }
  };

  if (isLoading) return <div className="h-screen flex items-center justify-center bg-zinc-950 text-gold-500 animate-pulse"><Brain size={48}/></div>;

  return (
    <div className="space-y-6 pb-20">
        {/* HEADER */}
        <div className="flex justify-between items-center bg-zinc-900/50 p-6 rounded-sm border border-zinc-800">
            <div>
                <h1 className="text-2xl font-bold text-white flex items-center gap-3">
                    <Brain className="text-gold-500" /> Inteligência Financeira
                </h1>
                <p className="text-zinc-500 text-xs mt-1 uppercase tracking-widest">Módulo de Análise Preditiva e Risco (BETA)</p>
            </div>
            <div className="flex gap-2">
                <button onClick={() => setActiveTab('projection')} className={`px-4 py-2 text-xs font-bold uppercase rounded-sm border transition-all ${activeTab === 'projection' ? 'bg-gold-500 text-black border-gold-500' : 'bg-zinc-950 text-zinc-400 border-zinc-800 hover:border-gold-500'}`}>Simulador de Caixa</button>
                <button onClick={() => setActiveTab('risk')} className={`px-4 py-2 text-xs font-bold uppercase rounded-sm border transition-all ${activeTab === 'risk' ? 'bg-red-500 text-white border-red-500' : 'bg-zinc-950 text-zinc-400 border-zinc-800 hover:border-red-500'}`}>Risco de Clientes</button>
                <button onClick={() => setActiveTab('health')} className={`px-4 py-2 text-xs font-bold uppercase rounded-sm border transition-all ${activeTab === 'health' ? 'bg-emerald-500 text-white border-emerald-500' : 'bg-zinc-950 text-zinc-400 border-zinc-800 hover:border-emerald-500'}`}>Saúde do Negócio</button>
            </div>
        </div>

        {/* --- PROJECTION TAB --- */}
        {activeTab === 'projection' && (
            <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
                
                {/* Controls */}
                <div className="lg:col-span-1 space-y-4">
                    <div className="bg-zinc-900 border border-zinc-800 p-4 rounded-sm">
                        <h3 className="text-xs font-bold text-white uppercase tracking-wider mb-4 flex items-center gap-2">
                            <Zap size={14} className="text-gold-500" /> Ações de Cenário
                        </h3>
                        <div className="space-y-2">
                            <button 
                                onClick={() => toggleScenario('delay_payment')}
                                className={`w-full flex items-center justify-between p-3 rounded-sm border transition-all ${scenarios.some(s => s.type === 'delay_payment') ? 'bg-blue-900/30 border-blue-500 text-blue-200' : 'bg-zinc-950 border-zinc-800 text-zinc-400 hover:border-zinc-600'}`}
                            >
                                <span className="text-xs font-bold">Adiar Contas (15d)</span>
                                {scenarios.some(s => s.type === 'delay_payment') && <CheckCircle size={14} />}
                            </button>
                            
                            <button 
                                onClick={() => toggleScenario('simulate_default')}
                                className={`w-full flex items-center justify-between p-3 rounded-sm border transition-all ${scenarios.some(s => s.type === 'simulate_default') ? 'bg-red-900/30 border-red-500 text-red-200' : 'bg-zinc-950 border-zinc-800 text-zinc-400 hover:border-zinc-600'}`}
                            >
                                <span className="text-xs font-bold">Simular Inadimplência (30%)</span>
                                {scenarios.some(s => s.type === 'simulate_default') && <CheckCircle size={14} />}
                            </button>

                            <div className="p-3 bg-zinc-950 border border-zinc-800 rounded-sm">
                                <label className="text-[10px] uppercase font-bold text-zinc-500 mb-2 block">Injeção de Capital</label>
                                <div className="flex gap-2">
                                    <input 
                                        type="number" 
                                        value={manualInjection} 
                                        onChange={(e) => setManualInjection(parseFloat(e.target.value))}
                                        className="w-full bg-zinc-900 border border-zinc-700 rounded-sm text-xs text-white px-2 py-1 outline-none focus:border-gold-500"
                                        placeholder="0.00"
                                    />
                                    <button 
                                        onClick={() => {
                                            const existing = scenarios.find(s => s.type === 'inject_cash');
                                            if (existing) {
                                                setScenarios(prev => prev.map(s => s.type === 'inject_cash' ? { ...s, amount: manualInjection } : s));
                                            } else {
                                                setScenarios(prev => [...prev, { id: 'inj', type: 'inject_cash', amount: manualInjection, description: 'Capital' }]);
                                            }
                                        }}
                                        className="bg-gold-600 hover:bg-gold-500 text-black px-3 rounded-sm"
                                    ><Plus size={14}/></button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className="bg-zinc-900 border border-zinc-800 p-4 rounded-sm">
                        <div className="flex items-center gap-3 mb-4">
                            <div className="w-2 h-2 rounded-full bg-zinc-500"></div> <span className="text-xs text-zinc-400">Cenário Base</span>
                        </div>
                        <div className="flex items-center gap-3">
                            <div className="w-2 h-2 rounded-full bg-gold-500"></div> <span className="text-xs text-gold-500 font-bold">Cenário Simulado</span>
                        </div>
                    </div>
                </div>

                {/* Chart */}
                <div className="lg:col-span-3 bg-zinc-900 border border-zinc-800 p-6 rounded-sm">
                    <div className="flex justify-between items-center mb-6">
                        <h3 className="text-sm font-bold text-white uppercase tracking-wider">Projeção de Caixa (60 Dias)</h3>
                        {scenarios.length > 0 && <span className="text-xs bg-gold-500/20 text-gold-500 px-2 py-1 rounded border border-gold-500/30 animate-pulse">SIMULAÇÃO ATIVA</span>}
                    </div>
                    
                    <div className="h-[400px]">
                        <ResponsiveContainer width="100%" height="100%">
                            <AreaChart data={projections}>
                                <defs>
                                    <linearGradient id="colorBalance" x1="0" y1="0" x2="0" y2="1">
                                        <stop offset="5%" stopColor={COLORS.gold} stopOpacity={0.3}/>
                                        <stop offset="95%" stopColor={COLORS.gold} stopOpacity={0}/>
                                    </linearGradient>
                                </defs>
                                <CartesianGrid strokeDasharray="3 3" stroke="#27272a" vertical={false} />
                                <XAxis 
                                    dataKey="date" 
                                    stroke="#52525b" 
                                    fontSize={10} 
                                    tickFormatter={(str) => str.substring(8, 10) + '/' + str.substring(5, 7)}
                                    minTickGap={30}
                                />
                                <YAxis stroke="#52525b" fontSize={10} tickFormatter={(val) => `R$${val/1000}k`} />
                                <Tooltip 
                                    contentStyle={{ backgroundColor: COLORS.bg, borderColor: '#3f3f46' }}
                                    formatter={(value: number) => formatCurrency(value)}
                                />
                                <ReferenceLine y={0} stroke={COLORS.red} strokeDasharray="3 3" />
                                <Area 
                                    type="monotone" 
                                    dataKey="closingBalance" 
                                    stroke={scenarios.length > 0 ? COLORS.gold : COLORS.zinc} 
                                    strokeWidth={2}
                                    fill="url(#colorBalance)" 
                                    name="Saldo Projetado"
                                />
                            </AreaChart>
                        </ResponsiveContainer>
                    </div>
                </div>
            </div>
        )}

        {/* --- RISK TAB --- */}
        {activeTab === 'risk' && (
            <div className="grid grid-cols-1 gap-6">
                <div className="bg-zinc-900 border border-zinc-800 rounded-sm overflow-hidden">
                    <table className="w-full text-left">
                        <thead className="bg-zinc-950 text-zinc-500 text-[10px] uppercase font-bold tracking-wider">
                            <tr>
                                <th className="p-4">Cliente</th>
                                <th className="p-4 text-center">Score (0-100)</th>
                                <th className="p-4 text-center">Risco</th>
                                <th className="p-4 text-right">Atraso Médio</th>
                                <th className="p-4 text-right">Exposição (Em Aberto)</th>
                                <th className="p-4 text-right">Limite Sugerido</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-zinc-800 text-sm">
                            {riskProfiles.map(profile => (
                                <tr key={profile.clientId} className="hover:bg-zinc-800/50 transition">
                                    <td className="p-4 font-bold text-white">{profile.clientName}</td>
                                    <td className="p-4 text-center">
                                        <div className="w-full bg-zinc-800 h-2 rounded-full overflow-hidden">
                                            <div 
                                                className={`h-full ${profile.score > 75 ? 'bg-emerald-500' : profile.score > 40 ? 'bg-yellow-500' : 'bg-red-500'}`} 
                                                style={{ width: `${profile.score}%` }}
                                            ></div>
                                        </div>
                                        <span className="text-xs text-zinc-400 mt-1 block">{profile.score}</span>
                                    </td>
                                    <td className="p-4 text-center">
                                        <span className={`px-2 py-1 rounded-sm text-[10px] uppercase font-bold ${
                                            profile.riskLevel === 'high' ? 'bg-red-900/30 text-red-500 border border-red-900' : 
                                            profile.riskLevel === 'medium' ? 'bg-yellow-900/30 text-yellow-500 border border-yellow-900' : 
                                            'bg-emerald-900/30 text-emerald-500 border border-emerald-900'
                                        }`}>
                                            {profile.riskLevel === 'high' ? 'Alto' : profile.riskLevel === 'medium' ? 'Médio' : 'Baixo'}
                                        </span>
                                    </td>
                                    <td className="p-4 text-right font-mono text-zinc-300">{profile.avgDelayDays} dias</td>
                                    <td className="p-4 text-right font-mono text-white">{formatCurrency(profile.totalOpen)}</td>
                                    <td className="p-4 text-right font-mono text-zinc-500">{formatCurrency(profile.suggestedCreditLimit)}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
        )}

        {/* --- HEALTH TAB --- */}
        {activeTab === 'health' && health && (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <div className="bg-zinc-900 border border-zinc-800 p-6 rounded-sm">
                    <h3 className="text-xs font-bold text-zinc-500 uppercase tracking-widest mb-2">Liquidez Corrente</h3>
                    <p className="text-3xl font-bold text-white">{health.liquidityRatio.toFixed(2)}</p>
                    <p className="text-xs text-zinc-500 mt-2">Ideal: Maior que 1.0</p>
                    <div className="mt-4 w-full bg-zinc-950 h-2 rounded-full overflow-hidden">
                        <div className={`h-full ${health.liquidityRatio > 1 ? 'bg-emerald-500' : 'bg-red-500'}`} style={{ width: `${Math.min(health.liquidityRatio * 50, 100)}%` }}></div>
                    </div>
                </div>

                <div className="bg-zinc-900 border border-zinc-800 p-6 rounded-sm">
                    <h3 className="text-xs font-bold text-zinc-500 uppercase tracking-widest mb-2">Cash Runway (Sobrevivência)</h3>
                    <p className="text-3xl font-bold text-white">{Math.floor(health.cashRunwayDays)} Dias</p>
                    <p className="text-xs text-zinc-500 mt-2">Baseado na queima média de caixa</p>
                </div>

                <div className="bg-zinc-900 border border-zinc-800 p-6 rounded-sm">
                    <h3 className="text-xs font-bold text-zinc-500 uppercase tracking-widest mb-2">Margem de Lucro Real</h3>
                    <p className={`text-3xl font-bold ${health.profitMargin > 0 ? 'text-emerald-500' : 'text-red-500'}`}>{health.profitMargin.toFixed(1)}%</p>
                    <p className="text-xs text-zinc-500 mt-2">Receita vs Despesas Totais</p>
                </div>

                {/* Radar Chart */}
                <div className="md:col-span-2 lg:col-span-3 bg-zinc-900 border border-zinc-800 p-6 rounded-sm flex flex-col items-center">
                    <h3 className="text-sm font-bold text-white uppercase tracking-widest mb-6">Raio-X de Saúde Financeira</h3>
                    <div className="h-[300px] w-full max-w-lg">
                        <ResponsiveContainer width="100%" height="100%">
                            <RadarChart outerRadius={90} data={[
                                { subject: 'Liquidez', A: Math.min(health.liquidityRatio * 100, 100), fullMark: 100 },
                                { subject: 'Margem', A: Math.max(0, health.profitMargin * 2), fullMark: 100 },
                                { subject: 'Runway', A: Math.min(health.cashRunwayDays, 100), fullMark: 100 },
                                { subject: 'Endividamento', A: Math.max(0, 100 - (health.debtRatio * 100)), fullMark: 100 },
                            ]}>
                                <PolarGrid stroke="#3f3f46" />
                                <PolarAngleAxis dataKey="subject" tick={{ fill: '#a1a1aa', fontSize: 10 }} />
                                <PolarRadiusAxis angle={30} domain={[0, 100]} tick={false} axisLine={false} />
                                <Radar name="Botezini" dataKey="A" stroke={COLORS.gold} fill={COLORS.gold} fillOpacity={0.3} />
                                <Tooltip contentStyle={{ backgroundColor: COLORS.bg, borderColor: '#3f3f46' }} />
                            </RadarChart>
                        </ResponsiveContainer>
                    </div>
                </div>
            </div>
        )}
    </div>
  );
};

export default Intelligence;

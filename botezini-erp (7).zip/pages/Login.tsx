import React, { useState, useEffect } from 'react';
import { authService } from '../services/auth';
import { storageService } from '../services/storage';
import { CompanyProfile } from '../types';
import { Lock, Mail, AlertTriangle, ArrowRight, ShieldCheck, HelpCircle, X, Loader2 } from 'lucide-react';

interface Props {
    onLoginSuccess: () => void;
}

const Login: React.FC<Props> = ({ onLoginSuccess }) => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [isProfileLoading, setIsProfileLoading] = useState(true);
    const [error, setError] = useState('');
    const [showHelp, setShowHelp] = useState(false);
    const [companyProfile, setCompanyProfile] = useState<CompanyProfile | null>(null);

    useEffect(() => {
        const loadIdentity = async () => {
            setIsProfileLoading(true);
            try {
                const profile = await storageService.getCompanyProfile();
                if (profile) setCompanyProfile(profile);
            } catch (e) {
                console.error("Failed to load company profile for login", e);
            } finally {
                setIsProfileLoading(false);
            }
        };
        loadIdentity();
    }, []);

    const handleLogin = async (e: React.FormEvent) => {
        e.preventDefault();
        setIsLoading(true);
        setError('');

        try {
            await authService.signIn(email, password);
            onLoginSuccess();
        } catch (err: any) {
            console.error(err);
            if (err.message.includes('Invalid login credentials')) {
                setError('Credenciais incorretas. Verifique e tente novamente.');
            } else if (err.message.includes('Email not confirmed')) {
                setError('Email não confirmado. Verifique sua caixa de entrada.');
            } else {
                setError('Acesso negado. Contate o administrador.');
            }
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="min-h-screen bg-zinc-950 flex flex-col items-center justify-center p-4 relative overflow-hidden">
            {/* Background Effects */}
            <div className="absolute inset-0 pointer-events-none opacity-[0.03]" 
                 style={{ backgroundImage: 'linear-gradient(#333 1px, transparent 1px), linear-gradient(90deg, #333 1px, transparent 1px)', backgroundSize: '40px 40px' }}>
            </div>
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-gold-500/5 rounded-full blur-[100px] pointer-events-none"></div>

            <div className="w-full max-w-md bg-zinc-900 border border-zinc-800 p-8 rounded-sm shadow-2xl relative z-10 animate-in fade-in zoom-in-95 duration-500">
                <div className="flex flex-col items-center mb-8 min-h-[100px] justify-center">
                    {isProfileLoading ? (
                        <div className="flex flex-col items-center gap-2 opacity-50">
                            <div className="h-6 w-32 bg-zinc-800 rounded animate-pulse"></div>
                        </div>
                    ) : (
                        <>
                            {companyProfile?.logoUrl && (
                                <div className="w-28 h-28 mb-4 flex items-center justify-center bg-transparent rounded-lg overflow-hidden">
                                    <img src={companyProfile.logoUrl} alt="Logo" className="w-full h-full object-contain drop-shadow-2xl" />
                                </div>
                            )}
                            
                            <h1 className="text-2xl font-bold text-white tracking-widest text-center uppercase">
                                {companyProfile?.name || 'BOTEZINI ERP'}
                            </h1>
                            <p className="text-xs text-zinc-500 mt-1 font-mono uppercase tracking-wider">Acesso Restrito • Ambiente Seguro</p>
                        </>
                    )}
                </div>

                {error && (
                    <div className="bg-red-950/30 border border-red-900/50 p-3 rounded-sm flex items-center gap-3 mb-6 animate-in slide-in-from-top-2">
                        <AlertTriangle className="text-red-500 shrink-0" size={18} />
                        <p className="text-xs text-red-200">{error}</p>
                    </div>
                )}

                <form onSubmit={handleLogin} className="space-y-4">
                    <div className="space-y-1">
                        <label className="text-[10px] font-bold text-zinc-500 uppercase tracking-wider">Email Corporativo</label>
                        <div className="relative group">
                            <Mail className="absolute left-3 top-3 text-zinc-600 group-focus-within:text-gold-500 transition-colors" size={18} />
                            <input 
                                type="email" 
                                value={email}
                                onChange={(e) => setEmail(e.target.value)}
                                className="w-full bg-zinc-950 border border-zinc-800 text-white text-sm py-2.5 pl-10 pr-4 rounded-sm outline-none focus:border-gold-500 transition-all placeholder:text-zinc-700"
                                placeholder="usuario@empresa.com"
                                required
                            />
                        </div>
                    </div>

                    <div className="space-y-1">
                        <label className="text-[10px] font-bold text-zinc-500 uppercase tracking-wider">Senha</label>
                        <div className="relative group">
                            <Lock className="absolute left-3 top-3 text-zinc-600 group-focus-within:text-gold-500 transition-colors" size={18} />
                            <input 
                                type="password" 
                                value={password}
                                onChange={(e) => setPassword(e.target.value)}
                                className="w-full bg-zinc-950 border border-zinc-800 text-white text-sm py-2.5 pl-10 pr-4 rounded-sm outline-none focus:border-gold-500 transition-all placeholder:text-zinc-700"
                                placeholder="••••••••"
                                required
                            />
                        </div>
                    </div>

                    <button 
                        type="submit" 
                        disabled={isLoading}
                        className="w-full bg-gold-600 hover:bg-gold-500 text-black font-bold py-3 rounded-sm uppercase tracking-wide text-xs transition-all flex items-center justify-center gap-2 mt-6 shadow-lg shadow-gold-900/20 disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                        {isLoading ? (
                            <>
                                <Loader2 size={16} className="animate-spin" /> Autenticando...
                            </>
                        ) : (
                            <>
                                Entrar no Sistema <ArrowRight size={16} />
                            </>
                        )} 
                    </button>
                </form>

                <div className="mt-6 flex justify-between items-center text-[10px] text-zinc-500">
                    <button onClick={() => setShowHelp(true)} className="hover:text-gold-500 flex items-center gap-1 transition-colors"><HelpCircle size={12} /> Primeiro Acesso?</button>
                    <span className="flex items-center gap-1"><ShieldCheck size={10} className="text-emerald-500" /> Secure SSL</span>
                </div>
            </div>

            {/* Help Modal */}
            {showHelp && (
                <div className="fixed inset-0 bg-black/90 z-50 flex items-center justify-center p-4 backdrop-blur-sm animate-in fade-in duration-200">
                    <div className="bg-zinc-900 border border-zinc-800 rounded-sm max-w-sm w-full p-6 shadow-2xl relative">
                        <button onClick={() => setShowHelp(false)} className="absolute top-4 right-4 text-zinc-500 hover:text-white"><X size={20} /></button>
                        <div className="mb-4 text-gold-500"><Lock size={32} /></div>
                        <h3 className="text-lg font-bold text-white mb-2">Acesso Restrito</h3>
                        <p className="text-sm text-zinc-400 mb-4 leading-relaxed">
                            Por motivos de segurança industrial, este sistema não permite auto-cadastro.
                        </p>
                        <ul className="text-xs text-zinc-500 space-y-2 mb-6 list-disc pl-4">
                            <li>Solicite sua credencial ao <strong>Administrador do Sistema</strong>.</li>
                            <li>Novos usuários são criados com permissão "Fábrica" por padrão.</li>
                            <li>Para acesso administrativo, é necessária aprovação da diretoria.</li>
                        </ul>
                        <button onClick={() => setShowHelp(false)} className="w-full bg-zinc-800 hover:bg-zinc-700 text-white py-2 rounded-sm text-xs font-bold uppercase">Entendido</button>
                    </div>
                </div>
            )}
        </div>
    );
};

export default Login;
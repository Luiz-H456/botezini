import React, { useState, useEffect, useMemo } from 'react';
import { storageService } from '../services/storage';
import { Order, OrderStatus, ProductionStage } from '../types';
import { formatDate, getTodayStr, countBusinessDays } from '../utils';
import { Scissors, Shirt, Package, Truck, AlertTriangle, Maximize2, Minimize2, ChevronRight, CheckCircle, Clock, Calendar, Factory, Palette, Box, ChevronLeft, ChevronRight as IconRight, Link, StickyNote, Layers, Search, CheckSquare } from 'lucide-react';

// --- HELPER TYPES & UTILS ---

type DelayStatus = 'ok' | 'warning' | 'late';

// Define a local type for display that includes the joined client name
type EnrichedOrder = Order & { clientName?: string };

const getDeadlineStatus = (deadline: string): DelayStatus => {
    if (!deadline) return 'ok';
    const today = getTodayStr();
    const daysLeft = countBusinessDays(today, deadline);
    
    if (deadline < today) return 'late';
    if (daysLeft <= 3) return 'warning';
    return 'ok';
};

const getStatusColor = (status: DelayStatus) => {
    switch (status) {
        case 'ok': return 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20';
        case 'warning': return 'bg-yellow-500/10 text-yellow-500 border-yellow-500/20';
        case 'late': return 'bg-red-500/10 text-red-500 border-red-500/20';
    }
};

// --- COMPONENTS ---

interface CardProps {
    order: EnrichedOrder;
    onAdvance: (order: EnrichedOrder) => void;
    isFactoryMode: boolean;
    stage: ProductionStage;
    onNavigate?: (view: 'orders' | 'budgets', searchTerm?: string) => void;
}

const ProductionCard: React.FC<CardProps> = ({ order, onAdvance, isFactoryMode, stage, onNavigate }) => {
    const delayStatus = getDeadlineStatus(order.deadline);
    const delayColor = getStatusColor(delayStatus);
    
    // Calculate totals
    const totalItems = order.items.reduce((acc, i) => acc + i.quantity, 0);
    const uniqueModels = Array.from(new Set(order.items.map(i => i.productId))).length;
    
    // Check for notes/customizations
    const hasNotes = (order.customizations && order.customizations.length > 0) || (order.extras && order.extras.length > 0);

    // Update Logic: The last stage is now LOGISTICS (Transporte)
    const isLastStage = stage === ProductionStage.LOGISTICS;
    const btnLabel = isLastStage ? "ENTREGAR" : "AVANÇAR";
    const btnClass = isLastStage 
        ? "bg-emerald-600 hover:bg-emerald-500 text-white shadow-emerald-900/20" 
        : "bg-zinc-800 hover:bg-zinc-700 text-zinc-300 hover:text-white border-zinc-700";

    const handleCardClick = () => {
        if (onNavigate && order.budgetSerialNumber) {
            onNavigate('budgets', order.budgetSerialNumber);
        }
    };

    const hasLink = !!(onNavigate && order.budgetSerialNumber);

    return (
        <div 
            onClick={handleCardClick}
            className={`
                relative flex flex-col justify-between
                bg-zinc-950 border border-zinc-800 rounded-sm overflow-hidden 
                transition-all duration-200 group
                ${isFactoryMode ? 'p-5 min-h-[220px]' : 'p-3 min-h-[160px]'}
                ${hasLink ? 'cursor-pointer hover:border-zinc-500 hover:bg-zinc-900/40' : 'hover:border-zinc-600'}
            `}
        >
            {/* Status Stripe */}
            <div className={`absolute left-0 top-0 bottom-0 w-1 ${
                delayStatus === 'late' ? 'bg-red-500' : delayStatus === 'warning' ? 'bg-yellow-500' : 'bg-zinc-800'
            }`}></div>

            <div className="pl-3 flex flex-col h-full">
                {/* Header */}
                <div className="flex justify-between items-start mb-2">
                    <div className="flex items-center gap-2">
                        <span className={`font-mono font-bold flex items-center gap-1 ${isFactoryMode ? 'text-xl text-white' : 'text-xs text-zinc-400'}`}>
                            #{order.orderNumber}
                            {hasLink && <Link size={10} className="text-zinc-600 group-hover:text-gold-500 transition-colors" />}
                        </span>
                        {hasNotes && (
                            <div className="flex items-center gap-1 px-1.5 py-0.5 rounded-sm bg-blue-900/20 border border-blue-800 text-[10px] text-blue-400" title="Possui observações ou personalizações">
                                <StickyNote size={10} />
                            </div>
                        )}
                    </div>
                    {order.deadline && (
                        <div className={`flex items-center gap-1 px-2 py-0.5 rounded-sm border text-[10px] font-bold uppercase tracking-wider ${delayColor}`}>
                            {delayStatus === 'late' && <AlertTriangle size={10} />}
                            {delayStatus === 'warning' && <Clock size={10} />}
                            {formatDate(order.deadline).substring(0, 5)}
                        </div>
                    )}
                </div>

                {/* Client & Main Info */}
                <div className="mb-3">
                    <h4 className={`font-bold text-white leading-tight mb-1 truncate ${isFactoryMode ? 'text-2xl' : 'text-sm'}`}>
                         {order.clientName || 'Cliente'} 
                    </h4>
                    
                    <div className="flex items-center gap-3 text-zinc-500 text-[10px] uppercase font-bold tracking-wide mt-1">
                        <span className="flex items-center gap-1 text-zinc-300 bg-zinc-900 px-1.5 py-0.5 rounded border border-zinc-800">
                            <Layers size={10} /> {totalItems} Peças
                        </span>
                        <span className="flex items-center gap-1">
                            <Package size={10} /> {uniqueModels} Mod
                        </span>
                    </div>
                </div>

                {/* Item Preview (Compact List) */}
                {!isFactoryMode && (
                    <div className="mb-3 bg-zinc-900/50 border border-zinc-800/50 rounded-sm p-1.5 space-y-1">
                        {order.items.slice(0, 3).map((item, idx) => (
                            <div key={idx} className="flex justify-between items-center text-[10px] leading-none">
                                <div className="flex items-center gap-1.5 truncate pr-2">
                                    <span className="text-zinc-500 w-3 text-right">{item.quantity}</span>
                                    <span className="text-zinc-400 font-medium truncate max-w-[120px]">
                                        {/* Fallback to generic name if product name isn't directly available in OrderItem without join */}
                                        Item {idx + 1} ({item.size})
                                    </span>
                                </div>
                            </div>
                        ))}
                        {order.items.length > 3 && (
                            <div className="text-[9px] text-zinc-600 text-center pt-0.5 border-t border-zinc-800/50 mt-1">
                                + {order.items.length - 3} outros itens
                            </div>
                        )}
                    </div>
                )}

                {/* Footer / Action */}
                <div className="mt-auto">
                    <button 
                        onClick={(e) => {
                            e.stopPropagation(); // Prevent card click
                            onAdvance(order);
                        }}
                        className={`w-full py-2 rounded-sm font-bold uppercase tracking-widest flex items-center justify-center gap-2 transition-all shadow-lg text-[10px] ${btnClass}`}
                    >
                        {isLastStage ? <CheckCircle size={12} /> : null}
                        {btnLabel}
                        {!isLastStage ? <ChevronRight size={12} /> : null}
                    </button>
                </div>
            </div>
        </div>
    );
};

// --- COMPLETED COLUMN ---

const CompletedColumn: React.FC<{ orders: EnrichedOrder[], onNavigate?: (view: 'orders' | 'budgets', searchTerm?: string) => void }> = ({ orders, onNavigate }) => {
    const [isExpanded, setIsExpanded] = useState(false);
    const [currentPage, setCurrentPage] = useState(1);
    const [searchTerm, setSearchTerm] = useState('');
    
    const itemsPerPage = 8;

    // Filter and Sort internally
    const filteredOrders = useMemo(() => {
        return orders.filter(o => 
            searchTerm === '' || 
            o.orderNumber.toLowerCase().includes(searchTerm.toLowerCase()) || 
            (o.clientName || '').toLowerCase().includes(searchTerm.toLowerCase())
        );
    }, [orders, searchTerm]);

    const totalPages = Math.ceil(filteredOrders.length / itemsPerPage);
    const paginatedOrders = filteredOrders.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);

    const handlePageChange = (newPage: number) => {
        if (newPage >= 1 && newPage <= totalPages) setCurrentPage(newPage);
    };

    // Reset page on search
    useEffect(() => setCurrentPage(1), [searchTerm]);

    return (
        <div className={`flex flex-col h-full bg-zinc-900 border-l-2 border-zinc-800 transition-all duration-300 ${isExpanded ? 'min-w-[320px] flex-1' : 'w-14 items-center'}`}>
            
            {/* Header: Strict height/border matching with StageColumn to avoid "steps" */}
            <div 
                className={`w-full p-4 bg-zinc-900 sticky top-0 z-10 border-b-2 ${isExpanded ? 'border-zinc-800' : 'border-transparent'}`}
            >
                <div className={`flex items-center ${isExpanded ? 'justify-between w-full' : 'justify-center flex-col gap-4'} mb-2`}>
                    <div 
                        className="flex items-center gap-2 cursor-pointer"
                        onClick={() => setIsExpanded(!isExpanded)}
                        title={isExpanded ? "Recolher" : "Expandir Pedidos Concluídos"}
                    >
                        <CheckCircle className="text-zinc-500" size={20} />
                        {isExpanded && <h3 className="text-sm font-bold text-white uppercase tracking-widest">Concluídos</h3>}
                    </div>
                    
                    {isExpanded ? (
                        <div className="flex items-center gap-2">
                            <span className="bg-zinc-800 text-white text-xs font-mono py-1 px-2 rounded-sm border border-zinc-700">{filteredOrders.length}</span>
                            <button onClick={() => setIsExpanded(false)} className="text-zinc-500 hover:text-white"><ChevronRight size={20}/></button>
                        </div>
                    ) : (
                        <div className="flex flex-col items-center gap-1">
                            <span className="text-xs font-mono text-zinc-500">{orders.length}</span>
                            <button onClick={() => setIsExpanded(true)} className="text-zinc-500 hover:text-white"><ChevronLeft size={20}/></button>
                        </div>
                    )}
                </div>

                {isExpanded && (
                    <div className="relative mt-2">
                        <input 
                            type="text" 
                            placeholder="Buscar concluídos..." 
                            className="w-full bg-zinc-950 border border-zinc-700 rounded-sm py-1.5 pl-8 pr-2 text-xs text-white outline-none focus:border-gold-500 transition-colors"
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                        />
                        <Search size={12} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-zinc-500" />
                    </div>
                )}
            </div>

            {isExpanded ? (
                <>
                    <div className="flex-1 overflow-y-auto p-4 space-y-2 bg-zinc-900/50 custom-scrollbar">
                        {paginatedOrders.map(order => {
                             const hasLink = !!(onNavigate && order.budgetSerialNumber);
                             return (
                                <div 
                                    key={order.id} 
                                    onClick={() => hasLink && onNavigate && onNavigate('budgets', order.budgetSerialNumber)}
                                    className={`
                                        bg-zinc-950 p-3 rounded-sm border border-zinc-800 flex justify-between items-center 
                                        opacity-70 hover:opacity-100 transition-all
                                        ${hasLink ? 'cursor-pointer hover:border-zinc-600 hover:bg-zinc-900' : ''}
                                    `}
                                >
                                    <div>
                                        <div className="font-mono text-xs text-zinc-500 mb-1 flex items-center gap-1">
                                            #{order.orderNumber}
                                            {hasLink && <Link size={8} className="text-zinc-600" />}
                                        </div>
                                        <div className="text-sm font-bold text-white truncate w-40">{order.clientName || 'Cliente'}</div>
                                        <div className="text-[10px] text-zinc-600 mt-1 flex items-center gap-1">
                                            <Calendar size={10} /> {formatDate(order.updatedAt || order.createdAt || '')}
                                        </div>
                                    </div>
                                    <div className="text-emerald-500">
                                        <CheckCircle size={16} />
                                    </div>
                                </div>
                             )
                        })}
                        {filteredOrders.length === 0 && <div className="text-center py-8 text-zinc-600 text-xs">Nenhum pedido encontrado.</div>}
                    </div>
                    
                    {totalPages > 1 && (
                        <div className="p-3 bg-zinc-900 border-t border-zinc-800 flex justify-between items-center">
                            <button onClick={() => handlePageChange(currentPage - 1)} disabled={currentPage === 1} className="p-1 text-zinc-400 hover:text-white disabled:opacity-30"><ChevronLeft size={16} /></button>
                            <span className="text-xs text-zinc-500 font-mono">{currentPage} / {totalPages}</span>
                            <button onClick={() => handlePageChange(currentPage + 1)} disabled={currentPage === totalPages} className="p-1 text-zinc-400 hover:text-white disabled:opacity-30"><IconRight size={16} /></button>
                        </div>
                    )}
                </>
            ) : (
                <div className="flex-1 flex items-center justify-center overflow-hidden py-8">
                     {/* Correct rotation for "Tab" style vertical text, no cutoff */}
                    <span className="transform -rotate-90 whitespace-nowrap text-[10px] text-zinc-600 font-bold uppercase tracking-widest">
                        Pedidos Finalizados
                    </span>
                </div>
            )}
        </div>
    );
};

// --- MAIN PAGE ---

interface ProductionProps {
    onNavigate?: (view: 'orders' | 'budgets', searchTerm?: string) => void;
}

const Production: React.FC<ProductionProps> = ({ onNavigate }) => {
  const [activeOrders, setActiveOrders] = useState<EnrichedOrder[]>([]);
  const [completedOrders, setCompletedOrders] = useState<EnrichedOrder[]>([]);
  const [isFactoryMode, setIsFactoryMode] = useState(false);
  const [deliveryConfirm, setDeliveryConfirm] = useState<EnrichedOrder | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Alert State (Copied from other pages)
  const [alertInfo, setAlertInfo] = useState<{ isOpen: boolean, title: string, message: string, type: 'success' | 'error' }>({ 
      isOpen: false, title: '', message: '', type: 'success' 
  });

  const showAlert = (message: string, type: 'success' | 'error' = 'error') => {
      setAlertInfo({ isOpen: true, title: type === 'error' ? 'Erro' : 'Sucesso', message, type });
      setTimeout(() => setAlertInfo(prev => ({...prev, isOpen: false})), 3000);
  };

  const loadData = async () => {
    setIsLoading(true);
    try {
        const [fetchedOrders, fetchedClients] = await Promise.all([
            storageService.getOrders(),
            storageService.getClients()
        ]);

        // Enrich orders
        const enrichedOrders: EnrichedOrder[] = fetchedOrders.map(o => {
            return {
                ...o,
                clientName: fetchedClients.find(c => c.id === o.clientId)?.companyName || 'Cliente Desconhecido',
                productionStage: o.productionStage || ProductionStage.WAITING
            };
        });

        setActiveOrders(enrichedOrders.filter(o => o.status !== OrderStatus.DELIVERED && o.status !== OrderStatus.COMPLETED));
        
        // Sort completed orders by UpdatedAt Descending (Most recent first)
        const completed = enrichedOrders
            .filter(o => o.status === OrderStatus.DELIVERED || o.status === OrderStatus.COMPLETED)
            .sort((a, b) => {
                const dateA = a.updatedAt || a.createdAt || '';
                const dateB = b.updatedAt || b.createdAt || '';
                return dateB.localeCompare(dateA);
            });
            
        setCompletedOrders(completed);
    } catch (e) {
        console.error("Erro ao carregar produção", e);
        showAlert('Falha ao carregar dados de produção. Verifique a conexão.', 'error');
    } finally {
        setIsLoading(false);
    }
  };

  useEffect(() => { loadData(); }, []);

  // Organize by Top-Level Stage
  const columns = useMemo(() => {
    const cols = {
        [ProductionStage.WAITING]: [] as EnrichedOrder[],
        [ProductionStage.CUTTING]: [] as EnrichedOrder[],
        [ProductionStage.CUSTOMIZATION]: [] as EnrichedOrder[],
        [ProductionStage.SEWING]: [] as EnrichedOrder[],
        [ProductionStage.FINISHING]: [] as EnrichedOrder[],
        [ProductionStage.LOGISTICS]: [] as EnrichedOrder[],
    };

    activeOrders.forEach(order => {
        const stage = order.productionStage || ProductionStage.WAITING;
        // @ts-ignore
        if (cols[stage]) cols[stage].push(order);
        // @ts-ignore
        else cols[ProductionStage.WAITING].push(order); // Fallback
    });

    // Sort by Deadline
    Object.keys(cols).forEach(key => {
        // @ts-ignore
        cols[key].sort((a, b) => (a.deadline || '9999').localeCompare(b.deadline || '9999'));
    });

    return cols;
  }, [activeOrders]);

  const executeStageChange = async (order: EnrichedOrder) => {
    const currentStage = order.productionStage || ProductionStage.WAITING;
    let nextStage: ProductionStage | null = null;
    let nextOrderStatus: OrderStatus = order.status;

    // Defined Flow (Extended)
    if (currentStage === ProductionStage.WAITING) nextStage = ProductionStage.CUTTING;
    else if (currentStage === ProductionStage.CUTTING) nextStage = ProductionStage.CUSTOMIZATION;
    else if (currentStage === ProductionStage.CUSTOMIZATION) nextStage = ProductionStage.SEWING;
    else if (currentStage === ProductionStage.SEWING) nextStage = ProductionStage.FINISHING;
    else if (currentStage === ProductionStage.FINISHING) nextStage = ProductionStage.LOGISTICS;
    else if (currentStage === ProductionStage.LOGISTICS) {
        // Move to Delivered/Completed
        nextStage = null; 
        nextOrderStatus = OrderStatus.DELIVERED;
    }

    // Create Updated Object
    const updatedOrder = { 
        ...order, 
        updatedAt: new Date().toISOString(),
        productionStage: nextStage || order.productionStage, // Update top level
        status: nextStage ? OrderStatus.IN_PRODUCTION : nextOrderStatus,
        // Sync items for legacy support/granularity if needed
        items: nextStage ? order.items.map(i => ({...i, productionStage: nextStage!})) : order.items
    };
    
    // Optimistic UI (Immediate feedback)
    if (nextStage) {
        setActiveOrders(prev => prev.map(o => o.id === order.id ? updatedOrder : o));
    } else {
        setActiveOrders(prev => prev.filter(o => o.id !== order.id));
        setCompletedOrders(prev => [updatedOrder, ...prev].sort((a, b) => (b.updatedAt || '').localeCompare(a.updatedAt || '')));
    }

    // DB Persist (Remove UI-only prop)
    const { clientName, ...orderToSave } = updatedOrder;
    
    try {
        await storageService.saveOrder(orderToSave);
    } catch (e) {
        console.error("Erro ao salvar estágio:", e);
        showAlert('Erro ao salvar alteração. Recarregue a página.', 'error');
        // Optional: Revert optimistic UI here if needed, but for now strict alert is enough
        loadData(); // Reload to sync with server state
    }
  }

  const handleAdvanceStage = (order: EnrichedOrder) => {
    const stage = order.productionStage || ProductionStage.WAITING;
    
    // Last active stage is now LOGISTICS
    if (stage === ProductionStage.LOGISTICS) {
        setDeliveryConfirm(order);
    } else {
        executeStageChange(order);
    }
  };

  const onConfirmDelivery = () => {
    if (deliveryConfirm) {
        executeStageChange(deliveryConfirm);
        setDeliveryConfirm(null);
    }
  };

  const StageColumn = ({ stage, title, icon: Icon, colorClass }: { stage: ProductionStage, title: string, icon: any, colorClass: string }) => {
    // @ts-ignore
    const stageOrders = columns[stage] || [];
    return (
        <div className="flex-1 min-w-[320px] flex flex-col h-full bg-zinc-900 border-r border-zinc-800 last:border-r-0">
            <div className={`p-4 border-b-2 ${colorClass} bg-zinc-900 sticky top-0 z-10`}>
                <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                        <Icon className="text-zinc-400" size={20} />
                        <h3 className="text-sm font-bold text-white uppercase tracking-widest">{title}</h3>
                    </div>
                    <span className="bg-zinc-800 text-white text-xs font-mono py-1 px-2 rounded-sm border border-zinc-700">{stageOrders.length}</span>
                </div>
            </div>
            <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-zinc-900/50 custom-scrollbar">
                {stageOrders.map((order: EnrichedOrder) => (
                    <ProductionCard 
                        key={order.id} 
                        order={order} 
                        stage={stage}
                        onAdvance={handleAdvanceStage} 
                        onNavigate={onNavigate}
                        isFactoryMode={isFactoryMode} 
                    />
                ))}
                {stageOrders.length === 0 && (
                    <div className="h-32 flex flex-col items-center justify-center text-zinc-700 opacity-50 border-2 border-dashed border-zinc-800 rounded-sm">
                        <span className="text-xs uppercase font-bold">Vazio</span>
                    </div>
                )}
            </div>
        </div>
    );
  };

  return (
    <div className={`flex flex-col h-full bg-zinc-950 ${isFactoryMode ? 'fixed inset-0 z-50' : 'relative'}`}>
      
      {isLoading && <div className="absolute top-20 right-8 z-[60] bg-blue-600 px-4 py-2 rounded text-white text-xs font-bold animate-pulse">Carregando Produção...</div>}

      <div className="h-16 shrink-0 border-b border-zinc-800 bg-zinc-950 flex items-center justify-between px-6">
        <div className="flex items-center gap-4">
            <h1 className="text-2xl font-bold text-white tracking-tight flex items-center gap-3">
                <Factory size={24} className="text-gold-500" />
                LINHA DE PRODUÇÃO
            </h1>
        </div>
        <div className="flex items-center gap-4">
            <div className="hidden md:flex items-center gap-4 mr-4 text-[10px] uppercase font-bold text-zinc-500">
                <div className="flex items-center gap-1"><div className="w-2 h-2 rounded-full bg-zinc-700"></div> No Prazo</div>
                <div className="flex items-center gap-1"><div className="w-2 h-2 rounded-full bg-yellow-500"></div> Atenção</div>
                <div className="flex items-center gap-1"><div className="w-2 h-2 rounded-full bg-red-500"></div> Atrasado</div>
            </div>
            <button onClick={() => setIsFactoryMode(!isFactoryMode)} className={`flex items-center gap-2 px-4 py-2 rounded-sm font-bold uppercase text-xs transition-all ${isFactoryMode ? 'bg-gold-500 text-black' : 'bg-zinc-800 text-white border border-zinc-700'}`}>
                {isFactoryMode ? <Minimize2 size={16} /> : <Maximize2 size={16} />}
                {isFactoryMode ? 'Sair do Modo Fábrica' : 'Modo Fábrica'}
            </button>
        </div>
      </div>

      <div className="flex-1 flex overflow-hidden">
          <div className="flex-1 flex overflow-x-auto overflow-y-hidden snap-x">
            <StageColumn stage={ProductionStage.WAITING} title="Aguardando Materiais" icon={Box} colorClass="border-zinc-500" />
            <StageColumn stage={ProductionStage.CUTTING} title="Corte" icon={Scissors} colorClass="border-orange-500" />
            <StageColumn stage={ProductionStage.CUSTOMIZATION} title="Personalização" icon={Palette} colorClass="border-pink-500" />
            <StageColumn stage={ProductionStage.SEWING} title="Costura" icon={Shirt} colorClass="border-blue-500" />
            <StageColumn stage={ProductionStage.FINISHING} title="Finalização" icon={CheckSquare} colorClass="border-purple-500" />
            <StageColumn stage={ProductionStage.LOGISTICS} title="Transporte" icon={Truck} colorClass="border-emerald-500" />
          </div>
          <CompletedColumn orders={completedOrders} onNavigate={onNavigate} />
      </div>

      {/* CONFIRMATION MODAL */}
      {deliveryConfirm && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-[60] p-4 backdrop-blur-sm animate-in fade-in zoom-in-95">
            <div className="bg-zinc-900 border border-zinc-800 rounded-sm shadow-2xl max-w-sm w-full p-6 text-center">
                <div className="w-16 h-16 bg-emerald-900/20 text-emerald-500 rounded-full flex items-center justify-center mx-auto mb-4 border border-emerald-900/50">
                    <CheckCircle size={32} />
                </div>
                <h3 className="text-lg font-bold text-white mb-2">Confirmar Entrega</h3>
                <p className="text-zinc-400 text-sm mb-6">
                    O pedido <b>#{deliveryConfirm.orderNumber}</b> será marcado como entregue e movido para o histórico.
                </p>
                <div className="flex gap-3">
                    <button 
                        onClick={() => setDeliveryConfirm(null)}
                        className="flex-1 bg-zinc-800 hover:bg-zinc-700 text-white py-3 rounded-sm font-bold text-xs uppercase tracking-wide transition-colors"
                    >
                        Cancelar
                    </button>
                    <button 
                        onClick={onConfirmDelivery}
                        className="flex-1 bg-emerald-600 hover:bg-emerald-500 text-white py-3 rounded-sm font-bold text-xs uppercase tracking-wide transition-colors"
                    >
                        Confirmar
                    </button>
                </div>
            </div>
        </div>
      )}

      {/* ALERT TOAST */}
      {alertInfo.isOpen && (
          <div className={`fixed bottom-4 right-4 px-4 py-3 rounded-sm border flex items-center gap-3 shadow-2xl z-[70] animate-in slide-in-from-bottom-5 duration-300 ${alertInfo.type === 'success' ? 'bg-emerald-950 border-emerald-900 text-emerald-500' : 'bg-red-950 border-red-900 text-red-500'}`}>
              {alertInfo.type === 'success' ? <CheckCircle size={20} /> : <AlertTriangle size={20} />}
              <div>
                  <h4 className="font-bold text-xs uppercase">{alertInfo.title}</h4>
                  <p className="text-sm">{alertInfo.message}</p>
              </div>
          </div>
      )}
    </div>
  );
};

export default Production;
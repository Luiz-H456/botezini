import React, { useState, useEffect, useMemo } from 'react';
import { storageService } from '../services/storage';
import { pdfService } from '../services/pdfService';
import { idService } from '../services/idService';
import { budgetService } from '../services/budgetService';
import { Budget, Product, Client, Order, OrderStatus, ProductionStage, BudgetItem, BudgetCustomization, BudgetExtra, CompanyProfile, PaymentStatus } from '../types';
import { formatCurrency, formatDate, isBudgetExpired, getTodayStr, isDateInPeriod, addBusinessDays, countBusinessDays } from '../utils';
import { FileText, Plus, Printer, ArrowRight, Save, X, AlertTriangle, Link, Lock, Search, Filter, Truck, Copy, ChevronLeft, Calendar, User, Percent, DollarSign, Trash2, CheckSquare, Edit2, Package, CheckCircle, Info, ChevronRight, ListFilter } from 'lucide-react';

// --- CONTROLLER HOOK ---
const useBudgetController = (initialSearch?: string, clearSearch?: () => void) => {
  const [budgets, setBudgets] = useState<Budget[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [clients, setClients] = useState<Client[]>([]);
  const [companyProfile, setCompanyProfile] = useState<CompanyProfile | null>(null);
  
  const [searchTerm, setSearchTerm] = useState('');
  const [filterClient, setFilterClient] = useState('ALL');
  const [filterStatus, setFilterStatus] = useState('ALL');
  const [filterPeriod, setFilterPeriod] = useState<'ALL' | 'DAY' | 'WEEK' | 'MONTH'>('ALL');

  const loadData = async () => {
    try {
        const [b, p, c, profile, o] = await Promise.all([
            storageService.getBudgets(),
            storageService.getProducts(),
            storageService.getClients(),
            storageService.getCompanyProfile(),
            storageService.getOrders()
        ]);
        setBudgets(b);
        setOrders(o);
        setProducts(p);
        setClients(c);
        setCompanyProfile(profile);
    } catch (e) {
        console.error("Budgets Load Error:", e);
    }
  };

  useEffect(() => { loadData(); }, []);

  useEffect(() => {
      if (initialSearch) { setSearchTerm(initialSearch); if (clearSearch) clearSearch(); }
  }, [initialSearch, clearSearch]);

  const processedBudgets = useMemo(() => {
    // 1. Filter
    const filtered = budgets.filter(b => {
      if (searchTerm && !b.serialNumber.toLowerCase().includes(searchTerm.toLowerCase()) && 
          !b.generatedOrderNumber?.toLowerCase().includes(searchTerm.toLowerCase())) return false;
      if (filterClient !== 'ALL' && b.clientId !== filterClient) return false;
      if (filterStatus !== 'ALL' && b.status !== filterStatus) return false;
      if (!isDateInPeriod(b.date, filterPeriod)) return false;
      return true;
    });

    // 2. Sort: Drafts First -> Then Date Descending (Newest First)
    return filtered.sort((a, b) => {
        // Priority to Drafts
        if (a.status === 'Draft' && b.status !== 'Draft') return -1;
        if (a.status !== 'Draft' && b.status === 'Draft') return 1;
        
        // Then compare dates (string YYYY-MM-DD comparison works for ISO)
        // If dates are equal, fallback to serialNumber desc
        const dateComparison = b.date.localeCompare(a.date);
        if (dateComparison !== 0) return dateComparison;
        
        return b.serialNumber.localeCompare(a.serialNumber);
    });
  }, [budgets, searchTerm, filterClient, filterStatus, filterPeriod]);

  // Returns a fresh object copy for the editor (does not save to DB)
  const prepareDuplicate = async (budget: Budget): Promise<Budget> => {
      const newSerial = await idService.getNextSequence('budget');
      return {
          ...budget,
          id: '', // Empty ID triggers creation flow in Editor
          serialNumber: newSerial,
          date: getTodayStr(),
          status: 'Draft',
          generatedOrderNumber: undefined,
          // Deep copy items with new IDs for sub-entities to prevent React key collision or reference issues
          customizations: (budget.customizations || []).map(c => ({...c, id: crypto.randomUUID()})),
          extras: (budget.extras || []).map(e => ({...e, id: crypto.randomUUID()})),
          items: (budget.items || []).map(i => ({...i})), // Shallow copy items is enough as they don't have IDs
          createdAt: undefined,
          updatedAt: undefined
      };
  };

  const deleteBudget = async (id: string) => {
      await storageService.deleteBudget(id);
      await loadData();
  };

  return {
      budgets: processedBudgets, orders, products, clients, companyProfile,
      searchTerm, setSearchTerm, 
      filterClient, setFilterClient, 
      filterStatus, setFilterStatus,
      filterPeriod, setFilterPeriod,
      refresh: loadData,
      prepareDuplicate,
      deleteBudget
  };
};

// --- EDITOR COMPONENT ---

interface BudgetEditorProps {
    budget?: Budget | null;
    clients: Client[];
    products: Product[];
    onClose: () => void;
    onSave: (budget: Budget) => Promise<void>;
    showToast: (msg: string, type?: 'error' | 'success') => void;
}

const BudgetEditor: React.FC<BudgetEditorProps> = ({ budget, clients, products, onClose, onSave, showToast }) => {
    // Local State Initialization
    const [headerInfo, setHeaderInfo] = useState({ 
        serialNumber: '', date: getTodayStr(), validity: 15, status: 'Draft' as const 
    });
    const [selectedClientId, setSelectedClientId] = useState('');
    const [items, setItems] = useState<BudgetItem[]>([]);
    const [customizations, setCustomizations] = useState<BudgetCustomization[]>([]);
    const [extras, setExtras] = useState<BudgetExtra[]>([]);
    const [discount, setDiscount] = useState<number>(0); 
    const [paymentInfo, setPaymentInfo] = useState({ downPaymentPercent: 50, notes: '' });
    const [deliveryTimeDays, setDeliveryTimeDays] = useState<number>(20);
    const [isSaving, setIsSaving] = useState(false);

    // Initialize form data
    useEffect(() => {
        const init = async () => {
            if (budget) {
                setHeaderInfo({ serialNumber: budget.serialNumber, date: budget.date, validity: budget.validityDays, status: budget.status as any });
                setSelectedClientId(budget.clientId);
                setItems(budget.items || []);
                setCustomizations(budget.customizations || []);
                setExtras(budget.extras || []);
                setDiscount(budget.discount || 0);
                setPaymentInfo({ downPaymentPercent: budget.downPaymentPercent, notes: budget.notes || '' });
                setDeliveryTimeDays(budget.deliveryTimeDays || 20);
            } else {
                const serial = await idService.getNextSequence('budget');
                setHeaderInfo(prev => ({ ...prev, serialNumber: serial }));
            }
        };
        init();
    }, [budget]);

    // Live Calculations
    const totals = useMemo(() => 
        budgetService.calculateTotals(items, customizations, extras, discount), 
    [items, customizations, extras, discount]);

    const payments = useMemo(() => 
        budgetService.calculatePayments(totals.totalAmount, paymentInfo.downPaymentPercent),
    [totals.totalAmount, paymentInfo.downPaymentPercent]);

    // Handlers
    const handleSave = async () => {
        if (!selectedClientId) { showToast('Selecione um cliente', 'error'); return; }
        if (items.length === 0 && customizations.length === 0) { showToast('Adicione itens ou serviços ao orçamento.', 'error'); return; }
        
        setIsSaving(true);
        const payload: Budget = {
            id: budget?.id || '',
            serialNumber: headerInfo.serialNumber,
            clientId: selectedClientId,
            date: headerInfo.date,
            items, customizations, extras,
            subtotalItems: totals.subtotalItems,
            subtotalCustomizations: totals.subtotalCustom,
            subtotalExtras: totals.subtotalExtras,
            discount,
            totalAmount: totals.totalAmount,
            downPaymentPercent: paymentInfo.downPaymentPercent,
            downPaymentValue: payments.downPaymentValue,
            deliveryPaymentValue: payments.deliveryPaymentValue,
            validityDays: headerInfo.validity,
            deliveryTimeDays,
            notes: paymentInfo.notes,
            status: headerInfo.status
        };
        await onSave(payload);
        setIsSaving(false);
    };

    const updateItem = (index: number, field: keyof BudgetItem, value: any) => {
        const newItems = [...items];
        const item = { ...newItems[index] };
        if (field === 'productId') {
            const prod = products.find(p => p.id === value);
            if (prod) { 
                item.productId = prod.id; 
                item.productName = prod.name; 
                item.unitPrice = prod.priceTier1 || 0; 
                item.model = ''; // Reset model if product changes
            }
        } else {
            (item as any)[field] = value;
        }
        item.total = (item.quantity || 0) * (item.unitPrice || 0);
        newItems[index] = item;
        setItems(newItems);
    };

    // JSX Helpers
    const SectionHeader = ({ title, onAdd }: { title: string, onAdd: () => void }) => (
        <div className="flex justify-between items-center mt-6 mb-2 px-1">
            <h3 className="text-xs font-bold text-zinc-400 uppercase tracking-widest flex items-center gap-2">
                <div className="w-1 h-3 bg-gold-500 rounded-full"></div> {title}
            </h3>
            <button onClick={onAdd} className="text-[10px] bg-zinc-800 hover:bg-zinc-700 text-gold-500 font-bold px-3 py-1 rounded-sm flex items-center gap-1 transition-colors border border-zinc-700">
                <Plus size={12} /> ADICIONAR
            </button>
        </div>
    );

    return (
        <div className="absolute inset-0 bg-zinc-950 z-50 flex flex-col w-full h-full animate-in fade-in zoom-in-95 duration-200">
            {/* 1. TOP BAR (Fixed) */}
            <div className="h-14 border-b border-zinc-800 bg-zinc-900 flex justify-between items-center px-4 shrink-0 shadow-sm z-20">
                <div className="flex items-center gap-4">
                    <button onClick={onClose} className="text-zinc-400 hover:text-white transition-colors p-1 rounded-md hover:bg-zinc-800">
                        <ChevronLeft size={24} />
                    </button>
                    <div>
                         <div className="flex items-center gap-2">
                             <h2 className="text-lg font-bold text-white leading-none">{headerInfo.serialNumber}</h2>
                             {/* Display 'Novo' if no ID (new or duplicate copy), otherwise 'Editando' */}
                             <span className="text-[10px] bg-zinc-800 text-zinc-400 px-1.5 py-0.5 rounded border border-zinc-700">
                                {budget && budget.id ? 'Editando' : 'Novo'}
                             </span>
                         </div>
                    </div>
                </div>

                {/* Identification Compact Inline Form */}
                <div className="hidden md:flex items-center gap-4 bg-zinc-950/50 p-1.5 rounded-sm border border-zinc-800/50">
                    <div className="flex items-center gap-2 px-2 border-r border-zinc-800">
                        <User size={14} className="text-zinc-500" />
                        <select value={selectedClientId} onChange={e => setSelectedClientId(e.target.value)} className="bg-transparent text-sm text-white outline-none w-48 cursor-pointer hover:text-gold-500 transition-colors">
                            <option value="" className="bg-zinc-900 text-zinc-400">Selecione o Cliente...</option>
                            {clients.map(c => <option key={c.id} value={c.id} className="bg-zinc-900 text-zinc-200">{c.companyName}</option>)}
                        </select>
                    </div>
                    <div className="flex items-center gap-2 px-2 border-r border-zinc-800">
                        <Calendar size={14} className="text-zinc-500" />
                        <input type="date" value={headerInfo.date} onChange={e => setHeaderInfo({...headerInfo, date: e.target.value})} className="bg-transparent text-sm text-zinc-300 outline-none w-28 text-center cursor-pointer" />
                    </div>
                     <div className="flex items-center gap-2 px-2">
                        <span className="text-[10px] uppercase font-bold text-zinc-500">Validade</span>
                        <input type="number" value={headerInfo.validity} onChange={e => setHeaderInfo({...headerInfo, validity: parseInt(e.target.value)})} className="bg-transparent text-sm text-zinc-300 outline-none w-10 text-center border-b border-zinc-700 focus:border-gold-500 transition-colors" />
                        <span className="text-[10px] text-zinc-600">Dias</span>
                    </div>
                </div>

                <div className="flex items-center gap-3">
                    <button 
                        onClick={handleSave} 
                        disabled={isSaving}
                        className="bg-gold-600 hover:bg-gold-500 text-black px-6 py-2 rounded-sm font-bold uppercase text-xs flex items-center gap-2 transition-all disabled:opacity-50 shadow-lg shadow-gold-900/20"
                    >
                        <Save size={16} /> {isSaving ? 'Salvando...' : 'Salvar'}
                    </button>
                </div>
            </div>

            {/* 2. SCROLLABLE CONTENT */}
            <div className="flex-1 overflow-y-auto bg-zinc-950 p-4 md:px-8 custom-scrollbar">
                <div className="max-w-7xl mx-auto space-y-1 pb-24">
                    
                    {/* ITEMS TABLE - DENSE LOOK */}
                    <SectionHeader title="Itens" onAdd={() => setItems([...items, { productId: '', productName: '', model: '', fabric: '', color: '', size: 'M', quantity: 10, unitPrice: 0, total: 0 }])} />
                    
                    {/* Changed overflow-hidden to allow delete button to float out */}
                    <div className="border border-zinc-800 rounded-sm bg-zinc-900/30">
                        {/* Table Header */}
                        <div className="grid grid-cols-12 gap-px bg-zinc-900 border-b border-zinc-800 text-[10px] font-bold text-zinc-500 uppercase tracking-wider text-center">
                            <div className="col-span-3 py-2 text-left pl-3">Produto</div>
                            <div className="col-span-2 py-2">Modelo/Ref</div>
                            <div className="col-span-2 py-2">Tecido</div>
                            <div className="col-span-1 py-2">Cor</div>
                            <div className="col-span-1 py-2">Tam</div>
                            <div className="col-span-1 py-2">Qtd</div>
                            <div className="col-span-1 py-2 text-right">Unit (R$)</div>
                            <div className="col-span-1 py-2 text-right pr-3">Total</div>
                        </div>

                        {/* Rows */}
                        {items.length > 0 ? (
                            <div className="divide-y divide-zinc-800/50">
                                {items.map((item, i) => (
                                    <div key={i} className="grid grid-cols-12 gap-px items-center hover:bg-zinc-900/80 transition-colors group relative">
                                        <div className="col-span-3 p-1">
                                            <select value={item.productId} onChange={e => updateItem(i, 'productId', e.target.value)} className="w-full bg-transparent text-white text-xs p-1.5 rounded-sm outline-none border border-transparent hover:border-zinc-700 focus:border-gold-500 focus:bg-zinc-950 transition-all cursor-pointer">
                                                <option value="" className="bg-zinc-900 text-zinc-500">Selecione...</option>
                                                {products.map(p => <option key={p.id} value={p.id} className="bg-zinc-900 text-zinc-200">{p.name}</option>)}
                                            </select>
                                        </div>
                                        <div className="col-span-2 p-1"><input placeholder="-" value={item.model} onChange={e => updateItem(i, 'model', e.target.value)} className="w-full bg-transparent text-zinc-300 text-xs p-1.5 rounded-sm outline-none border border-transparent hover:border-zinc-700 focus:border-gold-500 focus:bg-zinc-950 text-center" /></div>
                                        <div className="col-span-2 p-1"><input placeholder="-" value={item.fabric} onChange={e => updateItem(i, 'fabric', e.target.value)} className="w-full bg-transparent text-zinc-300 text-xs p-1.5 rounded-sm outline-none border border-transparent hover:border-zinc-700 focus:border-gold-500 focus:bg-zinc-950 text-center" /></div>
                                        <div className="col-span-1 p-1"><input placeholder="-" value={item.color} onChange={e => updateItem(i, 'color', e.target.value)} className="w-full bg-transparent text-zinc-300 text-xs p-1.5 rounded-sm outline-none border border-transparent hover:border-zinc-700 focus:border-gold-500 focus:bg-zinc-950 text-center" /></div>
                                        <div className="col-span-1 p-1"><input placeholder="M" value={item.size} onChange={e => updateItem(i, 'size', e.target.value)} className="w-full bg-transparent text-zinc-300 text-xs p-1.5 rounded-sm outline-none border border-transparent hover:border-zinc-700 focus:border-gold-500 focus:bg-zinc-950 text-center" /></div>
                                        <div className="col-span-1 p-1"><input type="number" value={item.quantity} onChange={e => updateItem(i, 'quantity', parseFloat(e.target.value))} className="w-full bg-transparent text-white font-bold text-xs p-1.5 rounded-sm outline-none border border-transparent hover:border-zinc-700 focus:border-gold-500 focus:bg-zinc-950 text-center" /></div>
                                        <div className="col-span-1 p-1"><input type="number" value={item.unitPrice} onChange={e => updateItem(i, 'unitPrice', parseFloat(e.target.value))} className="w-full bg-transparent text-zinc-300 text-xs p-1.5 rounded-sm outline-none border border-transparent hover:border-zinc-700 focus:border-gold-500 focus:bg-zinc-950 text-right" /></div>
                                        <div className="col-span-1 p-1 pr-3 flex justify-end items-center">
                                            <span className="text-xs font-mono text-white">{formatCurrency(item.total)}</span>
                                        </div>
                                        {/* Floating Delete Button */}
                                        <button 
                                            onClick={() => setItems(items.filter((_, idx) => idx !== i))} 
                                            className="absolute -right-8 top-1/2 -translate-y-1/2 text-zinc-600 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-all p-2"
                                            title="Excluir Item"
                                        >
                                            <Trash2 size={16} />
                                        </button>
                                    </div>
                                ))}
                            </div>
                        ) : (
                            <div className="py-8 text-center text-zinc-600 text-xs border-t border-zinc-800 border-dashed">Nenhum item adicionado.</div>
                        )}
                    </div>

                    {/* CUSTOMIZATIONS */}
                    <SectionHeader title="Personalizações" onAdd={() => setCustomizations([...customizations, { id: crypto.randomUUID(), type: 'Embroidery', description: '', position: '', quantity: 1, unitPrice: 0, total: 0 }])} />
                    
                    {customizations.length > 0 && (
                        <div className="border border-zinc-800 rounded-sm bg-zinc-900/30">
                             <div className="grid grid-cols-12 gap-px bg-zinc-900 border-b border-zinc-800 text-[10px] font-bold text-zinc-500 uppercase tracking-wider text-center">
                                <div className="col-span-2 py-2 text-left pl-3">Tipo</div>
                                <div className="col-span-4 py-2">Descrição</div>
                                <div className="col-span-2 py-2">Posição</div>
                                <div className="col-span-1 py-2">Qtd</div>
                                <div className="col-span-2 py-2 text-right">Unit (R$)</div>
                                <div className="col-span-1 py-2 text-right pr-3">Total</div>
                            </div>
                            <div className="divide-y divide-zinc-800/50">
                                {customizations.map((custom, i) => (
                                    <div key={custom.id} className="grid grid-cols-12 gap-px items-center hover:bg-zinc-900/80 transition-colors group relative">
                                        <div className="col-span-2 p-1">
                                            <select value={custom.type} onChange={e => { const newC = [...customizations]; newC[i].type = e.target.value as any; setCustomizations(newC); }} className="w-full bg-transparent text-white text-xs p-1.5 rounded-sm outline-none border border-transparent hover:border-zinc-700 focus:border-gold-500 focus:bg-zinc-950 cursor-pointer">
                                                <option value="Embroidery" className="bg-zinc-900 text-zinc-200">Bordado</option>
                                                <option value="ScreenPrint" className="bg-zinc-900 text-zinc-200">Silk/Estampa</option>
                                                <option value="DTF" className="bg-zinc-900 text-zinc-200">DTF</option>
                                                <option value="Other" className="bg-zinc-900 text-zinc-200">Outro</option>
                                            </select>
                                        </div>
                                        <div className="col-span-4 p-1"><input placeholder="Ex: Logo Peito 10cm" value={custom.description} onChange={e => { const newC = [...customizations]; newC[i].description = e.target.value; setCustomizations(newC); }} className="w-full bg-transparent text-zinc-300 text-xs p-1.5 rounded-sm outline-none border border-transparent hover:border-zinc-700 focus:border-gold-500 focus:bg-zinc-950" /></div>
                                        <div className="col-span-2 p-1"><input placeholder="Ex: Peito Esq" value={custom.position} onChange={e => { const newC = [...customizations]; newC[i].position = e.target.value; setCustomizations(newC); }} className="w-full bg-transparent text-zinc-300 text-xs p-1.5 rounded-sm outline-none border border-transparent hover:border-zinc-700 focus:border-gold-500 focus:bg-zinc-950 text-center" /></div>
                                        <div className="col-span-1 p-1"><input type="number" value={custom.quantity} onChange={e => { const newC = [...customizations]; newC[i].quantity = parseFloat(e.target.value); newC[i].total = newC[i].quantity * newC[i].unitPrice; setCustomizations(newC); }} className="w-full bg-transparent text-white font-bold text-xs p-1.5 rounded-sm outline-none border border-transparent hover:border-zinc-700 focus:border-gold-500 focus:bg-zinc-950 text-center" /></div>
                                        <div className="col-span-2 p-1"><input type="number" value={custom.unitPrice} onChange={e => { const newC = [...customizations]; newC[i].unitPrice = parseFloat(e.target.value); newC[i].total = newC[i].quantity * newC[i].unitPrice; setCustomizations(newC); }} className="w-full bg-transparent text-zinc-300 text-xs p-1.5 rounded-sm outline-none border border-transparent hover:border-zinc-700 focus:border-gold-500 focus:bg-zinc-950 text-right" /></div>
                                        <div className="col-span-1 p-1 pr-3 flex justify-end items-center">
                                            <span className="text-xs font-mono text-white">{formatCurrency(custom.total)}</span>
                                        </div>
                                        {/* Floating Delete Button */}
                                        <button onClick={() => setCustomizations(customizations.filter((_, idx) => idx !== i))} className="absolute -right-8 top-1/2 -translate-y-1/2 text-zinc-600 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-all p-2">
                                            <Trash2 size={16} />
                                        </button>
                                    </div>
                                ))}
                            </div>
                        </div>
                    )}

                    {/* EXTRAS */}
                    <SectionHeader title="Extras / Serviços" onAdd={() => setExtras([...extras, { id: crypto.randomUUID(), description: '', quantity: 1, unitPrice: 0, total: 0 }])} />
                    
                    {extras.length > 0 && (
                        <div className="border border-zinc-800 rounded-sm bg-zinc-900/30">
                            <div className="grid grid-cols-12 gap-px bg-zinc-900 border-b border-zinc-800 text-[10px] font-bold text-zinc-500 uppercase tracking-wider text-center">
                                <div className="col-span-8 py-2 text-left pl-3">Descrição</div>
                                <div className="col-span-1 py-2">Qtd</div>
                                <div className="col-span-2 py-2 text-right">Unit (R$)</div>
                                <div className="col-span-1 py-2 text-right pr-3">Total</div>
                            </div>
                            <div className="divide-y divide-zinc-800/50">
                                {extras.map((extra, i) => (
                                    <div key={extra.id} className="grid grid-cols-12 gap-px items-center hover:bg-zinc-900/80 transition-colors group relative">
                                        <div className="col-span-8 p-1"><input placeholder="Descrição do Serviço ou Extra" value={extra.description} onChange={e => { const newE = [...extras]; newE[i].description = e.target.value; setExtras(newE); }} className="w-full bg-transparent text-zinc-300 text-xs p-1.5 rounded-sm outline-none border border-transparent hover:border-zinc-700 focus:border-gold-500 focus:bg-zinc-950" /></div>
                                        <div className="col-span-1 p-1"><input type="number" value={extra.quantity} onChange={e => { const newE = [...extras]; newE[i].quantity = parseFloat(e.target.value); newE[i].total = newE[i].quantity * newE[i].unitPrice; setExtras(newE); }} className="w-full bg-transparent text-white font-bold text-xs p-1.5 rounded-sm outline-none border border-transparent hover:border-zinc-700 focus:border-gold-500 focus:bg-zinc-950 text-center" /></div>
                                        <div className="col-span-2 p-1"><input type="number" value={extra.unitPrice} onChange={e => { const newE = [...extras]; newE[i].unitPrice = parseFloat(e.target.value); newE[i].total = newE[i].quantity * newE[i].unitPrice; setExtras(newE); }} className="w-full bg-transparent text-zinc-300 text-xs p-1.5 rounded-sm outline-none border border-transparent hover:border-zinc-700 focus:border-gold-500 focus:bg-zinc-950 text-right" /></div>
                                        <div className="col-span-1 p-1 pr-3 flex justify-end items-center">
                                            <span className="text-xs font-mono text-white">{formatCurrency(extra.total)}</span>
                                        </div>
                                        {/* Floating Delete Button */}
                                        <button onClick={() => setExtras(extras.filter((_, idx) => idx !== i))} className="absolute -right-8 top-1/2 -translate-y-1/2 text-zinc-600 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-all p-2">
                                            <Trash2 size={16} />
                                        </button>
                                    </div>
                                ))}
                            </div>
                        </div>
                    )}
                </div>
            </div>

            {/* 3. STICKY FOOTER (Optimized) */}
            <div className="border-t border-zinc-800 bg-zinc-900 p-2 shrink-0 z-20">
                <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
                    
                    {/* Left: Inputs Grouped */}
                    <div className="flex items-center gap-4 bg-zinc-950/50 p-2 rounded-sm border border-zinc-800/50">
                        <div className="flex items-center gap-2 px-2 border-r border-zinc-800">
                             <Truck size={14} className="text-zinc-500" />
                             <span className="text-[10px] uppercase font-bold text-zinc-500">Entrega</span>
                             <input type="number" value={deliveryTimeDays} onChange={e => setDeliveryTimeDays(parseInt(e.target.value))} className="w-10 bg-transparent text-sm text-center text-white border-b border-zinc-700 focus:border-gold-500 outline-none transition-colors" />
                             <span className="text-[10px] text-zinc-600">dias</span>
                        </div>
                        <div className="flex items-center gap-2 px-2 border-r border-zinc-800">
                             <Percent size={14} className="text-zinc-500" />
                             <span className="text-[10px] uppercase font-bold text-zinc-500">Entrada</span>
                             <input type="number" value={paymentInfo.downPaymentPercent} onChange={e => setPaymentInfo({...paymentInfo, downPaymentPercent: parseFloat(e.target.value)})} className="w-10 bg-transparent text-sm text-center text-white border-b border-zinc-700 focus:border-gold-500 outline-none transition-colors" />
                             <span className="text-[10px] text-zinc-600">%</span>
                        </div>
                        <div className="flex items-center gap-2 px-2">
                             <DollarSign size={14} className="text-zinc-500" />
                             <span className="text-[10px] uppercase font-bold text-zinc-500">Desconto</span>
                             <input type="number" value={discount} onChange={e => setDiscount(parseFloat(e.target.value))} className="w-16 bg-transparent text-sm text-right text-red-400 font-bold border-b border-zinc-700 focus:border-red-500 outline-none transition-colors" placeholder="0.00" />
                        </div>
                    </div>

                    {/* Right: Totals */}
                    <div className="flex items-center gap-6 pr-4">
                        <div className="text-right hidden md:block">
                            <span className="text-[10px] text-zinc-500 uppercase font-bold block">Subtotal</span>
                            <span className="text-xs text-zinc-400 font-mono">{formatCurrency(totals.subtotalItems + totals.subtotalCustom + totals.subtotalExtras)}</span>
                        </div>
                        <div className="h-8 w-px bg-zinc-800 hidden md:block"></div>
                        <div className="text-right">
                            <span className="text-[10px] text-zinc-500 uppercase font-bold block">Total Geral</span>
                            <span className="text-2xl text-white font-bold tracking-tight">{formatCurrency(totals.totalAmount)}</span>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    );
};

interface Props {
    onNavigate?: (view: 'orders' | 'budgets', searchTerm?: string) => void;
    initialSearch?: string;
    clearSearch?: () => void;
}

interface DialogState {
    isOpen: boolean;
    type: 'confirm' | 'alert';
    title: string;
    message: string;
    variant?: 'danger' | 'success' | 'info';
    onConfirm?: () => void;
}

const Budgets: React.FC<Props> = ({ onNavigate, initialSearch, clearSearch }) => {
    const { 
        budgets, clients, products, companyProfile,
        searchTerm, setSearchTerm, 
        filterClient, setFilterClient, 
        filterStatus, setFilterStatus,
        filterPeriod, setFilterPeriod,
        refresh, prepareDuplicate, deleteBudget
    } = useBudgetController(initialSearch, clearSearch);

    const [isEditorOpen, setIsEditorOpen] = useState(false);
    const [editingBudget, setEditingBudget] = useState<Budget | null>(null);

    // Pagination State
    const [currentPage, setCurrentPage] = useState(1);
    const itemsPerPage = 10;
    
    // Reset page when filters change
    useEffect(() => { setCurrentPage(1); }, [searchTerm, filterClient, filterPeriod, filterStatus]);

    // Dialog State
    const [dialog, setDialog] = useState<DialogState>({ isOpen: false, type: 'alert', title: '', message: '' });

    // Pagination Logic
    const totalPages = Math.ceil(budgets.length / itemsPerPage);
    const paginatedBudgets = budgets.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);

    const openConfirm = (title: string, message: string, onConfirm: () => void, variant: 'danger' | 'success' | 'info' = 'danger') => {
        setDialog({ isOpen: true, type: 'confirm', title, message, onConfirm, variant });
    };

    const openAlert = (message: string, type: 'error' | 'success' = 'error') => {
        setDialog({ 
            isOpen: true, 
            type: 'alert', 
            title: type === 'error' ? 'Atenção' : 'Sucesso', 
            message, 
            variant: type === 'error' ? 'danger' : 'success' 
        });
    };

    const handleOpenEditor = (budget?: Budget) => {
        setEditingBudget(budget || null);
        setIsEditorOpen(true);
    };

    const handleDuplicateClick = (budget: Budget) => {
        openConfirm(
            'Duplicar Orçamento',
            `Deseja duplicar o orçamento ${budget.serialNumber}?`,
            async () => {
                const newBudget = await prepareDuplicate(budget);
                handleOpenEditor(newBudget);
                setDialog(prev => ({...prev, isOpen: false}));
            },
            'info'
        );
    };

    const handleSaveBudget = async (budgetToSave: Budget) => {
        await storageService.saveBudget(budgetToSave);
        setIsEditorOpen(false);
        refresh();
        openAlert('Orçamento salvo com sucesso!', 'success');
    };

    const handlePrint = (budget: Budget) => {
        const client = clients.find(c => c.id === budget.clientId);
        if (client) {
            pdfService.generateBudgetPDF(budget, client, companyProfile);
        }
    };

    const handleConvertClick = (budget: Budget) => {
         if (budget.status === 'Converted') { openAlert('Orçamento já convertido.', 'error'); return; }
         
         openConfirm(
             'Gerar Pedido',
             `Converter orçamento ${budget.serialNumber} em Pedido?`,
             async () => {
                 try {
                    // Generate Order
                    const nextOrderNumber = await idService.getNextSequence('order');
                    const order: Order = {
                        id: crypto.randomUUID(),
                        budgetId: budget.id,
                        budgetSerialNumber: budget.serialNumber,
                        orderNumber: nextOrderNumber,
                        clientId: budget.clientId,
                        items: budget.items.map(i => ({
                            productId: i.productId,
                            quantity: i.quantity,
                            size: i.size,
                            productionStage: ProductionStage.CUTTING, // Initial Stage
                            fabric: i.fabric,
                            color: i.color
                        })),
                        customizations: budget.customizations,
                        extras: budget.extras,
                        totalAmount: budget.totalAmount,
                        amountPaid: budget.downPaymentValue,
                        deadline: addBusinessDays(getTodayStr(), budget.deliveryTimeDays || 20),
                        status: OrderStatus.PENDING,
                        paymentStatus: budget.downPaymentValue > 0 ? PaymentStatus.PARTIAL : PaymentStatus.PENDING,
                        createdAt: getTodayStr(),
                        updatedAt: getTodayStr()
                    };

                    await storageService.saveOrder(order);
                    await storageService.saveBudget({ ...budget, status: 'Converted', generatedOrderNumber: nextOrderNumber });
                    refresh();
                    setDialog(prev => ({...prev, isOpen: false}));
                    if (onNavigate) onNavigate('orders');

                 } catch(e) {
                     console.error(e);
                     openAlert('Erro ao converter orçamento.');
                 }
             },
             'success'
         );
    };

    const handleDeleteClick = (id: string) => {
        openConfirm(
            'Excluir Orçamento',
            'Tem certeza que deseja excluir este orçamento? Esta ação não pode ser desfeita.',
            async () => {
                await deleteBudget(id);
                setDialog(prev => ({...prev, isOpen: false}));
            },
            'danger'
        );
    };

    const getStatusBadge = (status: string) => {
        const styles: Record<string, string> = {
            'Draft': 'bg-zinc-800 text-zinc-400 border-zinc-700',
            'Sent': 'bg-blue-900/30 text-blue-400 border-blue-800',
            'Approved': 'bg-emerald-900/30 text-emerald-400 border-emerald-800',
            'Converted': 'bg-purple-900/30 text-purple-400 border-purple-800'
        };
        return <span className={`px-2 py-1 rounded-sm text-[10px] uppercase font-bold border ${styles[status] || styles['Draft']}`}>{status === 'Sent' ? 'Enviado' : status === 'Draft' ? 'Rascunho' : status === 'Approved' ? 'Aprovado' : 'Convertido'}</span>;
    };

    return (
        <>
            <div className="space-y-6 relative">
                <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                    <h1 className="text-2xl font-bold text-white">Orçamentos</h1>
                    <button onClick={() => handleOpenEditor()} className="bg-gold-600 hover:bg-gold-500 text-black px-4 py-2 rounded-sm font-bold uppercase text-xs flex items-center gap-2 transition-all">
                        <Plus size={16} /> Novo Orçamento
                    </button>
                </div>

                {/* FILTERS */}
                <div className="flex flex-col xl:flex-row gap-4 bg-zinc-900 p-4 border border-zinc-800 rounded-sm">
                    {/* Search & Client */}
                    <div className="flex flex-col md:flex-row gap-4 flex-1">
                        <div className="flex items-center gap-2 bg-zinc-950 px-3 py-2 border border-zinc-800 rounded-sm flex-1">
                            <Search size={16} className="text-zinc-500" />
                            <input placeholder="Buscar por Nº ou Pedido..." className="bg-transparent outline-none text-sm text-white w-full" value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} />
                        </div>
                        <div className="flex items-center gap-2 bg-zinc-950 px-3 py-2 border border-zinc-800 rounded-sm flex-1">
                            <User size={14} className="text-zinc-500" />
                            <select className="bg-transparent outline-none text-sm text-white w-full uppercase cursor-pointer" value={filterClient} onChange={(e) => setFilterClient(e.target.value)}>
                                <option value="ALL" className="bg-zinc-900 text-zinc-400">Todos Clientes</option>
                                {clients.map(c => <option key={c.id} value={c.id} className="bg-zinc-900 text-zinc-200">{c.companyName}</option>)}
                            </select>
                        </div>
                    </div>

                    {/* Status & Period */}
                    <div className="flex flex-col md:flex-row gap-4 shrink-0">
                        <div className="flex items-center gap-2 bg-zinc-950 px-3 py-2 border border-zinc-800 rounded-sm min-w-[150px]">
                            <ListFilter size={14} className="text-zinc-500" />
                            <select className="bg-transparent outline-none text-sm text-white w-full uppercase cursor-pointer" value={filterStatus} onChange={(e) => setFilterStatus(e.target.value)}>
                                <option value="ALL" className="bg-zinc-900 text-zinc-400">Todos Status</option>
                                <option value="Draft" className="bg-zinc-900 text-zinc-200">Rascunho</option>
                                <option value="Sent" className="bg-zinc-900 text-zinc-200">Enviado</option>
                                <option value="Approved" className="bg-zinc-900 text-zinc-200">Aprovado</option>
                                <option value="Converted" className="bg-zinc-900 text-zinc-200">Convertido</option>
                            </select>
                        </div>
                        <div className="flex items-center bg-zinc-950 border border-zinc-800 rounded-sm overflow-x-auto">
                            {(['ALL', 'DAY', 'WEEK', 'MONTH'] as const).map(p => (
                                <button key={p} onClick={() => setFilterPeriod(p)} className={`px-4 py-2 text-xs font-bold uppercase transition-colors whitespace-nowrap ${filterPeriod === p ? 'bg-zinc-800 text-white' : 'text-zinc-500'}`}>
                                    {p === 'ALL' ? 'Todos' : p === 'DAY' ? 'Hoje' : p === 'WEEK' ? 'Semana' : 'Mês'}
                                </button>
                            ))}
                        </div>
                    </div>
                </div>

                {/* LIST */}
                <div className="grid gap-4">
                    {paginatedBudgets.map(budget => {
                        const client = clients.find(c => c.id === budget.clientId);
                        const isExpired = isBudgetExpired(budget.date, budget.validityDays) && budget.status === 'Sent';
                        
                        return (
                            <div key={budget.id} className="bg-zinc-900 p-5 rounded-sm border border-zinc-800 flex flex-col md:flex-row justify-between items-center hover:border-zinc-700 transition gap-4">
                                <div className="flex-1 w-full">
                                    <div className="flex items-center gap-3 mb-1">
                                        <span className="font-mono text-xs bg-zinc-950 px-2 py-1 rounded-sm text-zinc-400 border border-zinc-800">{budget.serialNumber}</span>
                                        <h3 className="font-bold text-white text-sm md:text-base truncate">{client?.companyName || 'Cliente Desconhecido'}</h3>
                                        {getStatusBadge(budget.status)}
                                        {isExpired && <span className="text-[10px] text-red-500 font-bold flex items-center gap-1 bg-red-900/20 px-1.5 py-0.5 rounded border border-red-900/50"><AlertTriangle size={10} /> EXPIRADO</span>}
                                    </div>
                                    <div className="text-xs text-zinc-500 flex flex-wrap items-center gap-4 mt-2">
                                        <span className="flex items-center gap-1"><Calendar size={12} /> {formatDate(budget.date)}</span>
                                        <span className="flex items-center gap-1"><Package size={12} /> {budget.items.length} itens</span>
                                        <span className="font-mono text-zinc-600">Total: {formatCurrency(budget.totalAmount)}</span>
                                        {budget.generatedOrderNumber && (
                                            <span 
                                                onClick={() => onNavigate && onNavigate('orders', budget.generatedOrderNumber)}
                                                className="flex items-center gap-1 text-emerald-600 cursor-pointer hover:underline"
                                            >
                                                <Link size={12} /> Pedido: {budget.generatedOrderNumber}
                                            </span>
                                        )}
                                    </div>
                                </div>
                                
                                <div className="flex items-center gap-2 w-full md:w-auto justify-end">
                                    {budget.status !== 'Converted' && (
                                        <button 
                                            onClick={() => handleConvertClick(budget)} 
                                            className="flex items-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-sm text-xs font-bold uppercase transition-colors mr-2 shadow-lg shadow-emerald-900/20"
                                            title="Gerar Pedido"
                                        >
                                            <CheckSquare size={16} /> GERAR PEDIDO
                                        </button>
                                    )}
                                    
                                    {budget.status !== 'Converted' && (
                                        <button onClick={() => handleOpenEditor(budget)} className="p-2 text-zinc-400 hover:text-white bg-zinc-950 border border-zinc-800 rounded-sm transition-colors" title="Editar">
                                            <Edit2 size={16} />
                                        </button>
                                    )}

                                    <button onClick={() => handleDuplicateClick(budget)} className="p-2 text-zinc-400 hover:text-blue-500 bg-zinc-950 border border-zinc-800 rounded-sm transition-colors" title="Duplicar">
                                        <Copy size={16} />
                                    </button>
                                    <button onClick={() => handlePrint(budget)} className="p-2 text-zinc-400 hover:text-white bg-zinc-950 border border-zinc-800 rounded-sm transition-colors" title="Imprimir PDF">
                                        <Printer size={16} />
                                    </button>
                                    
                                    <button onClick={() => handleDeleteClick(budget.id)} className="p-2 text-zinc-400 hover:text-red-500 bg-zinc-950 border border-zinc-800 rounded-sm transition-colors" title="Excluir">
                                        <Trash2 size={16} />
                                    </button>
                                </div>
                            </div>
                        );
                    })}
                    {budgets.length === 0 && (
                        <div className="text-center py-12 border-2 border-dashed border-zinc-800 rounded-sm">
                            <p className="text-zinc-500 text-sm font-bold uppercase">Nenhum orçamento encontrado.</p>
                        </div>
                    )}
                </div>

                {/* PAGINATION CONTROLS */}
                {budgets.length > 0 && (
                    <div className="flex justify-between items-center p-4 border-t border-zinc-800 bg-zinc-900 rounded-sm">
                        <span className="text-xs text-zinc-500">
                            Mostrando {(currentPage - 1) * itemsPerPage + 1}-{Math.min(currentPage * itemsPerPage, budgets.length)} de {budgets.length}
                        </span>
                        <div className="flex gap-2">
                            <button 
                                onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                                disabled={currentPage === 1}
                                className="px-3 py-1 bg-zinc-800 hover:bg-zinc-700 disabled:opacity-50 rounded-sm text-xs font-bold text-zinc-300 transition-colors"
                            >
                                <ChevronLeft size={14} />
                            </button>
                            <span className="px-3 py-1 text-xs font-mono text-zinc-400 flex items-center bg-zinc-950 rounded-sm border border-zinc-800">
                                {currentPage} / {totalPages}
                            </span>
                            <button 
                                onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                                disabled={currentPage === totalPages}
                                className="px-3 py-1 bg-zinc-800 hover:bg-zinc-700 disabled:opacity-50 rounded-sm text-xs font-bold text-zinc-300 transition-colors"
                            >
                                <ChevronRight size={14} />
                            </button>
                        </div>
                    </div>
                )}
            </div>

            {isEditorOpen && (
                <BudgetEditor 
                    budget={editingBudget} 
                    clients={clients} 
                    products={products} 
                    onClose={() => setIsEditorOpen(false)} 
                    onSave={handleSaveBudget}
                    showToast={openAlert}
                />
            )}

            {/* CUSTOM DIALOG */}
            {dialog.isOpen && (
                <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-[60] flex items-center justify-center p-4 animate-in fade-in duration-200">
                    <div className="bg-zinc-900 border border-zinc-800 rounded-sm shadow-2xl max-w-sm w-full p-6 text-center transform transition-all scale-100">
                        <div className={`mx-auto mb-4 w-12 h-12 rounded-full flex items-center justify-center border ${
                            dialog.variant === 'danger' ? 'bg-red-900/20 border-red-900 text-red-500' :
                            dialog.variant === 'success' ? 'bg-emerald-900/20 border-emerald-900 text-emerald-500' :
                            'bg-blue-900/20 border-blue-900 text-blue-500'
                        }`}>
                            {dialog.variant === 'danger' ? <AlertTriangle size={24} /> :
                             dialog.variant === 'success' ? <CheckCircle size={24} /> : <Info size={24} />}
                        </div>
                        <h3 className="text-lg font-bold text-white mb-2">{dialog.title}</h3>
                        <p className="text-zinc-400 text-sm mb-6">{dialog.message}</p>
                        
                        <div className="flex gap-3">
                             {dialog.type === 'confirm' ? (
                                <>
                                    <button 
                                        onClick={() => setDialog(prev => ({...prev, isOpen: false}))} 
                                        className="flex-1 bg-zinc-800 hover:bg-zinc-700 text-white py-2.5 rounded-sm font-bold text-xs uppercase tracking-wide transition-colors"
                                    >
                                        Cancelar
                                    </button>
                                    <button 
                                        onClick={dialog.onConfirm} 
                                        className={`flex-1 py-2.5 rounded-sm font-bold text-xs uppercase tracking-wide text-white transition-colors ${
                                            dialog.variant === 'danger' ? 'bg-red-600 hover:bg-red-500' :
                                            dialog.variant === 'success' ? 'bg-emerald-600 hover:bg-emerald-500' :
                                            'bg-blue-600 hover:bg-blue-500'
                                        }`}
                                    >
                                        Confirmar
                                    </button>
                                </>
                             ) : (
                                <button 
                                    onClick={() => setDialog(prev => ({...prev, isOpen: false}))} 
                                    className="w-full bg-zinc-800 hover:bg-zinc-700 text-white py-2.5 rounded-sm font-bold text-xs uppercase tracking-wide transition-colors"
                                >
                                    OK
                                </button>
                             )}
                        </div>
                    </div>
                </div>
            )}
        </>
    );
};
export default Budgets;
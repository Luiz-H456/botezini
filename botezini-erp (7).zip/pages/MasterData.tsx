import React, { useState, useEffect } from 'react';
import { storageService } from '../services/storage';
import { Client, Product, Supplier, CompanyProfile, CostCenter, BankAccount } from '../types';
import { Users, Shirt, Plus, Edit2, Trash2, X, Save, AlertTriangle, Truck, Settings, ChevronDown, Building2, Upload, DollarSign, CheckCircle, Target, Wallet, FolderTree } from 'lucide-react';
import { maskCNPJ, maskPhone, formatCurrency, clientSchema, productSchema, supplierSchema } from '../utils';
import { supabase } from '../services/supabase';

interface Props {
    onProfileUpdate?: () => void;
}

export default function MasterData({ onProfileUpdate }: Props) {
  const [activeTab, setActiveTab] = useState<'company' | 'accounts' | 'clients' | 'suppliers' | 'products' | 'financial'>('company');
  const [clients, setClients] = useState<Client[]>([]);
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  
  // Financial Settings State
  const [costCenters, setCostCenters] = useState<CostCenter[]>([]);
  const [bankAccounts, setBankAccounts] = useState<BankAccount[]>([]);
  const [isSavingFinance, setIsSavingFinance] = useState(false);

  // Pagination State
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10;

  useEffect(() => { setCurrentPage(1); }, [activeTab]);

  // Company Profile State
  const [companyProfile, setCompanyProfile] = useState<CompanyProfile>({
      name: '', cnpj: '', email: '', phone: '', address: '', website: '', logoUrl: '', bankInfo: '',
      bankName: '', bankAgency: '', bankAccount: '', bankHolder: '', pixKey: '',
      revenueGoal: 0, expenseLimit: 0, defaultTaxRate: 0
  });
  const [isSavingCompany, setIsSavingCompany] = useState(false);

  // Category States
  const [clientCategories, setClientCategories] = useState<string[]>([]);
  const [supplierCategories, setSupplierCategories] = useState<string[]>([]);
  const [productCategories, setProductCategories] = useState<string[]>([]);
  
  // Modal State
  const [isClientModalOpen, setIsClientModalOpen] = useState(false);
  const [isSupplierModalOpen, setIsSupplierModalOpen] = useState(false);
  const [isProductModalOpen, setIsProductModalOpen] = useState(false);
  const [isAccountModalOpen, setIsAccountModalOpen] = useState(false);
  
  // Category Management State
  const [isManagingCats, setIsManagingCats] = useState(false);
  const [newCategoryInput, setNewCategoryInput] = useState('');
  
  const [editingClient, setEditingClient] = useState<Partial<Client>>({});
  const [editingSupplier, setEditingSupplier] = useState<Partial<Supplier>>({});
  const [editingProduct, setEditingProduct] = useState<Partial<Product>>({});
  const [editingAccount, setEditingAccount] = useState<Partial<BankAccount>>({});
  
  // Generic Inputs for Finance Tab
  const [newCostCenter, setNewCostCenter] = useState<Partial<CostCenter>>({ name: '', type: 'production', budgetLimit: 0 });
  const [ccCategoryInputs, setCcCategoryInputs] = useState<Record<string, string>>({});

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [itemToDelete, setItemToDelete] = useState<{ id: string, type: 'client' | 'supplier' | 'product' | 'account', name: string } | null>(null);

  const [alertInfo, setAlertInfo] = useState<{ isOpen: boolean, title: string, message: string, type: 'success' | 'error' }>({ 
      isOpen: false, title: '', message: '', type: 'success' 
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setIsLoading(true);
    try {
        const [c, s, p, profile, cc] = await Promise.all([
            storageService.getClients(),
            storageService.getSuppliers(),
            storageService.getProducts(),
            storageService.getCompanyProfile(),
            storageService.getCostCenters()
        ]);
        setClients(c);
        setSuppliers(s);
        setProducts(p);
        setCostCenters(cc);
        if (profile) setCompanyProfile(profile);
        
        setClientCategories(storageService.getCategories('client'));
        setSupplierCategories(storageService.getCategories('supplier'));
        setProductCategories(storageService.getCategories('product'));

        // Load Bank Accounts directly from DB
        const { data: accounts } = await supabase.from('bank_accounts').select('*');
        if (accounts) setBankAccounts(accounts);

    } catch (e) {
        console.error("MasterData Load Error:", e);
        showAlert('Erro', 'Falha ao carregar cadastros. Verifique a conexão.', 'error');
    } finally {
        setIsLoading(false);
    }
  };

  const getCurrentData = () => {
      if (activeTab === 'clients') return clients;
      if (activeTab === 'suppliers') return suppliers;
      if (activeTab === 'products') return products;
      if (activeTab === 'accounts') return bankAccounts;
      return [];
  };

  const currentData = getCurrentData();
  const paginatedData = currentData.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);

  const showAlert = (title: string, message: string, type: 'success' | 'error') => {
      setAlertInfo({ isOpen: true, title, message, type });
      setTimeout(() => setAlertInfo(prev => ({...prev, isOpen: false})), 3000);
  };

  const handleAddCategory = (type: 'client' | 'supplier' | 'product') => {
      if (!newCategoryInput.trim()) return;
      let current: string[] = [];
      if (type === 'client') current = clientCategories;
      if (type === 'supplier') current = supplierCategories;
      if (type === 'product') current = productCategories;

      if (!current.includes(newCategoryInput.trim())) {
          const updated = [...current, newCategoryInput.trim()];
          storageService.saveCategories(type, updated);
          loadData();
          setNewCategoryInput('');
      }
  };

  const handleRemoveCategory = (type: 'client' | 'supplier' | 'product', cat: string) => {
      let current: string[] = [];
      if (type === 'client') current = clientCategories;
      if (type === 'supplier') current = supplierCategories;
      if (type === 'product') current = productCategories;

      const updated = current.filter(c => c !== cat);
      storageService.saveCategories(type, updated);
      loadData();
  };

  const resetModalState = () => {
      setIsManagingCats(false);
      setNewCategoryInput('');
      setErrors({});
  };

  // --- COMPANY PROFILE ---
  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
        const reader = new FileReader();
        reader.onloadend = () => setCompanyProfile(prev => ({ ...prev, logoUrl: reader.result as string }));
        reader.readAsDataURL(file);
    }
  };

  const handleSaveCompany = async () => {
      setIsSavingCompany(true);
      try {
          await storageService.saveCompanyProfile(companyProfile);
          if (onProfileUpdate) onProfileUpdate();
          showAlert('Sucesso', 'Dados da empresa salvos!', 'success');
      } catch (err) {
          showAlert('Erro', 'Erro ao salvar dados.', 'error');
      } finally {
          setIsSavingCompany(false);
      }
  };

  // --- FINANCIAL & ACCOUNTS ---
  const handleAddCostCenter = async () => {
      if (!newCostCenter.name) return;
      try {
          // Remove ID to allow DB generation
          const newItem: any = {
              name: newCostCenter.name, 
              type: newCostCenter.type || 'administrative',
              budgetLimit: newCostCenter.budgetLimit || 0, 
              color: '#8b5cf6', 
              isActive: true, 
              categories: []
          };
          await storageService.saveCostCenter(newItem);
          const updated = await storageService.getCostCenters();
          setCostCenters(updated);
          setNewCostCenter({ name: '', type: 'production', budgetLimit: 0 });
          showAlert('Sucesso', 'Centro de Custo criado!', 'success');
      } catch (e) {
          showAlert('Erro', 'Erro ao criar Centro de Custo.', 'error');
      }
  };

  const handleSaveAccount = async () => {
      try {
          if (!editingAccount.name) {
              showAlert('Erro', 'Nome da conta é obrigatório', 'error');
              return;
          }

          const accountData: any = {
              name: editingAccount.name,
              type: editingAccount.type || 'checking',
              bankName: editingAccount.bankName,
              accountNumber: editingAccount.accountNumber,
              currentBalance: editingAccount.currentBalance || 0,
              initialBalance: editingAccount.initialBalance || 0,
              isActive: true
          };

          if (editingAccount.id) {
              accountData.id = editingAccount.id;
          }

          const { error } = await supabase.from('bank_accounts').upsert(accountData);
          if (error) throw error;
          
          setIsAccountModalOpen(false);
          loadData();
          showAlert('Sucesso', 'Conta bancária salva!', 'success');
      } catch (e) {
          console.error(e);
          showAlert('Erro', 'Erro ao salvar conta.', 'error');
      }
  };

  const handleDeleteCostCenter = async (id: string) => {
      try {
          await storageService.deleteCostCenter(id);
          setCostCenters(await storageService.getCostCenters());
      } catch (e) {
          showAlert('Erro', 'Erro ao excluir.', 'error');
      }
  };

  const handleAddCostCenterCategory = async (costCenterId: string) => {
      const catName = ccCategoryInputs[costCenterId]?.trim();
      if (!catName) return;
      const targetCC = costCenters.find(cc => cc.id === costCenterId);
      if (!targetCC) return;
      if ((targetCC.categories || []).includes(catName)) return;

      try {
          const updatedCC = { ...targetCC, categories: [...(targetCC.categories || []), catName] };
          await storageService.saveCostCenter(updatedCC);
          setCostCenters(await storageService.getCostCenters());
          setCcCategoryInputs(prev => ({ ...prev, [costCenterId]: '' }));
      } catch (e) {
          showAlert('Erro', 'Erro ao adicionar categoria.', 'error');
      }
  };

  const handleRemoveCostCenterCategory = async (costCenterId: string, catName: string) => {
      const targetCC = costCenters.find(cc => cc.id === costCenterId);
      if (!targetCC) return;
      try {
          const updatedCC = { ...targetCC, categories: (targetCC.categories || []).filter(c => c !== catName) };
          await storageService.saveCostCenter(updatedCC);
          setCostCenters(await storageService.getCostCenters());
      } catch (e) {
          showAlert('Erro', 'Erro ao remover categoria.', 'error');
      }
  };

  const handleSaveFinanceGoals = async () => {
      setIsSavingFinance(true);
      try {
          await storageService.saveCompanyProfile(companyProfile);
          if (onProfileUpdate) onProfileUpdate();
          showAlert('Sucesso', 'Metas financeiras atualizadas!', 'success');
      } catch (e) {
          showAlert('Erro', 'Erro ao salvar metas.', 'error');
      } finally {
          setIsSavingFinance(false);
      }
  };

  // --- CRUD HANDLERS ---
  const handleOpenClient = (client?: Client) => {
    setEditingClient(client || { companyName: '', category: '', cnpj: '', contactPerson: '', email: '', phone: '', address: '' });
    resetModalState();
    setIsClientModalOpen(true);
  };

  const handleSaveClient = async () => {
    const result = clientSchema.safeParse(editingClient);
    if (!result.success) {
      const formattedErrors: Record<string, string> = {};
      result.error.issues.forEach(issue => formattedErrors[String(issue.path[0])] = issue.message);
      setErrors(formattedErrors);
      return;
    }
    await storageService.saveClient({ ...editingClient, id: editingClient.id || '' } as Client);
    setIsClientModalOpen(false);
    loadData();
  };

  const confirmDeleteClient = (client: Client) => setItemToDelete({ id: client.id, type: 'client', name: client.companyName });

  const handleOpenSupplier = (supplier?: Supplier) => {
    setEditingSupplier(supplier || { companyName: '', category: '', cnpj: '', contactPerson: '', email: '', phone: '', address: '' });
    resetModalState();
    setIsSupplierModalOpen(true);
  };

  const handleSaveSupplier = async () => {
    const result = supplierSchema.safeParse(editingSupplier);
    if (!result.success) {
      const formattedErrors: Record<string, string> = {};
      result.error.issues.forEach(issue => formattedErrors[String(issue.path[0])] = issue.message);
      setErrors(formattedErrors);
      return;
    }
    await storageService.saveSupplier({ ...editingSupplier, id: editingSupplier.id || '' } as Supplier);
    setIsSupplierModalOpen(false);
    loadData();
  };

  const confirmDeleteSupplier = (supplier: Supplier) => setItemToDelete({ id: supplier.id, type: 'supplier', name: supplier.companyName });

  const handleOpenProduct = (product?: Product) => {
    setEditingProduct(product || { name: '', sku: '', category: '', priceTier1: 0, priceTier2: 0, priceTier3: 0, notes: '', description: '' });
    resetModalState();
    setIsProductModalOpen(true);
  };

  const handleSaveProduct = async () => {
    const payload = {
        ...editingProduct,
        priceTier1: Number(editingProduct.priceTier1 || 0),
        priceTier2: Number(editingProduct.priceTier2 || 0),
        priceTier3: Number(editingProduct.priceTier3 || 0),
    };
    const result = productSchema.safeParse(payload);
    if (!result.success) {
      const formattedErrors: Record<string, string> = {};
      result.error.issues.forEach(issue => formattedErrors[String(issue.path[0])] = issue.message);
      setErrors(formattedErrors);
      return;
    }
    await storageService.saveProduct({ ...payload, id: editingProduct.id || '' } as Product);
    setIsProductModalOpen(false);
    loadData();
  };

  const confirmDeleteProduct = (product: Product) => setItemToDelete({ id: product.id, type: 'product', name: product.name });

  const executeDelete = async () => {
    if (!itemToDelete) return;
    if (itemToDelete.type === 'client') await storageService.deleteClient(itemToDelete.id);
    else if (itemToDelete.type === 'supplier') await storageService.deleteSupplier(itemToDelete.id);
    else if (itemToDelete.type === 'product') await storageService.deleteProduct(itemToDelete.id);
    else if (itemToDelete.type === 'account') {
        await supabase.from('bank_accounts').delete().eq('id', itemToDelete.id);
    }
    loadData();
    setItemToDelete(null);
  };

  const handleAddClick = () => {
      if (activeTab === 'clients') handleOpenClient();
      else if (activeTab === 'suppliers') handleOpenSupplier();
      else if (activeTab === 'products') handleOpenProduct();
      else if (activeTab === 'accounts') {
          setEditingAccount({ name: '', type: 'checking', currentBalance: 0, initialBalance: 0 });
          setIsAccountModalOpen(true);
      }
  };

  const renderCategorySection = (type: 'client' | 'supplier' | 'product', currentValue: string | undefined, onChange: (val: string) => void) => {
      const categories = type === 'client' ? clientCategories : type === 'supplier' ? supplierCategories : productCategories;
      return (
          <div className="relative group/cat-section">
              <div className="flex gap-2">
                  <div className="relative w-full">
                    <select
                        className="w-full bg-zinc-950 border border-zinc-800 rounded-sm px-3 py-2 outline-none focus:border-gold-500 text-slate-200 transition-colors appearance-none"
                        value={currentValue || ''}
                        onChange={e => onChange(e.target.value)}
                        disabled={isManagingCats}
                    >
                        <option value="" className="bg-zinc-900 text-zinc-400">Selecione...</option>
                        {categories.map((cat, idx) => <option key={idx} value={cat} className="bg-zinc-900 text-zinc-200">{cat}</option>)}
                    </select>
                    <div className="absolute right-3 top-2.5 pointer-events-none text-zinc-500"><ChevronDown size={14} /></div>
                  </div>
                  <button onClick={() => setIsManagingCats(true)} className="bg-zinc-900 border border-zinc-800 text-zinc-500 hover:text-white px-3 rounded-sm transition-all"><Settings size={16} /></button>
              </div>
              {isManagingCats && (
                  <div className="absolute top-0 right-0 z-50 w-[320px] bg-zinc-800 border border-zinc-600 shadow-2xl rounded-sm p-4 animate-in fade-in zoom-in-95 origin-top-right">
                       <div className="flex justify-between items-center mb-4 border-b border-zinc-700 pb-2">
                          <span className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2"><Settings size={14} className="text-gold-500" /> Gerenciar Opções</span>
                          <button onClick={() => setIsManagingCats(false)} className="text-[10px] bg-zinc-900 text-zinc-400 border border-zinc-700 px-2 py-1 rounded-sm font-bold flex items-center gap-1 hover:text-white"><X size={12} /> Fechar</button>
                      </div>
                      <div className="flex gap-0 mb-4 relative">
                          <input value={newCategoryInput} onChange={(e) => setNewCategoryInput(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && handleAddCategory(type)} className="flex-1 bg-zinc-900 border border-zinc-700 border-r-0 rounded-l-sm px-3 py-2.5 text-sm text-white outline-none focus:border-gold-500" placeholder="Nova categoria..." autoFocus />
                          <button onClick={() => handleAddCategory(type)} className="bg-gold-600 hover:bg-gold-500 text-black px-4 rounded-r-sm transition-colors font-bold"><Plus size={18} /></button>
                      </div>
                      <div className="flex flex-col gap-2 max-h-48 overflow-y-auto pr-1">
                          {categories.map((cat, idx) => (
                              <div key={idx} className="flex justify-between items-center bg-zinc-900/50 border border-zinc-700/50 p-2 rounded-sm group hover:border-zinc-600">
                                  <span className="text-sm text-zinc-300 pl-1">{cat}</span>
                                  <button onClick={() => handleRemoveCategory(type, cat)} className="text-zinc-600 hover:text-red-500 p-1 rounded-sm hover:bg-red-500/10"><Trash2 size={14} /></button>
                              </div>
                          ))}
                      </div>
                  </div>
              )}
          </div>
      );
  };

  return (
    <div className="space-y-6 relative pb-20">
       <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-white">Cadastros Gerais</h1>
        {activeTab !== 'company' && activeTab !== 'financial' && (
            <button onClick={handleAddClick} className="bg-zinc-800 text-white border border-zinc-700 px-4 py-2 rounded-sm flex items-center gap-2 hover:bg-zinc-700 transition uppercase text-xs font-bold tracking-wider">
              <Plus size={16} /> 
              {activeTab === 'clients' ? 'Novo Cliente' : 
               activeTab === 'suppliers' ? 'Novo Fornecedor' : 
               activeTab === 'accounts' ? 'Nova Conta' : 'Novo Produto'}
            </button>
        )}
      </div>

      <div className="flex gap-4 border-b border-zinc-800 overflow-x-auto">
        <button onClick={() => setActiveTab('company')} className={`pb-2 px-4 font-bold uppercase text-xs flex items-center gap-2 tracking-wider whitespace-nowrap ${activeTab === 'company' ? 'text-gold-500 border-b-2 border-gold-500' : 'text-zinc-500 hover:text-zinc-300'}`}><Building2 size={16} /> Minha Empresa</button>
        <button onClick={() => setActiveTab('financial')} className={`pb-2 px-4 font-bold uppercase text-xs flex items-center gap-2 tracking-wider whitespace-nowrap ${activeTab === 'financial' ? 'text-gold-500 border-b-2 border-gold-500' : 'text-zinc-500 hover:text-zinc-300'}`}><FolderTree size={16} /> Plano de Contas</button>
        <button onClick={() => setActiveTab('accounts')} className={`pb-2 px-4 font-bold uppercase text-xs flex items-center gap-2 tracking-wider whitespace-nowrap ${activeTab === 'accounts' ? 'text-gold-500 border-b-2 border-gold-500' : 'text-zinc-500 hover:text-zinc-300'}`}><Wallet size={16} /> Contas Bancárias</button>
        <button onClick={() => setActiveTab('clients')} className={`pb-2 px-4 font-bold uppercase text-xs flex items-center gap-2 tracking-wider whitespace-nowrap ${activeTab === 'clients' ? 'text-gold-500 border-b-2 border-gold-500' : 'text-zinc-500 hover:text-zinc-300'}`}><Users size={16} /> Clientes</button>
        <button onClick={() => setActiveTab('suppliers')} className={`pb-2 px-4 font-bold uppercase text-xs flex items-center gap-2 tracking-wider whitespace-nowrap ${activeTab === 'suppliers' ? 'text-gold-500 border-b-2 border-gold-500' : 'text-zinc-500 hover:text-zinc-300'}`}><Truck size={16} /> Fornecedores</button>
        <button onClick={() => setActiveTab('products')} className={`pb-2 px-4 font-bold uppercase text-xs flex items-center gap-2 tracking-wider whitespace-nowrap ${activeTab === 'products' ? 'text-gold-500 border-b-2 border-gold-500' : 'text-zinc-500 hover:text-zinc-300'}`}><Shirt size={16} /> Produtos</button>
      </div>

      {isLoading && <div className="text-center p-8 text-zinc-500">Carregando dados...</div>}

      <div className="rounded-sm overflow-hidden">
        {/* COMPANY PROFILE */}
        {activeTab === 'company' && (
            <div className="max-w-4xl mx-auto space-y-6">
                <div className="bg-zinc-900 border border-zinc-800 p-6 rounded-sm">
                    <h3 className="text-lg font-bold text-white mb-6 uppercase tracking-wider flex items-center gap-2"><Building2 size={20} className="text-gold-500" /> Dados da Fábrica</h3>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                        <div className="col-span-1 flex flex-col items-center gap-4">
                            <div className="w-40 h-40 bg-zinc-950 border-2 border-dashed border-zinc-700 rounded-sm flex items-center justify-center overflow-hidden relative group">
                                {companyProfile.logoUrl ? <img src={companyProfile.logoUrl} alt="Logo" className="w-full h-full object-contain p-2" /> : <div className="text-center p-4"><Upload size={32} className="mx-auto text-zinc-600 mb-2" /><span className="text-xs text-zinc-500">Carregar Logo</span></div>}
                                <input type="file" accept="image/*" className="absolute inset-0 opacity-0 cursor-pointer" onChange={handleLogoUpload} />
                            </div>
                        </div>
                        <div className="col-span-2 space-y-4">
                            <div><label className="block text-xs font-bold text-zinc-500 mb-1 uppercase">Nome Fantasia / Razão Social</label><input className="w-full bg-zinc-950 border border-zinc-800 rounded-sm px-3 py-2 outline-none focus:border-gold-500 text-slate-200" value={companyProfile.name} onChange={e => setCompanyProfile({...companyProfile, name: e.target.value})} placeholder="Ex: Botezini Uniformes" /></div>
                            <div className="grid grid-cols-2 gap-4">
                                <div><label className="block text-xs font-bold text-zinc-500 mb-1 uppercase">CNPJ</label><input className="w-full bg-zinc-950 border border-zinc-800 rounded-sm px-3 py-2 outline-none focus:border-gold-500 text-slate-200 font-mono" value={companyProfile.cnpj} onChange={e => setCompanyProfile({...companyProfile, cnpj: maskCNPJ(e.target.value)})} placeholder="00.000.000/0000-00" maxLength={18} /></div>
                                <div><label className="block text-xs font-bold text-zinc-500 mb-1 uppercase">Telefone / WhatsApp</label><input className="w-full bg-zinc-950 border border-zinc-800 rounded-sm px-3 py-2 outline-none focus:border-gold-500 text-slate-200 font-mono" value={companyProfile.phone} onChange={e => setCompanyProfile({...companyProfile, phone: maskPhone(e.target.value)})} placeholder="(00) 00000-0000" maxLength={15} /></div>
                            </div>
                            <div><label className="block text-xs font-bold text-zinc-500 mb-1 uppercase">Endereço Completo</label><input className="w-full bg-zinc-950 border border-zinc-800 rounded-sm px-3 py-2 outline-none focus:border-gold-500 text-slate-200" value={companyProfile.address} onChange={e => setCompanyProfile({...companyProfile, address: e.target.value})} placeholder="Rua, Número, Bairro, Cidade - UF, CEP" /></div>
                            <div className="grid grid-cols-2 gap-4">
                                <div><label className="block text-xs font-bold text-zinc-500 mb-1 uppercase">Email Contato</label><input className="w-full bg-zinc-950 border border-zinc-800 rounded-sm px-3 py-2 outline-none focus:border-gold-500 text-slate-200" value={companyProfile.email} onChange={e => setCompanyProfile({...companyProfile, email: e.target.value})} placeholder="contato@empresa.com" /></div>
                                <div><label className="block text-xs font-bold text-zinc-500 mb-1 uppercase">Site / Instagram</label><input className="w-full bg-zinc-950 border border-zinc-800 rounded-sm px-3 py-2 outline-none focus:border-gold-500 text-slate-200" value={companyProfile.website} onChange={e => setCompanyProfile({...companyProfile, website: e.target.value})} placeholder="@instagram ou www.site.com" /></div>
                            </div>
                        </div>
                    </div>
                    <div className="mt-8 flex justify-end">
                        <button onClick={handleSaveCompany} disabled={isSavingCompany} className="bg-gold-600 hover:bg-gold-500 text-black px-6 py-2.5 rounded-sm font-bold uppercase tracking-wide flex items-center gap-2 transition-all disabled:opacity-50"><Save size={18} /> {isSavingCompany ? 'Salvando...' : 'Salvar Alterações'}</button>
                    </div>
                </div>
            </div>
        )}

        {/* TAB: ACCOUNTS */}
        {activeTab === 'accounts' && (
            <div className="bg-zinc-900 border border-zinc-800 rounded-sm">
                <table className="w-full text-left">
                    <thead className="bg-zinc-950 text-zinc-500 text-[10px] uppercase font-bold tracking-wider"><tr><th className="p-4">Conta</th><th className="p-4">Tipo</th><th className="p-4 text-right">Saldo Atual</th><th className="p-4 text-right">Ações</th></tr></thead>
                    <tbody className="divide-y divide-zinc-800 text-sm">
                        {paginatedData.map(acc => {
                            const account = acc as BankAccount;
                            return (
                                <tr key={account.id} className="hover:bg-zinc-800/50 group transition-colors">
                                    <td className="p-4"><p className="font-bold text-white">{account.name}</p><p className="text-xs text-zinc-500">{account.bankName} • {account.accountNumber}</p></td>
                                    <td className="p-4"><span className="bg-zinc-800 text-zinc-400 px-2 py-1 rounded text-xs uppercase font-bold border border-zinc-700">{account.type}</span></td>
                                    <td className="p-4 text-right font-mono text-emerald-500 font-bold">{formatCurrency(account.currentBalance)}</td>
                                    <td className="p-4 flex gap-2 justify-end">
                                        <button onClick={() => { setEditingAccount(account); setIsAccountModalOpen(true); }} className="p-2 hover:bg-zinc-800 rounded-sm text-zinc-500 hover:text-white"><Edit2 size={16} /></button>
                                        <button onClick={() => setItemToDelete({id: account.id, type: 'account', name: account.name})} className="p-2 hover:bg-red-900/20 rounded-sm text-zinc-500 hover:text-red-500"><Trash2 size={16} /></button>
                                    </td>
                                </tr>
                            );
                        })}
                    </tbody>
                </table>
            </div>
        )}

        {/* TAB: FINANCIAL (COST CENTERS & GOALS) */}
        {activeTab === 'financial' && (
            <div className="max-w-6xl mx-auto space-y-6">
                <div className="bg-zinc-900 border border-zinc-800 p-6 rounded-sm">
                    <div className="flex justify-between items-center mb-6">
                        <h3 className="text-lg font-bold text-white uppercase tracking-wider flex items-center gap-2"><Target size={20} className="text-red-500" /> Metas & Planejamento</h3>
                        <button onClick={handleSaveFinanceGoals} disabled={isSavingFinance} className="text-xs bg-zinc-800 hover:bg-zinc-700 text-white px-3 py-1.5 rounded-sm border border-zinc-700 font-bold uppercase tracking-wide disabled:opacity-50">{isSavingFinance ? 'Salvando...' : 'Atualizar Metas'}</button>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <div><label className="block text-xs font-bold text-zinc-500 mb-1 uppercase">Meta de Receita (Mensal)</label><input type="number" className="w-full bg-zinc-950 border border-zinc-800 rounded-sm px-3 py-2 outline-none focus:border-emerald-500 text-emerald-400 font-bold" value={companyProfile.revenueGoal || ''} onChange={e => setCompanyProfile({...companyProfile, revenueGoal: parseFloat(e.target.value)})} placeholder="0.00" /></div>
                         <div><label className="block text-xs font-bold text-zinc-500 mb-1 uppercase">Teto de Gastos (Mensal)</label><input type="number" className="w-full bg-zinc-950 border border-zinc-800 rounded-sm px-3 py-2 outline-none focus:border-red-500 text-red-400 font-bold" value={companyProfile.expenseLimit || ''} onChange={e => setCompanyProfile({...companyProfile, expenseLimit: parseFloat(e.target.value)})} placeholder="0.00" /></div>
                         <div><label className="block text-xs font-bold text-zinc-500 mb-1 uppercase">Imposto Padrão (%)</label><input type="number" className="w-full bg-zinc-950 border border-zinc-800 rounded-sm px-3 py-2 outline-none focus:border-blue-500 text-blue-400 font-bold" value={companyProfile.defaultTaxRate || ''} onChange={e => setCompanyProfile({...companyProfile, defaultTaxRate: parseFloat(e.target.value)})} placeholder="Ex: 6.0" /></div>
                    </div>
                </div>
                <div className="bg-zinc-900 border border-zinc-800 p-6 rounded-sm flex flex-col">
                    <h3 className="text-lg font-bold text-white mb-4 uppercase tracking-wider flex items-center gap-2"><FolderTree size={20} className="text-gold-500" /> Centros de Custo</h3>
                    <div className="flex gap-2 mb-6 bg-zinc-950 p-2 rounded-sm border border-zinc-800">
                            <input className="flex-1 bg-transparent text-sm text-white outline-none placeholder:text-zinc-600" placeholder="Novo Centro de Custo Pai" value={newCostCenter.name} onChange={e => setNewCostCenter({...newCostCenter, name: e.target.value})} />
                            <select className="bg-zinc-900 text-xs text-zinc-400 border border-zinc-700 rounded-sm px-2 outline-none" value={newCostCenter.type} onChange={e => setNewCostCenter({...newCostCenter, type: e.target.value as any})}><option value="production">Produção</option><option value="administrative">Administrativo</option><option value="commercial">Comercial</option><option value="financial">Financeiro</option></select>
                            <button onClick={handleAddCostCenter} className="bg-gold-600 hover:bg-gold-500 text-black px-3 rounded-sm font-bold"><Plus size={16} /></button>
                    </div>
                    <div className="flex-1 overflow-y-auto max-h-[500px] space-y-4 pr-1 custom-scrollbar">
                        {costCenters.map(cc => (
                            <div key={cc.id} className="bg-zinc-950 border border-zinc-800 rounded-sm overflow-hidden group">
                                <div className="flex justify-between items-center p-3 bg-zinc-950 border-b border-zinc-800/50">
                                    <div className="flex items-center gap-3">
                                        <div className={`w-2 h-8 rounded-sm bg-${cc.color ? cc.color.replace('#','') : 'gray-500'}`} style={{ backgroundColor: cc.color }}></div>
                                        <div><p className="text-sm font-bold text-white">{cc.name}</p><p className="text-[10px] text-zinc-500 uppercase tracking-wide">{cc.type}</p></div>
                                    </div>
                                    <button onClick={() => handleDeleteCostCenter(cc.id)} className="text-zinc-600 hover:text-red-500 p-1 hover:bg-red-500/10 rounded transition-colors"><Trash2 size={14} /></button>
                                </div>
                                <div className="p-3 bg-zinc-900/30">
                                    <div className="flex flex-wrap gap-2 mb-3">{(cc.categories || []).map(cat => (<div key={cat} className="flex items-center gap-1 bg-zinc-800 text-zinc-300 text-[10px] px-2 py-1 rounded-full border border-zinc-700">{cat}<button onClick={() => handleRemoveCostCenterCategory(cc.id, cat)} className="text-zinc-500 hover:text-red-400 ml-1"><X size={10} /></button></div>))}</div>
                                    <div className="flex gap-1">
                                        <input className="flex-1 bg-zinc-950 border border-zinc-800 rounded-sm px-2 py-1 text-xs text-white outline-none focus:border-zinc-600 placeholder:text-zinc-700" placeholder="+ Adicionar Categoria" value={ccCategoryInputs[cc.id] || ''} onChange={e => setCcCategoryInputs({...ccCategoryInputs, [cc.id]: e.target.value})} onKeyDown={e => e.key === 'Enter' && handleAddCostCenterCategory(cc.id)} />
                                        <button onClick={() => handleAddCostCenterCategory(cc.id)} className="bg-zinc-800 hover:bg-zinc-700 text-zinc-400 px-2 rounded-sm"><Plus size={12} /></button>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        )}
        
        {/* TAB: CLIENTS */}
        {activeTab === 'clients' && (
            <div className="bg-zinc-900 border border-zinc-800 rounded-sm">
              <table className="w-full text-left">
                 <thead className="bg-zinc-950 text-zinc-500 text-[10px] uppercase font-bold tracking-wider"><tr><th className="p-4">Empresa</th><th className="p-4">Categoria</th><th className="p-4">Contato</th><th className="p-4 text-right">Ações</th></tr></thead>
                 <tbody className="divide-y divide-zinc-800 text-sm">
                   {paginatedData.map(c => { const client = c as Client; return (
                     <tr key={client.id} className="hover:bg-zinc-800/50 group transition-colors">
                       <td className="p-4"><p className="font-bold text-slate-200">{client.companyName}</p><p className="text-xs text-zinc-500 font-mono">{client.cnpj || '-'}</p></td>
                       <td className="p-4"><span className="bg-zinc-800 text-zinc-400 text-xs px-2 py-1 rounded-sm border border-zinc-700">{client.category || 'Geral'}</span></td>
                       <td className="p-4 text-sm text-zinc-400"><p className="text-white">{client.contactPerson || '-'}</p><p className="text-xs text-zinc-600">{client.email || ''} {client.phone ? `• ${client.phone}` : ''}</p></td>
                       <td className="p-4 flex gap-2 justify-end"><button onClick={() => handleOpenClient(client)} className="p-2 hover:bg-zinc-800 rounded-sm text-zinc-500 hover:text-white"><Edit2 size={16} /></button><button onClick={() => confirmDeleteClient(client)} className="p-2 hover:bg-red-900/20 rounded-sm text-zinc-500 hover:text-red-500"><Trash2 size={16} /></button></td>
                     </tr>
                   );})}
                 </tbody>
              </table>
            </div>
        )}

        {/* TAB: SUPPLIERS */}
        {activeTab === 'suppliers' && (
            <div className="bg-zinc-900 border border-zinc-800 rounded-sm">
              <table className="w-full text-left">
                 <thead className="bg-zinc-950 text-zinc-500 text-[10px] uppercase font-bold tracking-wider"><tr><th className="p-4">Fornecedor</th><th className="p-4">Categoria</th><th className="p-4">Contato</th><th className="p-4 text-right">Ações</th></tr></thead>
                 <tbody className="divide-y divide-zinc-800 text-sm">
                   {paginatedData.map(s => { const supplier = s as Supplier; return (
                     <tr key={supplier.id} className="hover:bg-zinc-800/50 group transition-colors">
                       <td className="p-4"><p className="font-bold text-slate-200">{supplier.companyName}</p><p className="text-xs text-zinc-500 font-mono">{supplier.cnpj || '-'}</p></td>
                       <td className="p-4"><span className="bg-zinc-800 text-zinc-400 text-xs px-2 py-1 rounded-sm border border-zinc-700">{supplier.category || 'Geral'}</span></td>
                       <td className="p-4 text-sm text-zinc-400"><p className="text-white">{supplier.contactPerson || '-'}</p><p className="text-xs text-zinc-600">{supplier.email || ''}</p></td>
                       <td className="p-4 flex gap-2 justify-end"><button onClick={() => handleOpenSupplier(supplier)} className="p-2 hover:bg-zinc-800 rounded-sm text-zinc-500 hover:text-white"><Edit2 size={16} /></button><button onClick={() => confirmDeleteSupplier(supplier)} className="p-2 hover:bg-red-900/20 rounded-sm text-zinc-500 hover:text-red-500"><Trash2 size={16} /></button></td>
                     </tr>
                   );})}
                 </tbody>
              </table>
            </div>
        )}

        {/* TAB: PRODUCTS */}
        {activeTab === 'products' && (
            <div className="bg-zinc-900 border border-zinc-800 rounded-sm">
              <table className="w-full text-left">
                 <thead className="bg-zinc-950 text-zinc-500 text-[10px] uppercase font-bold tracking-wider"><tr><th className="p-4">Produto</th><th className="p-4">Categoria</th><th className="p-4 text-right">Preço Base (T1)</th><th className="p-4 text-right">Ações</th></tr></thead>
                 <tbody className="divide-y divide-zinc-800 text-sm">
                   {paginatedData.map(p => { const product = p as Product; return (
                     <tr key={product.id} className="hover:bg-zinc-800/50 group transition-colors">
                       <td className="p-4"><p className="font-bold text-slate-200">{product.name}</p><p className="text-xs text-zinc-500 font-mono">{product.sku || '-'}</p></td>
                       <td className="p-4"><span className="bg-zinc-800 text-zinc-400 text-xs px-2 py-1 rounded-sm border border-zinc-700">{product.category || 'Geral'}</span></td>
                       <td className="p-4 text-right font-mono text-emerald-500">{formatCurrency(product.priceTier1 || 0)}</td>
                       <td className="p-4 flex gap-2 justify-end"><button onClick={() => handleOpenProduct(product)} className="p-2 hover:bg-zinc-800 rounded-sm text-zinc-500 hover:text-white"><Edit2 size={16} /></button><button onClick={() => confirmDeleteProduct(product)} className="p-2 hover:bg-red-900/20 rounded-sm text-zinc-500 hover:text-red-500"><Trash2 size={16} /></button></td>
                     </tr>
                   );})}
                 </tbody>
              </table>
            </div>
        )}
        
        {/* MODALS SECTION */}
        {isClientModalOpen && (
            <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4 backdrop-blur-sm">
            <div className="bg-zinc-900 border border-zinc-800 rounded-sm shadow-2xl w-full max-w-lg overflow-hidden animate-in fade-in zoom-in-95">
                <div className="flex justify-between items-center p-4 border-b border-zinc-800 bg-zinc-950"><h2 className="font-bold text-lg text-white uppercase tracking-wider text-sm">{editingClient.id ? 'Editar Cliente' : 'Novo Cliente'}</h2><button onClick={() => setIsClientModalOpen(false)} className="text-zinc-500 hover:text-white"><X size={20} /></button></div>
                <div className="p-6 space-y-4 max-h-[80vh] overflow-y-auto">
                     <div className="grid grid-cols-3 gap-4"><div className="col-span-2"><label className="block text-xs font-bold text-zinc-500 mb-1 uppercase">Empresa *</label><input className="w-full bg-zinc-950 border border-zinc-800 rounded-sm px-3 py-2 outline-none focus:border-gold-500 text-slate-200" value={editingClient.companyName || ''} onChange={e => setEditingClient({...editingClient, companyName: e.target.value})} placeholder="Nome da Empresa" /></div><div><label className="block text-xs font-bold text-zinc-500 mb-1 uppercase">Categoria</label>{renderCategorySection('client', editingClient.category, (val) => setEditingClient({...editingClient, category: val}))}</div></div>
                     <div className="grid grid-cols-2 gap-4"><div><label className="block text-xs font-bold text-zinc-500 mb-1 uppercase">CNPJ</label><input className="w-full bg-zinc-950 border border-zinc-800 rounded-sm px-3 py-2 outline-none focus:border-gold-500 text-slate-200" value={editingClient.cnpj || ''} onChange={e => setEditingClient({...editingClient, cnpj: maskCNPJ(e.target.value)})} maxLength={18} /></div><div><label className="block text-xs font-bold text-zinc-500 mb-1 uppercase">Telefone</label><input className="w-full bg-zinc-950 border border-zinc-800 rounded-sm px-3 py-2 outline-none focus:border-gold-500 text-slate-200" value={editingClient.phone || ''} onChange={e => setEditingClient({...editingClient, phone: maskPhone(e.target.value)})} maxLength={15} /></div></div>
                     <div><label className="block text-xs font-bold text-zinc-500 mb-1 uppercase">Email</label><input className="w-full bg-zinc-950 border border-zinc-800 rounded-sm px-3 py-2 outline-none focus:border-gold-500 text-slate-200" value={editingClient.email || ''} onChange={e => setEditingClient({...editingClient, email: e.target.value})} /></div>
                     <div><label className="block text-xs font-bold text-zinc-500 mb-1 uppercase">Endereço</label><input className="w-full bg-zinc-950 border border-zinc-800 rounded-sm px-3 py-2 outline-none focus:border-gold-500 text-slate-200" value={editingClient.address || ''} onChange={e => setEditingClient({...editingClient, address: e.target.value})} /></div>
                     <button onClick={handleSaveClient} className="w-full bg-gold-600 hover:bg-gold-500 text-black py-2.5 rounded-sm font-bold uppercase tracking-wide flex items-center justify-center gap-2"><Save size={18} /> Salvar Cliente</button>
                </div>
            </div>
            </div>
        )}

        {isAccountModalOpen && (
            <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4 backdrop-blur-sm">
                <div className="bg-zinc-900 border border-zinc-800 rounded-sm shadow-2xl w-full max-w-md p-6">
                    <h3 className="font-bold text-white mb-4 text-sm uppercase">Editar Conta Bancária</h3>
                    <div className="space-y-4">
                        <div><label className="block text-xs text-zinc-500 mb-1">Nome da Conta</label><input value={editingAccount.name} onChange={e => setEditingAccount({...editingAccount, name: e.target.value})} className="w-full bg-zinc-950 border border-zinc-800 rounded-sm p-2 text-white" placeholder="Ex: Caixa Principal" /></div>
                        <div className="grid grid-cols-2 gap-4">
                            <div><label className="block text-xs text-zinc-500 mb-1">Banco</label><input value={editingAccount.bankName} onChange={e => setEditingAccount({...editingAccount, bankName: e.target.value})} className="w-full bg-zinc-950 border border-zinc-800 rounded-sm p-2 text-white" placeholder="Itaú" /></div>
                            <div><label className="block text-xs text-zinc-500 mb-1">Agência/Conta</label><input value={editingAccount.accountNumber} onChange={e => setEditingAccount({...editingAccount, accountNumber: e.target.value})} className="w-full bg-zinc-950 border border-zinc-800 rounded-sm p-2 text-white" placeholder="0000 / 00000-0" /></div>
                        </div>
                        <div>
                            <label className="block text-xs text-zinc-500 mb-1">Tipo</label>
                            <select value={editingAccount.type} onChange={e => setEditingAccount({...editingAccount, type: e.target.value as any})} className="w-full bg-zinc-950 border border-zinc-800 rounded-sm p-2 text-white">
                                <option value="checking">Conta Corrente</option>
                                <option value="savings">Poupança</option>
                                <option value="cash">Caixa Físico</option>
                                <option value="credit_card">Cartão Crédito</option>
                            </select>
                        </div>
                        <button onClick={handleSaveAccount} className="w-full bg-emerald-600 hover:bg-emerald-500 text-white py-2 rounded-sm font-bold text-xs uppercase">Salvar Conta</button>
                        <button onClick={() => setIsAccountModalOpen(false)} className="w-full bg-zinc-800 hover:bg-zinc-700 text-zinc-400 py-2 rounded-sm font-bold text-xs uppercase">Cancelar</button>
                    </div>
                </div>
            </div>
        )}

        {isSupplierModalOpen && (
            <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4 backdrop-blur-sm">
            <div className="bg-zinc-900 border border-zinc-800 rounded-sm shadow-2xl w-full max-w-lg overflow-hidden animate-in fade-in zoom-in-95">
                <div className="flex justify-between items-center p-4 border-b border-zinc-800 bg-zinc-950"><h2 className="font-bold text-lg text-white uppercase tracking-wider text-sm">{editingSupplier.id ? 'Editar Fornecedor' : 'Novo Fornecedor'}</h2><button onClick={() => setIsSupplierModalOpen(false)} className="text-zinc-500 hover:text-white"><X size={20} /></button></div>
                <div className="p-6 space-y-4 max-h-[80vh] overflow-y-auto">
                     <div className="grid grid-cols-3 gap-4"><div className="col-span-2"><label className="block text-xs font-bold text-zinc-500 mb-1 uppercase">Empresa *</label><input className="w-full bg-zinc-950 border border-zinc-800 rounded-sm px-3 py-2 outline-none focus:border-gold-500 text-slate-200" value={editingSupplier.companyName || ''} onChange={e => setEditingSupplier({...editingSupplier, companyName: e.target.value})} /></div><div><label className="block text-xs font-bold text-zinc-500 mb-1 uppercase">Categoria</label>{renderCategorySection('supplier', editingSupplier.category, (val) => setEditingSupplier({...editingSupplier, category: val}))}</div></div>
                     <div className="grid grid-cols-2 gap-4"><div><label className="block text-xs font-bold text-zinc-500 mb-1 uppercase">CNPJ</label><input className="w-full bg-zinc-950 border border-zinc-800 rounded-sm px-3 py-2 outline-none focus:border-gold-500 text-slate-200" value={editingSupplier.cnpj || ''} onChange={e => setEditingSupplier({...editingSupplier, cnpj: maskCNPJ(e.target.value)})} maxLength={18} /></div><div><label className="block text-xs font-bold text-zinc-500 mb-1 uppercase">Telefone</label><input className="w-full bg-zinc-950 border border-zinc-800 rounded-sm px-3 py-2 outline-none focus:border-gold-500 text-slate-200" value={editingSupplier.phone || ''} onChange={e => setEditingSupplier({...editingSupplier, phone: maskPhone(e.target.value)})} maxLength={15} /></div></div>
                     <button onClick={handleSaveSupplier} className="w-full bg-gold-600 hover:bg-gold-500 text-black py-2.5 rounded-sm font-bold uppercase tracking-wide flex items-center justify-center gap-2"><Save size={18} /> Salvar Fornecedor</button>
                </div>
            </div>
            </div>
        )}

        {isProductModalOpen && (
            <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4 backdrop-blur-sm">
            <div className="bg-zinc-900 border border-zinc-800 rounded-sm shadow-2xl w-full max-w-lg overflow-hidden animate-in fade-in zoom-in-95">
                <div className="flex justify-between items-center p-4 border-b border-zinc-800 bg-zinc-950"><h2 className="font-bold text-lg text-white uppercase tracking-wider text-sm">{editingProduct.id ? 'Editar Produto' : 'Novo Produto'}</h2><button onClick={() => setIsProductModalOpen(false)} className="text-zinc-500 hover:text-white"><X size={20} /></button></div>
                <div className="p-6 space-y-4 max-h-[80vh] overflow-y-auto">
                     <div className="grid grid-cols-3 gap-4"><div className="col-span-2"><label className="block text-xs font-bold text-zinc-500 mb-1 uppercase">Nome *</label><input className="w-full bg-zinc-950 border border-zinc-800 rounded-sm px-3 py-2 outline-none focus:border-gold-500 text-slate-200" value={editingProduct.name || ''} onChange={e => setEditingProduct({...editingProduct, name: e.target.value})} /></div><div><label className="block text-xs font-bold text-zinc-500 mb-1 uppercase">Categoria</label>{renderCategorySection('product', editingProduct.category, (val) => setEditingProduct({...editingProduct, category: val}))}</div></div>
                     <div><label className="block text-xs font-bold text-zinc-500 mb-1 uppercase">SKU</label><input className="w-full bg-zinc-950 border border-zinc-800 rounded-sm px-3 py-2 outline-none focus:border-gold-500 text-slate-200" value={editingProduct.sku || ''} onChange={e => setEditingProduct({...editingProduct, sku: e.target.value})} /></div>
                     <div className="grid grid-cols-3 gap-4"><div><label className="block text-xs font-bold text-zinc-500 mb-1 uppercase">Preço T1</label><input type="number" className="w-full bg-zinc-950 border border-zinc-800 rounded-sm px-3 py-2 outline-none focus:border-gold-500 text-emerald-500 font-bold" value={editingProduct.priceTier1 || ''} onChange={e => setEditingProduct({...editingProduct, priceTier1: parseFloat(e.target.value)})} /></div>
                     <div><label className="block text-xs font-bold text-zinc-500 mb-1 uppercase">Preço T2</label><input type="number" className="w-full bg-zinc-950 border border-zinc-800 rounded-sm px-3 py-2 outline-none focus:border-gold-500 text-slate-200" value={editingProduct.priceTier2 || ''} onChange={e => setEditingProduct({...editingProduct, priceTier2: parseFloat(e.target.value)})} /></div>
                     <div><label className="block text-xs font-bold text-zinc-500 mb-1 uppercase">Preço T3</label><input type="number" className="w-full bg-zinc-950 border border-zinc-800 rounded-sm px-3 py-2 outline-none focus:border-gold-500 text-slate-200" value={editingProduct.priceTier3 || ''} onChange={e => setEditingProduct({...editingProduct, priceTier3: parseFloat(e.target.value)})} /></div></div>
                     <button onClick={handleSaveProduct} className="w-full bg-gold-600 hover:bg-gold-500 text-black py-2.5 rounded-sm font-bold uppercase tracking-wide flex items-center justify-center gap-2"><Save size={18} /> Salvar Produto</button>
                </div>
            </div>
            </div>
        )}

        {itemToDelete && (
            <div className="fixed inset-0 bg-black/80 z-[60] flex items-center justify-center p-4 backdrop-blur-sm">
                <div className="bg-zinc-900 border border-zinc-800 rounded-sm shadow-2xl w-full max-w-sm p-6 text-center animate-in fade-in zoom-in-95">
                    <Trash2 size={32} className="text-red-500 mx-auto mb-4" />
                    <h3 className="font-bold text-white mb-2">Excluir Registro?</h3>
                    <p className="text-xs text-zinc-400 mb-6">Você está prestes a excluir <b>{itemToDelete.name}</b>. Esta ação não pode ser desfeita.</p>
                    <div className="flex gap-3"><button onClick={() => setItemToDelete(null)} className="flex-1 bg-zinc-800 text-white py-3 rounded-sm font-bold uppercase text-xs hover:bg-zinc-700">Cancelar</button><button onClick={executeDelete} className="flex-1 bg-red-600 text-white py-3 rounded-sm font-bold uppercase text-xs hover:bg-red-500">Excluir</button></div>
                </div>
            </div>
        )}

      {alertInfo.isOpen && (
          <div className={`fixed bottom-4 right-4 px-4 py-3 rounded-sm border flex items-center gap-3 shadow-2xl z-[60] animate-in slide-in-from-bottom-5 duration-300 ${alertInfo.type === 'success' ? 'bg-emerald-950 border-emerald-900 text-emerald-500' : 'bg-red-950 border-red-900 text-red-500'}`}>
              {alertInfo.type === 'success' ? <CheckCircle size={20} /> : <AlertTriangle size={20} />}
              <div><h4 className="font-bold text-xs uppercase">{alertInfo.title}</h4><p className="text-sm">{alertInfo.message}</p></div>
          </div>
      )}
    </div>
  );
}
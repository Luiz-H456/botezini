import React, { useState, useEffect, useMemo } from 'react';
import { storageService } from '../services/storage';
import { pdfService } from '../services/pdfService';
import { Order, Client, OrderStatus, Product, CompanyProfile, Budget } from '../types';
import { formatCurrency, formatDate, isDateInPeriod } from '../utils';
import { Package, FileText, Clock, AlertTriangle, Printer, Link, RotateCcw, X, Unlock, Trash2, Search, Filter, CheckCircle, ChevronLeft, ChevronRight, ListFilter } from 'lucide-react';

interface Props {
    onNavigate?: (view: 'orders' | 'budgets', searchTerm?: string) => void;
    initialSearch?: string;
    clearSearch?: () => void;
}

const Orders: React.FC<Props> = ({ onNavigate, initialSearch, clearSearch }) => {
    const [orders, setOrders] = useState<Order[]>([]);
    const [budgets, setBudgets] = useState<Budget[]>([]);
    const [clients, setClients] = useState<Client[]>([]);
    const [products, setProducts] = useState<Product[]>([]);
    const [companyProfile, setCompanyProfile] = useState<CompanyProfile | null>(null);
    const [isLoading, setIsLoading] = useState(true);

    const [searchTerm, setSearchTerm] = useState('');
    const [filterClient, setFilterClient] = useState('ALL');
    const [filterStatus, setFilterStatus] = useState('ALL');
    const [filterPeriod, setFilterPeriod] = useState<'ALL' | 'DAY' | 'WEEK' | 'MONTH'>('ALL');

    const [isRevertModalOpen, setIsRevertModalOpen] = useState(false);
    const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
    const [orderToAction, setOrderToAction] = useState<Order | null>(null);

    // Pagination State
    const [currentPage, setCurrentPage] = useState(1);
    const itemsPerPage = 10;
    
    // Reset page when filters change
    useEffect(() => { setCurrentPage(1); }, [searchTerm, filterClient, filterPeriod, filterStatus]);

    // Alert State
    const [alertInfo, setAlertInfo] = useState<{ isOpen: boolean, title: string, message: string, type: 'success' | 'error' }>({ 
        isOpen: false, title: '', message: '', type: 'success' 
    });

    const showAlert = (message: string, type: 'success' | 'error' = 'error') => {
        setAlertInfo({ isOpen: true, title: type === 'error' ? 'Erro' : 'Sucesso', message, type });
        setTimeout(() => setAlertInfo(prev => ({...prev, isOpen: false})), 3000);
    };

    useEffect(() => { loadData(); }, []);

    useEffect(() => {
        if (initialSearch) { setSearchTerm(initialSearch); if (clearSearch) clearSearch(); }
    }, [initialSearch]);

    const loadData = async () => {
        setIsLoading(true);
        try {
            const [o, b, c, p, profile] = await Promise.all([
                storageService.getOrders(),
                storageService.getBudgets(),
                storageService.getClients(),
                storageService.getProducts(),
                storageService.getCompanyProfile()
            ]);
            setOrders(o); 
            setBudgets(b);
            setClients(c);
            setProducts(p);
            setCompanyProfile(profile);
        } catch (e) {
            console.error("Orders Load Error:", e);
            showAlert('Erro ao carregar pedidos. Verifique a conexão.', 'error');
        } finally {
            setIsLoading(false);
        }
    };

    const processedOrders = useMemo(() => {
        // 1. Filter
        const filtered = orders.filter(order => {
            if (searchTerm && !order.orderNumber.toLowerCase().includes(searchTerm.toLowerCase()) && !order.budgetSerialNumber?.toLowerCase().includes(searchTerm.toLowerCase())) return false;
            if (filterClient !== 'ALL' && order.clientId !== filterClient) return false;
            if (filterStatus !== 'ALL' && order.status !== filterStatus) return false;
            
            // Truncate createdAt timestamp to YYYY-MM-DD for filtering
            const createdDate = (order.createdAt || '').substring(0, 10);
            if (!isDateInPeriod(createdDate, filterPeriod)) return false;

            return true;
        });

        // 2. Sort Logic
        return filtered.sort((a, b) => {
            // Group Priority: 
            // 1. Active (Pending/In Production)
            // 2. Completed
            // 3. Delivered
            const getStatusWeight = (status: OrderStatus) => {
                if (status === OrderStatus.DELIVERED) return 3;
                if (status === OrderStatus.COMPLETED) return 2;
                return 1; // Pending, In Production
            };

            const weightA = getStatusWeight(a.status);
            const weightB = getStatusWeight(b.status);

            // If in different groups, sort by group weight
            if (weightA !== weightB) {
                return weightA - weightB;
            }

            // Tie-breaker: Arrival Date (createdAt)
            const dateA = a.createdAt || '';
            const dateB = b.createdAt || '';
            
            // If Delivered: Newest First (DESC)
            if (weightA === 3) {
                return dateB.localeCompare(dateA);
            }

            // Others (Active/Completed): Oldest First (ASC) - FIFO Logic
            return dateA.localeCompare(dateB);
        });
    }, [orders, searchTerm, filterClient, filterStatus, filterPeriod]);

    // Pagination Logic
    const totalPages = Math.ceil(processedOrders.length / itemsPerPage);
    const paginatedOrders = processedOrders.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);

    const getClient = (id: string) => clients.find(c => c.id === id);

    const handlePrintPDF = (order: Order) => {
        const client = getClient(order.clientId);
        if (client) pdfService.generateOrderProductionPDF(order, client, products, companyProfile, order.budgetSerialNumber || ''); 
    };

    const handleRevertClick = (order: Order) => {
        if (!order.budgetId) return;
        if (!budgets.find(b => b.id === order.budgetId)) { showAlert('Orçamento original não encontrado.', 'error'); return; }
        setOrderToAction(order);
        setIsRevertModalOpen(true);
    };

    const handleDeleteClick = (order: Order) => {
        setOrderToAction(order);
        setIsDeleteModalOpen(true);
    };

    const executeDeletion = async (isRevert: boolean) => {
        if (!orderToAction) return;
        
        setIsLoading(true);
        try {
            // 1. Delete the Order
            await storageService.deleteOrder(orderToAction.id);

            // 2. Delete linked Financial Transactions (Cascading delete to keep Finance clean)
            await storageService.deleteTransactionsByReference(orderToAction.id);

            // 3. If linked to Budget, update/reset the Budget
            if (orderToAction.budgetId) {
                 const budget = budgets.find(b => b.id === orderToAction.budgetId);
                 if (budget) {
                     // Explicitly set generatedOrderNumber to null to clear the link
                     await storageService.saveBudget({ 
                         ...budget, 
                         status: 'Approved', // Reset status to allow re-generation if needed
                         generatedOrderNumber: null as any 
                     }); 
                 }
            }

            await loadData();
            setIsRevertModalOpen(false);
            setIsDeleteModalOpen(false);
            setOrderToAction(null);
            
            if (isRevert) showAlert('Pedido revertido e financeiro limpo com sucesso.', 'success');
            else showAlert('Pedido e dados financeiros excluídos com sucesso.', 'success');

        } catch (error) { 
            console.error("Erro ao excluir/reverter:", error); 
            showAlert('Erro ao processar solicitação.', 'error');
        } finally { setIsLoading(false); }
    };

    const getStatusStyle = (status: OrderStatus) => {
         switch (status) {
             case OrderStatus.PENDING: return 'text-zinc-400 bg-zinc-800 border-zinc-700';
             case OrderStatus.IN_PRODUCTION: return 'text-blue-400 bg-blue-950 border-blue-900';
             case OrderStatus.COMPLETED: return 'text-purple-400 bg-purple-950 border-purple-900';
             case OrderStatus.DELIVERED: return 'text-emerald-400 bg-emerald-950 border-emerald-900';
             default: return 'text-zinc-500 bg-zinc-800 border-zinc-700';
         }
    };

    return (
        <div className="space-y-6 relative pb-20">
            <h1 className="text-2xl font-bold text-white">Pedidos de Produção</h1>
            
            <div className="flex flex-col xl:flex-row gap-4 bg-zinc-900 p-4 border border-zinc-800 rounded-sm">
                {/* Search & Client */}
                <div className="flex flex-col md:flex-row gap-4 flex-1">
                    <div className="flex items-center gap-2 bg-zinc-950 px-3 py-2 border border-zinc-800 rounded-sm flex-1">
                        <Search size={16} className="text-zinc-500" />
                        <input placeholder="Buscar..." className="bg-transparent outline-none text-sm text-white w-full" value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} />
                    </div>
                    <div className="flex items-center gap-2 bg-zinc-950 px-3 py-2 border border-zinc-800 rounded-sm flex-1">
                        <Filter size={14} className="text-zinc-500" />
                        <select className="bg-transparent outline-none text-sm text-white w-full uppercase cursor-pointer" value={filterClient} onChange={(e) => setFilterClient(e.target.value)}>
                            <option value="ALL" className="bg-zinc-900 text-zinc-400">Todos Clientes</option>
                            {clients.map(c => <option key={c.id} value={c.id} className="bg-zinc-900 text-zinc-200">{c.companyName}</option>)}
                        </select>
                    </div>
                </div>

                {/* Status & Period */}
                <div className="flex flex-col md:flex-row gap-4 shrink-0">
                    <div className="flex items-center gap-2 bg-zinc-950 px-3 py-2 border border-zinc-800 rounded-sm min-w-[150px]">
                        <ListFilter size={14} className="text-zinc-500" />
                        <select className="bg-transparent outline-none text-sm text-white w-full uppercase cursor-pointer" value={filterStatus} onChange={(e) => setFilterStatus(e.target.value)}>
                            <option value="ALL" className="bg-zinc-900 text-zinc-400">Todos Status</option>
                            <option value={OrderStatus.PENDING} className="bg-zinc-900 text-zinc-200">{OrderStatus.PENDING}</option>
                            <option value={OrderStatus.IN_PRODUCTION} className="bg-zinc-900 text-zinc-200">{OrderStatus.IN_PRODUCTION}</option>
                            <option value={OrderStatus.COMPLETED} className="bg-zinc-900 text-zinc-200">{OrderStatus.COMPLETED}</option>
                            <option value={OrderStatus.DELIVERED} className="bg-zinc-900 text-zinc-200">{OrderStatus.DELIVERED}</option>
                        </select>
                    </div>
                    <div className="flex items-center bg-zinc-950 border border-zinc-800 rounded-sm overflow-x-auto">
                        {(['ALL', 'DAY', 'WEEK', 'MONTH'] as const).map(p => (
                            <button key={p} onClick={() => setFilterPeriod(p)} className={`px-4 py-2 text-xs font-bold uppercase transition-colors whitespace-nowrap ${filterPeriod === p ? 'bg-zinc-800 text-white' : 'text-zinc-500'}`}>
                                {p === 'ALL' ? 'Todos' : p === 'DAY' ? 'Hoje' : p === 'WEEK' ? 'Semana' : 'Mês'}
                            </button>
                        ))}
                    </div>
                </div>
            </div>

            <div className="grid gap-4">
                {paginatedOrders.map(order => {
                    const client = getClient(order.clientId);
                    return (
                        <div key={order.id} className="bg-zinc-900 p-5 rounded-sm border border-zinc-800 flex flex-col md:flex-row justify-between items-center hover:border-zinc-700 transition gap-4">
                            <div className="flex-1 w-full">
                                <div className="flex items-center gap-3 mb-1">
                                    <span className="font-mono text-xs bg-zinc-950 px-2 py-1 rounded-sm text-zinc-400">{order.orderNumber}</span>
                                    <h3 className="font-bold text-white text-sm md:text-base">{client?.companyName}</h3>
                                    <span className={`px-2 py-0.5 text-[10px] font-bold uppercase rounded-sm border ${getStatusStyle(order.status)}`}>{order.status}</span>
                                </div>
                                <div className="text-xs text-zinc-500 flex items-center gap-4">
                                    <span className="flex items-center gap-1"><Clock size={12} /> Entrega: {formatDate(order.deadline)}</span>
                                    <span className="flex items-center gap-1"><Package size={12} /> {order.items.length} itens</span>
                                </div>
                            </div>
                            <div className="flex items-center gap-6 w-full md:w-auto justify-end">
                                <div className="text-right hidden md:block">
                                    <p className="text-[10px] uppercase font-bold text-zinc-600">Total</p>
                                    <p className="font-bold text-lg text-white">{formatCurrency(order.totalAmount)}</p>
                                </div>
                                <div className="flex gap-2 items-center">
                                    {order.budgetSerialNumber && (
                                        <div 
                                            className="mr-2 px-3 py-1 bg-zinc-950 border border-zinc-700 rounded-sm flex items-center gap-2 text-xs text-zinc-400 cursor-pointer hover:bg-zinc-900 transition-colors" 
                                            onClick={() => onNavigate && onNavigate('budgets', order.budgetSerialNumber)}
                                        >
                                            <Link size={12} className="text-yellow-600" />
                                            <span className="font-mono font-bold text-yellow-600">{order.budgetSerialNumber}</span>
                                        </div>
                                    )}
                                    {order.budgetId ? (
                                        <button onClick={() => handleRevertClick(order)} className="p-2 text-zinc-500 hover:text-blue-400 bg-zinc-950 border border-zinc-800 rounded-sm hover:border-blue-900 transition-colors mr-1" title="Reverter para Orçamento">
                                            <RotateCcw size={18} />
                                        </button>
                                    ) : null}
                                    
                                    <button onClick={() => handlePrintPDF(order)} className="p-2 text-zinc-400 hover:text-white bg-zinc-950 border border-zinc-800 rounded-sm transition-colors" title="Imprimir PDF">
                                        <Printer size={18} />
                                    </button>

                                    <button onClick={() => handleDeleteClick(order)} className="p-2 text-zinc-400 hover:text-red-500 bg-zinc-950 border border-zinc-800 rounded-sm transition-colors hover:border-red-900" title="Excluir Definitivamente">
                                        <Trash2 size={18} />
                                    </button>
                                </div>
                            </div>
                        </div>
                    );
                })}
                {processedOrders.length === 0 && (
                    <div className="text-center py-12 border-2 border-dashed border-zinc-800 rounded-sm">
                        <p className="text-zinc-500 text-sm font-bold uppercase">Nenhum pedido encontrado.</p>
                    </div>
                )}
            </div>

            {/* PAGINATION CONTROLS */}
            {processedOrders.length > 0 && (
                <div className="flex justify-between items-center p-4 border-t border-zinc-800 bg-zinc-900 rounded-sm">
                    <span className="text-xs text-zinc-500">
                        Mostrando {(currentPage - 1) * itemsPerPage + 1}-{Math.min(currentPage * itemsPerPage, processedOrders.length)} de {processedOrders.length}
                    </span>
                    <div className="flex gap-2">
                        <button 
                            onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                            disabled={currentPage === 1}
                            className="px-3 py-1 bg-zinc-800 hover:bg-zinc-700 disabled:opacity-50 rounded-sm text-xs font-bold text-zinc-300 transition-colors"
                        >
                            <ChevronLeft size={14} />
                        </button>
                        <span className="px-3 py-1 text-xs font-mono text-zinc-400 flex items-center bg-zinc-950 rounded-sm border border-zinc-800">
                            {currentPage} / {totalPages}
                        </span>
                        <button 
                            onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                            disabled={currentPage === totalPages}
                            className="px-3 py-1 bg-zinc-800 hover:bg-zinc-700 disabled:opacity-50 rounded-sm text-xs font-bold text-zinc-300 transition-colors"
                        >
                            <ChevronRight size={14} />
                        </button>
                    </div>
                </div>
            )}
            
            {/* MODAL: REVERT */}
            {isRevertModalOpen && orderToAction && (
                <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4 backdrop-blur-sm">
                    <div className="bg-zinc-900 border border-zinc-800 rounded-sm shadow-2xl w-full max-w-md p-6 text-center animate-in fade-in zoom-in-95">
                        <RotateCcw size={32} className="text-blue-500 mx-auto mb-4" />
                        <h3 className="font-bold text-white mb-2">Desfazer Conversão?</h3>
                        <p className="text-xs text-zinc-400 mb-6">
                            Isso removerá o pedido <b>{orderToAction.orderNumber}</b> e liberará o orçamento para edição. <br/>
                            <span className="text-red-400 font-bold">Atenção:</span> As transações financeiras vinculadas serão excluídas.
                        </p>
                        <div className="flex gap-3">
                            <button onClick={() => setIsRevertModalOpen(false)} className="flex-1 bg-zinc-800 text-white py-3 rounded-sm font-bold uppercase text-xs hover:bg-zinc-700 transition-colors">Cancelar</button>
                            <button onClick={() => executeDeletion(true)} className="flex-1 bg-blue-600 text-white py-3 rounded-sm font-bold uppercase text-xs hover:bg-blue-500 transition-colors">Confirmar</button>
                        </div>
                    </div>
                </div>
            )}

            {/* MODAL: DELETE */}
            {isDeleteModalOpen && orderToAction && (
                <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4 backdrop-blur-sm">
                    <div className="bg-zinc-900 border border-zinc-800 rounded-sm shadow-2xl w-full max-w-md p-6 text-center animate-in fade-in zoom-in-95">
                        <Trash2 size={32} className="text-red-500 mx-auto mb-4" />
                        <h3 className="font-bold text-white mb-2">Excluir Pedido?</h3>
                        <p className="text-xs text-zinc-400 mb-6">
                            Você está prestes a excluir definitivamente o pedido <b>{orderToAction.orderNumber}</b>. <br/>
                            <br/>
                            <span className="text-red-400 font-bold block mb-1">Esta ação apagará:</span>
                            1. O Pedido da lista e da Produção.<br/>
                            2. Todas as transações financeiras geradas.<br/>
                            3. O vínculo com o Orçamento original.
                        </p>
                        <div className="flex gap-3">
                            <button onClick={() => setIsDeleteModalOpen(false)} className="flex-1 bg-zinc-800 text-white py-3 rounded-sm font-bold uppercase text-xs hover:bg-zinc-700 transition-colors">Cancelar</button>
                            <button onClick={() => executeDeletion(false)} className="flex-1 bg-red-600 text-white py-3 rounded-sm font-bold uppercase text-xs hover:bg-red-500 transition-colors">Excluir Definitivamente</button>
                        </div>
                    </div>
                </div>
            )}

            {/* ALERT TOAST */}
            {alertInfo.isOpen && (
                <div className={`fixed bottom-4 right-4 px-4 py-3 rounded-sm border flex items-center gap-3 shadow-2xl z-[60] animate-in slide-in-from-bottom-5 duration-300 ${alertInfo.type === 'success' ? 'bg-emerald-950 border-emerald-900 text-emerald-500' : 'bg-red-950 border-red-900 text-red-500'}`}>
                    {alertInfo.type === 'success' ? <CheckCircle size={20} /> : <AlertTriangle size={20} />}
                    <div>
                        <h4 className="font-bold text-xs uppercase">{alertInfo.title}</h4>
                        <p className="text-sm">{alertInfo.message}</p>
                    </div>
                </div>
            )}
        </div>
    );
};
export default Orders;

import React, { useState, useEffect, useMemo } from 'react';
import { storageService } from '../services/storage';
import { Transaction, FinancialSplit, Order, Client, Supplier, CostCenter, TransactionType } from '../types';
import { formatCurrency, formatDate, getTodayStr, isDateInPeriod, addMonths, setDayPreservingMonth } from '../utils';
import { Plus, Minus, Filter, Save, Trash2, X, ChevronLeft, ChevronRight, Edit2, TrendingUp, TrendingDown, DollarSign, Link, Repeat, Building2, PieChart as PieIcon, ChevronDown, ChevronUp, Check, CalendarRange, FolderTree, AlertTriangle, CheckCircle } from 'lucide-react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip as RechartsTooltip } from 'recharts';

type PeriodType = 'month' | 'quarter' | 'semester' | 'year';
const COLORS = ['#C9A24D', '#ef4444', '#3b82f6', '#10b981', '#a855f7', '#f97316', '#64748b', '#ec4899'];

interface Props {
    onNavigate?: (view: 'orders' | 'budgets', searchTerm?: string) => void;
}

const Finance: React.FC<Props> = ({ onNavigate }) => {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [clients, setClients] = useState<Client[]>([]);
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [costCenters, setCostCenters] = useState<CostCenter[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formType, setFormType] = useState<TransactionType>('income');
  
  // Filter State (String Based)
  const [periodType, setPeriodType] = useState<PeriodType>('month');
  const [referenceDateStr, setReferenceDateStr] = useState(getTodayStr());
  
  const [categoryFilter, setCategoryFilter] = useState('ALL');
  const [payeeFilter, setPayeeFilter] = useState('ALL');
  const [typeFilter, setTypeFilter] = useState<'ALL' | 'income' | 'expense'>('ALL');

  // Pagination State
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10;

  const [isChartExpanded, setIsChartExpanded] = useState(false);
  const [txToDelete, setTxToDelete] = useState<Transaction | null>(null);

  // Form State
  const [desc, setDesc] = useState('');
  const [amount, setAmount] = useState<string>('');
  
  // Cost Center & Category Logic
  const [selectedCostCenterId, setSelectedCostCenterId] = useState<string>('');
  const [category, setCategory] = useState('');
  
  const [date, setDate] = useState(getTodayStr());
  const [isPaidForm, setIsPaidForm] = useState(true); // Control paid status in form

  const [selectedOrderId, setSelectedOrderId] = useState<string>('');
  const [isManualDesc, setIsManualDesc] = useState(false);
  const [payee, setPayee] = useState('');
  const [recurringMonths, setRecurringMonths] = useState(1);
  const [currentRecurrenceId, setCurrentRecurrenceId] = useState<string | undefined>(undefined);
  const [applyToSeries, setApplyToSeries] = useState(false);

  const [splits, setSplits] = useState<FinancialSplit[]>([
    { name: 'Matéria Prima', percentage: 40, amount: 0 },
    { name: 'Mão de Obra', percentage: 30, amount: 0 },
    { name: 'Lucro', percentage: 30, amount: 0 },
  ]);

  // Alert State
  const [alertInfo, setAlertInfo] = useState<{ isOpen: boolean, title: string, message: string, type: 'success' | 'error' }>({ 
    isOpen: false, title: '', message: '', type: 'success' 
  });

  const showAlert = (message: string, type: 'success' | 'error' = 'error') => {
    setAlertInfo({ isOpen: true, title: type === 'error' ? 'Erro' : 'Sucesso', message, type });
    setTimeout(() => setAlertInfo(prev => ({...prev, isOpen: false})), 3000);
  };

  useEffect(() => { loadData(); }, []);

  // Reset pagination when filters change
  useEffect(() => { setCurrentPage(1); }, [periodType, referenceDateStr, categoryFilter, payeeFilter, typeFilter]);

  const loadData = async () => {
    setIsLoading(true);
    try {
        const [txs, ords, cls, sups, ccenters] = await Promise.all([
            storageService.getTransactions(),
            storageService.getOrders(),
            storageService.getClients(),
            storageService.getSuppliers(),
            storageService.getCostCenters()
        ]);
        setTransactions(txs);
        setOrders(ords);
        setClients(cls);
        setSuppliers(sups);
        setCostCenters(ccenters);
    } catch (e) {
        console.error("Finance Load Error:", e);
        showAlert('Erro ao carregar dados financeiros. Verifique sua conexão.', 'error');
    } finally {
        setIsLoading(false);
    }
  };

  // --- FILTER LOGIC (STRING BASED) ---
  const navigatePeriod = (direction: 'prev' | 'next') => {
    const modifier = direction === 'next' ? 1 : -1;
    let monthsToAdd = 0;
    if (periodType === 'month') monthsToAdd = 1;
    else if (periodType === 'quarter') monthsToAdd = 3;
    else if (periodType === 'semester') monthsToAdd = 6;
    else if (periodType === 'year') monthsToAdd = 12;
    
    setReferenceDateStr(prev => addMonths(prev, monthsToAdd * modifier));
  };

  const getPeriodLabel = () => {
    const [y, m] = referenceDateStr.split('-').map(Number);
    const dateObj = new Date(y, m - 1, 1); 

    if (periodType === 'month') return dateObj.toLocaleString('pt-BR', { month: 'long', year: 'numeric' }).toUpperCase();
    if (periodType === 'quarter') return `${Math.floor((m - 1) / 3) + 1}º TRIMESTRE ${y}`;
    if (periodType === 'semester') return `${Math.floor((m - 1) / 6) + 1}º SEMESTRE ${y}`;
    return `ANO ${y}`;
  };

  const filteredTransactions = useMemo(() => {
    return transactions.filter(t => {
      if (!isDateInPeriod(t.date, periodType.toUpperCase() as any, referenceDateStr)) return false;
      if (categoryFilter !== 'ALL' && t.category !== categoryFilter) return false;
      if (payeeFilter !== 'ALL' && (t.payee || 'N/A').toLowerCase() !== payeeFilter.toLowerCase()) return false;
      if (typeFilter !== 'ALL' && t.type !== typeFilter) return false;
      return true;
    }).sort((a, b) => {
        if (a.isPaid !== b.isPaid) {
            return a.isPaid ? 1 : -1;
        }
        return a.date.localeCompare(b.date);
    });
  }, [transactions, referenceDateStr, periodType, categoryFilter, payeeFilter, typeFilter]);

  // Pagination Logic
  const totalPages = Math.ceil(filteredTransactions.length / itemsPerPage);
  const paginatedTransactions = filteredTransactions.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);

  const uniqueCategories = useMemo(() => Array.from(new Set(transactions.map(t => t.category).filter(Boolean))).sort(), [transactions]);
  const uniquePayees = useMemo(() => Array.from(new Set(transactions.filter(t => t.type === 'expense').map(t => t.payee).filter(Boolean))).sort() as string[], [transactions]);

  // --- KPI ---
  const contextTransactions = filteredTransactions; 
  const totalIncome = contextTransactions.filter(t => t.type === 'income').reduce((sum, t) => sum + t.amount, 0);
  const totalExpense = contextTransactions.filter(t => t.type === 'expense').reduce((sum, t) => sum + t.amount, 0);
  const balance = totalIncome - totalExpense;

  // --- CHART ---
  const expensesByCategoryData = useMemo(() => {
      const groups: Record<string, number> = {};
      contextTransactions.filter(t => t.type === 'expense').forEach(t => {
            const cat = t.category || 'Outros';
            groups[cat] = (groups[cat] || 0) + t.amount;
      });
      return Object.entries(groups).map(([name, value]) => ({ name, value })).sort((a, b) => b.value - a.value); 
  }, [contextTransactions]);

  const getClientName = (id: string) => clients.find(c => c.id === id)?.companyName || 'Cliente Removido';

  // --- FORM HANDLERS ---
  const handleOpenForm = (type: TransactionType, txToEdit?: Transaction) => {
    setFormType(type);
    setApplyToSeries(false);

    if (txToEdit) {
        setEditingId(txToEdit.id);
        setDesc(txToEdit.description.replace(/\s\(\d+\/\d+\)$/, '')); 
        setAmount(txToEdit.amount.toString());
        
        // Load Cost Center & Category
        setSelectedCostCenterId(txToEdit.costCenterId || '');
        setCategory(txToEdit.category);
        
        setDate(txToEdit.date);
        setSelectedOrderId(txToEdit.referenceId || '');
        setIsManualDesc(!txToEdit.referenceId); 
        setPayee(txToEdit.payee || '');
        setIsPaidForm(txToEdit.isPaid);
        setCurrentRecurrenceId(txToEdit.recurrenceId);
        setRecurringMonths(1); 
        
        if (txToEdit.splits) setSplits(txToEdit.splits);
        else resetSplits(parseFloat(txToEdit.amount.toString()));
    } else {
        setEditingId(null);
        setDesc('');
        setAmount('');
        
        // Defaults
        setSelectedCostCenterId('');
        setCategory(type === 'income' ? 'Vendas' : ''); // Start empty for expense to force selection

        setDate(getTodayStr());
        setSelectedOrderId('');
        setPayee('');
        setIsPaidForm(true); 
        setCurrentRecurrenceId(undefined);
        setRecurringMonths(1);
        setIsManualDesc(type === 'expense'); 
        resetSplits(0);
    }
    setShowForm(true);
  };

  const handleOrderSelect = (orderId: string) => {
      setSelectedOrderId(orderId);
      if (!orderId) { setDesc(''); return; }
      const order = orders.find(o => o.id === orderId);
      if (order) {
          setDesc(`Recebimento Pedido #${order.orderNumber} - ${getClientName(order.clientId)}`);
          if (!amount || amount === '0') setAmount((order.totalAmount - order.amountPaid).toFixed(2));
      }
  };

  // Handles the composite value from the grouped select
  const handleCompositeCategoryChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
      const val = e.target.value;
      if (!val) {
          setSelectedCostCenterId('');
          setCategory('');
          return;
      }
      
      const [ccId, catName] = val.split(':::');
      setSelectedCostCenterId(ccId);
      setCategory(catName);
  };

  const resetSplits = (val: number) => {
    setSplits([{ name: 'Matéria Prima', percentage: 40, amount: val * 0.4 }, { name: 'Mão de Obra', percentage: 30, amount: val * 0.3 }, { name: 'Lucro', percentage: 30, amount: val * 0.3 }]);
  };

  const updateSplitPercentage = (index: number, newPercent: number) => {
    const newSplits = [...splits];
    newSplits[index].percentage = newPercent;
    newSplits[index].amount = ((parseFloat(amount) || 0) * newPercent) / 100;
    setSplits(newSplits);
  };

  const updateSplitName = (index: number, name: string) => {
    const newSplits = [...splits];
    newSplits[index].name = name;
    setSplits(newSplits);
  };

  const addSplit = () => setSplits([...splits, { name: 'Novo Split', percentage: 0, amount: 0 }]);
  const removeSplit = (index: number) => setSplits(splits.filter((_, i) => i !== index));

  const handleOpenDelete = (tx: Transaction) => {
    setTxToDelete(tx);
  };

  const handleConfirmDelete = async (deleteSeries: boolean) => {
      if (!txToDelete) return;
      if (deleteSeries && txToDelete.recurrenceId) await storageService.deleteTransactionSeries(txToDelete.recurrenceId);
      else await storageService.deleteTransaction(txToDelete.id);
      setTxToDelete(null);
      loadData();
  };

  const handleTogglePaid = async (tx: Transaction) => {
      const updatedTx = { ...tx, isPaid: !tx.isPaid };
      await storageService.updateTransaction(updatedTx);
      loadData();
  };

  const handleSave = async () => {
    if (!desc || !amount) { showAlert('Preencha descrição e valor', 'error'); return; }
    
    if (formType === 'expense') {
        if (!selectedCostCenterId || !category) {
            showAlert('Selecione uma categoria de despesa', 'error');
            return;
        }
    }

    const totalVal = parseFloat(amount);
    
    if (formType === 'income') {
      const totalPercent = splits.reduce((sum, s) => sum + s.percentage, 0);
      if (Math.abs(totalPercent - 100) > 0.1) { showAlert(`Total de splits deve ser 100%. Atual: ${totalPercent}%`, 'error'); return; }
      splits.forEach(s => s.amount = (totalVal * s.percentage) / 100);
    }

    const baseTxData: Transaction = {
      id: editingId || crypto.randomUUID(), 
      type: formType, description: desc, amount: totalVal, date,
      category: formType === 'income' ? 'Vendas' : category,
      categoryId: '', // Provide a default/empty categoryId to satisfy type definition
      costCenterId: formType === 'expense' ? selectedCostCenterId : undefined,
      referenceId: !isManualDesc ? selectedOrderId : undefined,
      isPaid: isPaidForm, 
      splits: formType === 'income' ? splits : undefined,
      payee: formType === 'expense' ? payee : undefined,
      isRecurring: recurringMonths > 1,
      recurrenceId: currentRecurrenceId 
    };

    if (editingId) {
        if (applyToSeries && currentRecurrenceId) {
            const allTxs = await storageService.getTransactionsByRecurrenceId(currentRecurrenceId);
            const [_, __, newDayStr] = date.split('-');
            const targetDay = parseInt(newDayStr);

            const updates = allTxs.map((tx) => {
               const safeDate = setDayPreservingMonth(tx.date, targetDay);
               let newDescription = desc;
               const match = tx.description.match(/\(\d+\/\d+\)$/);
               if (match) newDescription = `${desc} ${match[0]}`;

               return {
                   ...tx,
                   description: newDescription,
                   amount: totalVal, 
                   category: formType === 'income' ? 'Vendas' : category,
                   costCenterId: formType === 'expense' ? selectedCostCenterId : undefined, 
                   payee,
                   splits: formType === 'income' ? splits : undefined,
                   updatedAt: new Date().toISOString(),
                   date: safeDate,
                   isPaid: tx.id === editingId ? isPaidForm : tx.isPaid 
               };
            });
            await storageService.upsertTransactions(updates);
        } else {
            await storageService.updateTransaction(baseTxData);
        }
    } else {
        if (recurringMonths > 1) {
             const newRecurrenceId = crypto.randomUUID();
             const transactionsToAdd: Transaction[] = [];
             for (let i = 0; i < recurringMonths; i++) {
                 const nextDateStr = addMonths(date, i);
                 transactionsToAdd.push({
                     ...baseTxData,
                     id: crypto.randomUUID(),
                     date: nextDateStr,
                     description: `${desc} (${i + 1}/${recurringMonths})`,
                     isRecurring: true,
                     recurrenceId: newRecurrenceId,
                     isPaid: i === 0 ? isPaidForm : false 
                 });
             }
             await storageService.addTransactions(transactionsToAdd);
        } else {
            await storageService.addTransaction(baseTxData);
        }
    }

    setShowForm(false);
    loadData();
    showAlert('Transação salva com sucesso!', 'success');
  };

  return (
    <div className="space-y-6 relative pb-20">
      {isLoading && <div className="fixed top-20 right-8 bg-blue-600 px-4 py-2 rounded text-white z-50 animate-pulse">Carregando...</div>}
      
      {/* HEADER & KPI */}
      <div className="flex flex-col gap-6">
        <div className="flex justify-between items-center">
            <h1 className="text-2xl font-bold text-white">Gestão Financeira</h1>
            <div className="flex gap-2">
                <button onClick={() => handleOpenForm('income')} className="flex items-center gap-2 px-4 py-2 bg-emerald-600/20 text-emerald-500 border border-emerald-600/50 rounded-sm hover:bg-emerald-600/30 transition text-sm font-bold uppercase tracking-wide"><Plus size={16} /> Receita</button>
                <button onClick={() => handleOpenForm('expense')} className="flex items-center gap-2 px-4 py-2 bg-red-600/20 text-red-500 border border-red-600/50 rounded-sm hover:bg-red-600/30 transition text-sm font-bold uppercase tracking-wide"><Minus size={16} /> Despesa</button>
            </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div onClick={() => setTypeFilter(typeFilter === 'income' ? 'ALL' : 'income')} className={`p-6 rounded-sm relative overflow-hidden group cursor-pointer border ${typeFilter === 'income' ? 'bg-zinc-900 border-emerald-500' : 'bg-zinc-900 border-zinc-800'}`}>
                <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20"><TrendingUp size={40} /></div>
                <p className={`text-xs font-bold uppercase tracking-widest ${typeFilter === 'income' ? 'text-emerald-400' : 'text-zinc-500'}`}>Total Entradas</p>
                <p className="text-2xl font-bold text-emerald-500">{formatCurrency(totalIncome)}</p>
            </div>
            <div onClick={() => setTypeFilter(typeFilter === 'expense' ? 'ALL' : 'expense')} className={`p-6 rounded-sm relative overflow-hidden group cursor-pointer border ${typeFilter === 'expense' ? 'bg-zinc-900 border-red-500' : 'bg-zinc-900 border-zinc-800'}`}>
                <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20"><TrendingDown size={40} /></div>
                <p className={`text-xs font-bold uppercase tracking-widest ${typeFilter === 'expense' ? 'text-red-400' : 'text-zinc-500'}`}>Total Saídas</p>
                <p className="text-2xl font-bold text-red-500">{formatCurrency(totalExpense)}</p>
            </div>
            <div className="bg-zinc-900 border border-zinc-800 p-6 rounded-sm relative overflow-hidden">
                <div className="absolute top-0 right-0 p-4 opacity-10"><DollarSign size={40} /></div>
                <p className="text-xs font-bold text-zinc-500 uppercase tracking-widest">Saldo Líquido</p>
                <p className={`text-2xl font-bold ${balance >= 0 ? 'text-blue-400' : 'text-red-500'}`}>{formatCurrency(balance)}</p>
            </div>
        </div>
      </div>

      {/* FILTER BAR */}
      <div className="bg-zinc-900 rounded-sm border border-zinc-800 p-2 flex flex-wrap gap-4 items-center">
          <div className="flex bg-zinc-950 p-1 rounded-sm border border-zinc-800 shrink-0">
             {(['month', 'quarter', 'semester', 'year'] as PeriodType[]).map((t) => (
                 <button key={t} onClick={() => setPeriodType(t)} className={`px-3 py-1.5 rounded-sm text-xs font-bold uppercase tracking-wide ${periodType === t ? 'bg-zinc-800 text-white' : 'text-zinc-500'}`}>
                    {t === 'month' ? 'Mês' : t === 'quarter' ? 'Tri' : t === 'semester' ? 'Sem' : 'Ano'}
                 </button>
             ))}
          </div>
          <div className="flex items-center gap-2 bg-zinc-950 px-2 py-1.5 rounded-sm border border-zinc-800 shrink-0">
              <button onClick={() => navigatePeriod('prev')} className="text-zinc-500 hover:text-white"><ChevronLeft size={18} /></button>
              <span className="text-xs font-bold text-gold-500 w-32 text-center">{getPeriodLabel()}</span>
              <button onClick={() => navigatePeriod('next')} className="text-zinc-500 hover:text-white"><ChevronRight size={18} /></button>
          </div>
          <div className="h-6 w-px bg-zinc-800 hidden md:block"></div>
          <div className="flex items-center gap-2 bg-zinc-950 px-3 py-1.5 rounded-sm border border-zinc-800 flex-1 min-w-[150px]">
             <Filter size={14} className="text-zinc-500 shrink-0" />
             <select value={categoryFilter} onChange={e => setCategoryFilter(e.target.value)} className="bg-transparent text-xs text-zinc-300 w-full outline-none uppercase cursor-pointer">
                 <option value="ALL" className="bg-zinc-900 text-zinc-400">Todas Categorias</option>
                 {uniqueCategories.map(c => <option key={c} value={c} className="bg-zinc-900 text-zinc-200">{c}</option>)}
             </select>
          </div>
          <div className="flex items-center gap-2 bg-zinc-950 px-3 py-1.5 rounded-sm border border-zinc-800 flex-1 min-w-[150px]">
             <Building2 size={14} className="text-zinc-500 shrink-0" />
             <select value={payeeFilter} onChange={e => setPayeeFilter(e.target.value)} className="bg-transparent text-xs text-zinc-300 w-full outline-none uppercase cursor-pointer">
                 <option value="ALL" className="bg-zinc-900 text-zinc-400">Todas Empresas</option>
                 {uniquePayees.map(p => <option key={p} value={p} className="bg-zinc-900 text-zinc-200">{p}</option>)}
             </select>
          </div>
      </div>
      
      {/* CHART */}
      {expensesByCategoryData.length > 0 && (
          <div className="bg-zinc-900 border border-zinc-800 rounded-sm overflow-hidden">
              <button onClick={() => setIsChartExpanded(!isChartExpanded)} className="w-full flex justify-between items-center p-4 bg-zinc-900 hover:bg-zinc-800/50 transition-colors">
                 <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2"><PieIcon size={16} className="text-gold-500" /> Distribuição de Gastos</h3>
                 <div className="text-zinc-500">{isChartExpanded ? <ChevronUp size={20} /> : <ChevronDown size={20} />}</div>
              </button>
              {isChartExpanded && (
                  <div className="p-6 border-t border-zinc-800 bg-zinc-950/30 flex flex-col md:flex-row gap-8 items-center justify-between">
                    <div className="flex-1 w-full flex flex-wrap gap-2">
                        {expensesByCategoryData.slice(0, 8).map((entry, index) => (
                            <div key={index} className="flex items-center gap-2 bg-zinc-950 px-3 py-1.5 rounded-sm border border-zinc-800">
                                <div className="w-2 h-2 rounded-full" style={{ backgroundColor: COLORS[index % COLORS.length] }}></div>
                                <span className="text-xs text-zinc-300">{entry.name}</span>
                                <span className="text-xs font-bold text-white">{formatCurrency(entry.value)}</span>
                            </div>
                        ))}
                    </div>
                    <div className="w-full md:w-64 h-48 relative shrink-0">
                        <ResponsiveContainer width="100%" height="100%">
                                <PieChart>
                                    <Pie data={expensesByCategoryData} cx="50%" cy="50%" innerRadius={40} outerRadius={80} paddingAngle={2} dataKey="value">
                                        {expensesByCategoryData.map((entry, index) => <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} stroke="rgba(0,0,0,0.5)" strokeWidth={1} />)}
                                    </Pie>
                                    <RechartsTooltip formatter={(value: number) => formatCurrency(value)} contentStyle={{ backgroundColor: '#18181b', borderColor: '#27272a' }} itemStyle={{ color: '#fff' }} />
                                </PieChart>
                        </ResponsiveContainer>
                    </div>
                  </div>
              )}
          </div>
      )}

      {/* TABLE */}
      <div className="bg-zinc-900 rounded-sm border border-zinc-800 overflow-hidden">
        <table className="w-full text-left">
          <thead className="bg-zinc-950 text-zinc-500 text-[10px] uppercase font-bold tracking-wider border-b border-zinc-800">
            <tr>
              <th className="p-4 w-10 text-center">STS</th>
              <th className="p-4 w-32">Data</th>
              <th className="p-4">Descrição</th>
              <th className="p-4 w-40">Classificação</th>
              <th className="p-4 w-64">Splits</th>
              <th className="p-4 text-right">Valor</th>
              <th className="p-4 w-24 text-right">Ações</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-zinc-800 text-sm">
            {paginatedTransactions.map(tx => {
                const linkedOrder = orders.find(o => o.id === tx.referenceId);
                const linkedCC = costCenters.find(cc => cc.id === tx.costCenterId);
                return (
              <tr key={tx.id} className={`hover:bg-zinc-800/50 transition group ${tx.isPaid ? 'opacity-60 grayscale-[0.3]' : ''}`}>
                <td className="p-4 text-center">
                    <button 
                        onClick={(e) => { e.stopPropagation(); handleTogglePaid(tx); }}
                        className={`w-5 h-5 rounded-sm flex items-center justify-center border transition-colors ${tx.isPaid ? 'bg-zinc-800 border-zinc-600 text-zinc-400' : 'border-zinc-700 hover:border-gold-500 text-transparent hover:text-gold-500'}`}
                        title={tx.isPaid ? "Marcar como Pendente" : "Marcar como Pago"}
                    >
                        <Check size={14} />
                    </button>
                </td>
                <td className="p-4 text-zinc-400 font-mono text-xs">{formatDate(tx.date)}</td>
                <td className="p-4 font-medium text-slate-200">
                  <div className="flex items-center gap-2">
                      {tx.description}
                      {tx.recurrenceId && <span title="Recorrente"><Repeat size={14} className="text-blue-500" /></span>}
                  </div>
                  <div className="flex gap-2 mt-1">
                      {tx.payee && <span className="inline-flex items-center gap-1 text-[10px] text-zinc-500 uppercase font-bold tracking-wider"><Building2 size={10}/> {tx.payee}</span>}
                      {tx.referenceId && (
                         <button onClick={(e) => { e.stopPropagation(); if (linkedOrder && onNavigate) onNavigate('orders', linkedOrder.orderNumber); }} className="inline-flex items-center gap-1 text-[10px] bg-zinc-950 border border-zinc-700 text-zinc-400 px-1.5 rounded-sm hover:text-emerald-500 transition-colors">
                             <Link size={10} /> {linkedOrder ? linkedOrder.orderNumber : 'Pedido'}
                         </button>
                      )}
                  </div>
                </td>
                <td className="p-4">
                    <div className="flex flex-col items-start gap-1">
                        <span className="px-2 py-1 bg-zinc-800 border border-zinc-700 rounded-sm text-[10px] uppercase font-bold text-zinc-400 tracking-wider">{tx.category}</span>
                        {linkedCC && (
                            <span className="text-[9px] text-zinc-600 flex items-center gap-1" style={{ color: linkedCC.color }}>
                                <FolderTree size={8} /> {linkedCC.name}
                            </span>
                        )}
                    </div>
                </td>
                <td className="p-4">
                  {tx.splits ? (
                    <div className="flex flex-col gap-1">
                        <div className="flex w-full h-2 rounded-full overflow-hidden bg-zinc-800">
                             {tx.splits.map((s, i) => <div key={i} className={`h-full ${['bg-orange-500', 'bg-blue-500', 'bg-emerald-500'][i%3]}`} style={{ width: `${s.percentage}%` }}></div>)}
                        </div>
                        <div className="flex justify-between text-[10px] text-zinc-500">{tx.splits.map((s, i) => <span key={i}>{s.percentage}%</span>)}</div>
                    </div>
                  ) : <span className="text-zinc-600 text-xs">-</span>}
                </td>
                <td className={`p-4 text-right font-bold ${tx.type === 'income' ? 'text-emerald-500' : 'text-red-500'}`}>{tx.type === 'expense' ? '-' : '+'} {formatCurrency(tx.amount)}</td>
                <td className="p-4 text-right">
                    <div className="flex justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button onClick={() => handleOpenForm(tx.type, tx)} className="text-zinc-500 hover:text-white"><Edit2 size={16} /></button>
                        <button onClick={() => handleOpenDelete(tx)} className="text-zinc-500 hover:text-red-500"><Trash2 size={16} /></button>
                    </div>
                </td>
              </tr>
            )})}
            {filteredTransactions.length === 0 && <tr><td colSpan={7} className="p-16 text-center text-zinc-600 uppercase text-xs font-bold tracking-wider border-dashed">Nenhum lançamento.</td></tr>}
          </tbody>
        </table>
        
        {/* PAGINATION CONTROLS */}
        {filteredTransactions.length > 0 && (
            <div className="flex justify-between items-center p-4 border-t border-zinc-800 bg-zinc-900">
                <span className="text-xs text-zinc-500">
                    Mostrando {(currentPage - 1) * itemsPerPage + 1}-{Math.min(currentPage * itemsPerPage, filteredTransactions.length)} de {filteredTransactions.length}
                </span>
                <div className="flex gap-2">
                    <button 
                        onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                        disabled={currentPage === 1}
                        className="px-3 py-1 bg-zinc-800 hover:bg-zinc-700 disabled:opacity-50 rounded-sm text-xs font-bold text-zinc-300 transition-colors"
                    >
                        <ChevronLeft size={14} />
                    </button>
                    <span className="px-3 py-1 text-xs font-mono text-zinc-400 flex items-center bg-zinc-950 rounded-sm border border-zinc-800">
                        {currentPage} / {totalPages}
                    </span>
                    <button 
                        onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                        disabled={currentPage === totalPages}
                        className="px-3 py-1 bg-zinc-800 hover:bg-zinc-700 disabled:opacity-50 rounded-sm text-xs font-bold text-zinc-300 transition-colors"
                    >
                        <ChevronRight size={14} />
                    </button>
                </div>
            </div>
        )}
      </div>

      {/* MODALS (Form & Delete) */}
      {showForm && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4 backdrop-blur-sm">
          <div className="bg-zinc-900 border border-zinc-800 rounded-sm shadow-2xl w-full max-w-lg overflow-hidden animate-in fade-in zoom-in-95">
             <div className={`p-4 flex justify-between items-center text-white ${formType === 'income' ? 'bg-emerald-900/30' : 'bg-red-900/30'}`}>
              <h3 className="font-bold text-lg tracking-wide uppercase text-sm">{editingId ? 'Editar' : 'Novo'} Lançamento</h3>
              <button onClick={() => setShowForm(false)} className="hover:text-white text-zinc-400"><X size={20} /></button>
            </div>
            <div className="p-6 space-y-4 max-h-[80vh] overflow-y-auto">
              {formType === 'income' && !isManualDesc ? (
                  <select value={selectedOrderId} onChange={(e) => handleOrderSelect(e.target.value)} className="w-full bg-zinc-950 text-slate-200 border border-zinc-800 rounded-sm p-2 outline-none">
                      <option value="" className="bg-zinc-900 text-zinc-400">-- Selecione Pedido --</option>
                      {orders.map(o => <option key={o.id} value={o.id} className="bg-zinc-900 text-zinc-200">#{o.orderNumber} - {getClientName(o.clientId)}</option>)}
                  </select>
              ) : (
                  <input type="text" value={desc} onChange={(e) => setDesc(e.target.value)} className="w-full bg-zinc-950 text-slate-200 border border-zinc-800 rounded-sm p-2 outline-none" placeholder="Descrição" />
              )}
              {formType === 'income' && <button onClick={() => { setIsManualDesc(!isManualDesc); if(!isManualDesc) setDesc(''); }} className="text-xs text-gold-500 underline">{isManualDesc ? 'Selecionar Pedido' : 'Digitar Manual'}</button>}
              
              <div className="grid grid-cols-2 gap-4">
                  <input type="number" value={amount} onChange={(e) => setAmount(e.target.value)} className="w-full bg-zinc-950 text-slate-200 border border-zinc-800 rounded-sm p-2 outline-none" placeholder="Valor" />
                  <input type="date" value={date} onChange={(e) => setDate(e.target.value)} className="w-full bg-zinc-950 text-slate-200 border border-zinc-800 rounded-sm p-2 outline-none" />
              </div>

              {formType === 'expense' && (
                  <div className="space-y-4">
                      {/* Unified Grouped Select for Cost Center and Category */}
                      <div>
                          <label className="text-xs text-zinc-500 font-bold uppercase mb-1 block flex items-center gap-2">
                              <FolderTree size={12} /> Classificação (Centro de Custo / Categoria)
                          </label>
                          <div className="relative">
                              <select 
                                  value={selectedCostCenterId && category ? `${selectedCostCenterId}:::${category}` : ''} 
                                  onChange={handleCompositeCategoryChange} 
                                  className="w-full bg-zinc-950 border border-zinc-800 rounded-sm p-2 outline-none text-zinc-200 appearance-none cursor-pointer hover:border-zinc-700 focus:border-gold-500 transition-colors"
                              >
                                  <option value="" className="bg-zinc-900 text-zinc-500">Selecione a categoria...</option>
                                  {costCenters.map(cc => (
                                      <optgroup label={cc.name} key={cc.id} className="bg-zinc-900 font-bold text-zinc-500 uppercase">
                                          {cc.categories.map(cat => (
                                              <option value={`${cc.id}:::${cat}`} key={`${cc.id}-${cat}`} className="text-white font-normal pl-4">
                                                  {cat}
                                              </option>
                                          ))}
                                          <option value={`${cc.id}:::Outros`} className="text-white font-normal pl-4">Outros</option>
                                      </optgroup>
                                  ))}
                              </select>
                              <ChevronDown size={14} className="absolute right-3 top-3 text-zinc-500 pointer-events-none" />
                          </div>
                      </div>

                      <div>
                          <label className="text-xs text-zinc-500 font-bold uppercase mb-1 block">Beneficiário / Fornecedor</label>
                          <input type="text" list="suppliers-list" value={payee} onChange={(e) => setPayee(e.target.value)} className="w-full bg-zinc-950 border border-zinc-800 rounded-sm p-2 outline-none text-white" placeholder="Quem recebeu este valor?" />
                      </div>
                  </div>
              )}
              
              {/* RECURRENCE LOGIC UI */}
              {formType === 'expense' && !editingId && (
                  <div className="flex items-center gap-2 p-3 bg-zinc-950 border border-zinc-800 rounded-sm">
                      <label className="text-xs uppercase font-bold text-zinc-500 flex items-center gap-2"><Repeat size={14} /> Repetir (Meses)</label>
                      <input type="number" min="1" max="120" value={recurringMonths} onChange={(e) => setRecurringMonths(parseInt(e.target.value))} className="w-16 bg-zinc-900 border border-zinc-800 rounded-sm p-1 text-center text-white" />
                  </div>
              )}

              {/* RECURRENCE EDIT TOGGLE (More explicit) */}
              {editingId && currentRecurrenceId && (
                  <div className="bg-blue-900/10 border border-blue-900/30 rounded-sm p-3">
                      <div className="flex items-center gap-2 mb-2 text-blue-400">
                          <CalendarRange size={16} />
                          <span className="text-xs font-bold uppercase tracking-wider">Item Recorrente</span>
                      </div>
                      <div className="flex gap-4">
                          <label className={`flex-1 cursor-pointer flex items-center gap-2 p-2 rounded-sm border transition-all ${!applyToSeries ? 'bg-blue-600/20 border-blue-500 text-white' : 'bg-zinc-950 border-zinc-800 text-zinc-500 hover:bg-zinc-900'}`}>
                              <input type="radio" name="recurrence" className="hidden" checked={!applyToSeries} onChange={() => setApplyToSeries(false)} />
                              <span className="text-xs font-bold">Apenas Este</span>
                          </label>
                          <label className={`flex-1 cursor-pointer flex items-center gap-2 p-2 rounded-sm border transition-all ${applyToSeries ? 'bg-blue-600/20 border-blue-500 text-white' : 'bg-zinc-950 border-zinc-800 text-zinc-500 hover:bg-zinc-900'}`}>
                              <input type="radio" name="recurrence" className="hidden" checked={applyToSeries} onChange={() => setApplyToSeries(true)} />
                              <span className="text-xs font-bold">Editar Série</span>
                          </label>
                      </div>
                      {applyToSeries && (
                          <p className="text-[10px] text-zinc-400 mt-2">
                              Atenção: Alterações de valor, data (dia) e categoria serão aplicadas a <b>todas</b> as transações desta série. O status "Pago" será mantido individualmente.
                          </p>
                      )}
                  </div>
              )}
               
              <div className="pt-2 flex justify-between items-center border-t border-zinc-800 mt-2">
                  <label className="flex items-center gap-2 cursor-pointer text-sm text-zinc-300">
                      <input type="checkbox" checked={isPaidForm} onChange={() => setIsPaidForm(!isPaidForm)} /> 
                      {isPaidForm ? 'Já Pago/Recebido' : 'Pendente (A Pagar/Receber)'}
                  </label>
              </div>

              {formType === 'income' && (
                  <div className="bg-zinc-950 p-4 rounded-sm border border-zinc-800">
                      <div className="flex justify-between mb-2"><span className="text-xs font-bold text-zinc-400">SPLITS</span> <button onClick={addSplit} className="text-xs text-zinc-400 border px-1">+ Add</button></div>
                      {splits.map((s, i) => (
                          <div key={i} className="flex gap-2 mb-1">
                              <input value={s.name} onChange={e => updateSplitName(i, e.target.value)} className="flex-1 bg-zinc-900 border border-zinc-800 text-xs p-1 text-white" />
                              <input type="number" value={s.percentage} onChange={e => updateSplitPercentage(i, parseFloat(e.target.value))} className="w-12 bg-zinc-900 border border-zinc-800 text-xs p-1 text-white" />
                              <button onClick={() => removeSplit(i)} className="text-red-500"><Trash2 size={12}/></button>
                          </div>
                      ))}
                  </div>
              )}

              <button onClick={handleSave} className="w-full bg-gold-600 hover:bg-gold-500 text-black py-3 rounded-sm font-bold uppercase tracking-wide text-sm flex justify-center gap-2"><Save size={18} /> Salvar</button>
            </div>
          </div>
        </div>
      )}

      {txToDelete && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4 backdrop-blur-sm">
            <div className="bg-zinc-900 border border-zinc-800 rounded-sm p-6 text-center max-w-sm w-full shadow-2xl animate-in fade-in zoom-in-95">
                <AlertTriangle size={32} className="text-red-500 mx-auto mb-4" />
                <h3 className="text-lg font-bold text-white mb-4">Excluir Lançamento?</h3>
                {txToDelete.recurrenceId ? (
                    <div className="flex flex-col gap-2">
                        <button onClick={() => handleConfirmDelete(true)} className="bg-red-600 text-white py-2 rounded-sm font-bold uppercase text-xs">Excluir Toda Série</button>
                        <button onClick={() => handleConfirmDelete(false)} className="bg-zinc-800 text-white py-2 rounded-sm font-bold uppercase text-xs">Excluir Apenas Este</button>
                    </div>
                ) : (
                    <button onClick={() => handleConfirmDelete(false)} className="w-full bg-red-600 text-white py-2 rounded-sm font-bold uppercase text-xs">Confirmar Exclusão</button>
                )}
                <button onClick={() => setTxToDelete(null)} className="mt-4 text-xs text-zinc-500 underline">Cancelar</button>
            </div>
        </div>
      )}

      {/* ALERT TOAST */}
      {alertInfo.isOpen && (
          <div className={`fixed bottom-4 right-4 px-4 py-3 rounded-sm border flex items-center gap-3 shadow-2xl z-[60] animate-in slide-in-from-bottom-5 duration-300 ${alertInfo.type === 'success' ? 'bg-emerald-950 border-emerald-900 text-emerald-500' : 'bg-red-950 border-red-900 text-red-500'}`}>
              {alertInfo.type === 'success' ? <CheckCircle size={20} /> : <AlertTriangle size={20} />}
              <div>
                  <h4 className="font-bold text-xs uppercase">{alertInfo.title}</h4>
                  <p className="text-sm">{alertInfo.message}</p>
              </div>
          </div>
      )}
      
      <datalist id="suppliers-list">{suppliers.map(s => <option key={s.id} value={s.companyName} />)}</datalist>
    </div>
  );
};
export default Finance;
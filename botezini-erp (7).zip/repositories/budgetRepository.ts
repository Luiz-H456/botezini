import { supabase } from '../services/supabase';
import { Budget } from '../types';
import { idService } from '../services/idService';
import { getNow } from '../utils';

export class BudgetRepository {
    async getAll(): Promise<Budget[]> {
        const { data, error } = await supabase.from('budgets').select('*').order('date', { ascending: false });
        if (error) throw new Error(error.message);
        return data || [];
    }

    async save(budget: Budget): Promise<void> {
        const now = getNow().toISOString();
        const payload = { 
            ...budget, 
            id: budget.id || idService.generateUUID(), 
            updatedAt: now, 
            createdAt: budget.createdAt || now 
        };
        const { error } = await supabase.from('budgets').upsert(payload);
        if (error) throw new Error(error.message);
    }

    async delete(id: string): Promise<void> {
        const { error } = await supabase.from('budgets').delete().eq('id', id);
        if (error) throw new Error(error.message);
    }
}